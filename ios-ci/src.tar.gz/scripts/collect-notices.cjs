const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const visited = new Set();
const sections = [];
const top = ['@capacitor/core','@capacitor/android','docx','pptxgenjs','exceljs','pdf-lib','pdfjs-dist','@pdf-lib/fontkit','fflate','7z-wasm'];
function locate(name, from) {
  for (let dir = from; dir.startsWith(root); dir = path.dirname(dir)) {
    const candidate = path.join(dir, 'node_modules', name, 'package.json');
    if (fs.existsSync(candidate)) return path.dirname(candidate);
    if (dir === root) break;
  }
  return null;
}
function visit(dir) {
  if (visited.has(dir)) return;
  visited.add(dir);
  const pkg = JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8'));
  const licenseFiles = fs.readdirSync(dir).filter(name => /^(licen[cs]e|copying|notice|copyright|ofl)([._-]|$)/i.test(name) && fs.statSync(path.join(dir, name)).isFile());
  let text = `${pkg.name}@${pkg.version}\nDeclared license: ${typeof pkg.license === 'string' ? pkg.license : JSON.stringify(pkg.license || pkg.licenses || 'See upstream notices')}\n`;
  if (pkg.author) text += `Published author: ${typeof pkg.author === 'string' ? pkg.author : JSON.stringify(pkg.author)}\n`;
  if (pkg.repository) text += `Published source: ${typeof pkg.repository === 'string' ? pkg.repository : pkg.repository.url || JSON.stringify(pkg.repository)}\n`;
  if (licenseFiles.length) {
    for (const name of licenseFiles) text += `\n[${name}]\n${fs.readFileSync(path.join(dir, name), 'utf8')}\n`;
  } else {
    const readme = fs.readdirSync(dir).find(name => /^readme([._-]|$)/i.test(name) && fs.statSync(path.join(dir, name)).isFile());
    text += '\nNo separate license file was included in this published npm package. Published README follows for its upstream notices.\n';
    if (readme) text += fs.readFileSync(path.join(dir, readme), 'utf8');
    else text += 'No README was distributed. Consult the published package source above.\n';
  }
  sections.push({name: pkg.name, text});
  for (const name of Object.keys(pkg.dependencies || {}).sort()) {
    const dependency = locate(name, dir);
    if (!dependency) throw new Error('Missing dependency notice: ' + name);
    visit(dependency);
  }
}
for (const name of top) {
  const dir = locate(name, root);
  if (!dir) throw new Error('Missing runtime package: ' + name);
  visit(dir);
}
sections.sort((a,b) => a.name.localeCompare(b.name));
const title = 'PDF Atelier Android third-party notices\n\nThe following published license and attribution texts accompany project/runtime dependencies, including transitive dependencies used by prebundled Office libraries. Some dependency-closure entries are build-only or unused browser shims. No private documents, credentials or signing material are included. Existing qpdf, PDF.js, font and other vendor licenses are also retained under assets/public/vendor.\n\n';
const output = title + sections.map(item => '='.repeat(72) + '\n' + item.text).join('\n');
for (const name of ['docx','pptxgenjs','exceljs','@capacitor/core','@capacitor/android']) if (!sections.some(item => item.name === name && item.text.includes('Permission is hereby granted'))) throw new Error('Full MIT notice missing: ' + name);
fs.writeFileSync(path.join(root, 'public', 'open-source-notices.txt'), output);
console.log(`Included published third-party notice texts for ${sections.length} dependency packages.`);
