const fs = require('node:fs');
const path = require('node:path');
const esbuild = require('esbuild-wasm');
const root = path.resolve(__dirname, '..');
(async () => {
  const outdir = path.join(root, 'public');
  require('./collect-notices.cjs');
  // This directory is exclusively generated bundle chunks, never user documents.
  fs.rmSync(path.join(outdir, 'chunks'), {recursive: true, force: true});
  // Splitting is essential: legacy unlock and toolkit share ONE Capacitor/plugin/save gate.
  const result = await esbuild.build({
    absWorkingDir: root,
    entryPoints: { toolkit: 'src/toolkit.js', 'native-save': 'src/native/save-bridge.mjs', 'auth-gate': 'src/auth/auth-gate.js' },
    outdir, bundle: true, splitting: true, format: 'esm', platform: 'browser',
    target: ['chrome110'], mainFields: ['browser','module','main'],
    external: ['/vendor/*'], chunkNames: 'chunks/[name]-[hash]',
    sourcemap: false, minify: true, metafile: true, logLevel: 'info'
  });
  // Exam scanner image worker: standalone classic worker bundle (no network, no shared chunks).
  await esbuild.build({absWorkingDir: root, entryPoints: ['src/exam-scan-worker.js'], outfile: path.join(outdir, 'exam-scan-worker.js'), bundle: true, format: 'iife', platform: 'browser', target: ['chrome110'], minify: true, logLevel: 'warning'});
  const pdfjsRoot = path.dirname(require.resolve('pdfjs-dist/package.json'));
  const destination = path.join(outdir, 'vendor/pdfjs');
  fs.mkdirSync(destination, {recursive: true});
  // Android System WebView may be older than desktop Chromium (e.g. WebView 124 lacks URL.parse).
  // Ship PDF.js's official legacy build, which bundles the required polyfills.
  for (const name of ['pdf.mjs','pdf.worker.mjs']) fs.copyFileSync(path.join(pdfjsRoot, 'legacy', 'build', name), path.join(destination, name));
  for (const name of ['cmaps','standard_fonts','wasm']) fs.cpSync(path.join(pdfjsRoot, name), path.join(destination, name), {recursive:true});
  for (const asset of ['vendor/qpdf.js','vendor/qpdf.wasm','vendor/fflate.js','vendor/fonts/noto-sans-kr.ttf']) {
    if (!fs.existsSync(path.join(outdir, asset))) throw new Error('Missing local asset: '+asset);
  }
  fs.writeFileSync(path.join(root, 'frontend-tests/build-meta.json'), JSON.stringify(result.metafile, null, 2));
  console.log('Android local frontend built in public/; all PDF.js assets copied. No native runtime test performed.');
})().catch(error => {console.error(error); process.exitCode=1;});
