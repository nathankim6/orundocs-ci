import {saveOutput} from '/native-save.js';
const $=id=>document.getElementById(id);
const entries=[];let busy=false,active=null,canceled=false;
const MAX=100*1024*1024, MAX_TOTAL=500*1024*1024;
const label={ready:'준비됨',working:'처리 중',done:'완료',password:'암호 확인 필요',error:'처리 실패'};
function tell(message){$('notice').textContent=message;$('notice').hidden=!message;}
function size(n){return n<1048576?(n/1024).toFixed(0)+' KB':(n/1048576).toFixed(1)+' MB';}
function render(){
 $('drop').hidden=entries.length>0;$('workspace').hidden=!entries.length;$('count').textContent=entries.length;
 $('files').replaceChildren();
 for(const entry of entries){
  const li=document.createElement('li');li.className='file-row';
  const icon=document.createElement('div');icon.className='pdf-icon';icon.textContent='PDF';
  const info=document.createElement('div');info.className='file-info';
  const name=document.createElement('strong');name.textContent=entry.file.name;name.title=entry.file.name;
  const meta=document.createElement('span');meta.className='meta';meta.textContent=size(entry.file.size)+' · '+(entry.message||label[entry.state]);
  info.append(name,meta);
  const input=document.createElement('input');input.type='password';input.autocomplete='off';input.placeholder='열기 암호 (필요 시)';input.setAttribute('aria-label',entry.file.name+' 열기 암호');input.value=entry.password;input.disabled=busy||entry.state==='done';input.className='password-input';input.addEventListener('input',()=>{entry.password=input.value;if(entry.state==='password'||entry.state==='error'){entry.state='ready';entry.message='';meta.textContent=size(entry.file.size)+' · 준비됨';}});
  const tag=document.createElement('span');tag.className='tag '+entry.state;tag.textContent=label[entry.state];
  const action=document.createElement('button');action.className=entry.state==='done'?'download':'remove';action.disabled=busy;action.textContent=entry.state==='done'?'다운로드':'×';action.setAttribute('aria-label',entry.file.name+(entry.state==='done'?' 다운로드':' 제거'));action.onclick=async()=>{if(entry.state==='done')await save(entry.result,entry.outputName,'application/pdf');else{entries.splice(entries.indexOf(entry),1);render();}};
  input.addEventListener('change',()=>window.dispatchEvent(new CustomEvent('atelier-unlock-password',{detail:{file:entry.file,password:entry.password}})));li.append(icon,info,input,tag,action);$('files').append(li);
 }
 $('run').disabled=busy||!entries.some(e=>e.state!=='done');$('run').hidden=busy;$('cancel').hidden=!busy;
 $('clear').disabled=busy;$('add').disabled=busy;$('zip').hidden=!entries.some(e=>e.state==='done');$('zip').disabled=busy;
window.dispatchEvent(new CustomEvent('atelier-unlock-preview',{detail:{entries:entries.map(e=>({file:e.file,result:e.result,outputName:e.outputName})),getPassword:file=>entries.find(e=>e.file===file)?.password||''}}));}
async function addFiles(list){
 if(busy)return;
 const rejected=[];
 for(const file of list){
  if(entries.length>=20){rejected.push('최대 20개까지 선택할 수 있어요.');break;}
  if(!/\.pdf$/i.test(file.name)){rejected.push(file.name+': PDF 파일을 선택해 주세요.');continue;}
  if(file.size>MAX||!file.size){rejected.push(file.name+': 0바이트 초과, 100 MB 이하의 파일만 가능해요.');continue;}
  if(entries.reduce((sum,e)=>sum+e.file.size,0)+file.size>MAX_TOTAL){rejected.push('전체 파일 합계는 500 MB 이하로 선택해 주세요.');continue;}
  const head=new TextDecoder().decode(await file.slice(0,1024).arrayBuffer());
  if(!head.includes('%PDF-')){rejected.push(file.name+': 올바른 PDF 헤더가 없어요.');continue;}
  entries.push({file,password:'',state:'ready',message:'',result:null,outputName:file.name.replace(/\.pdf$/i,'')+'_unlocked.pdf'});
 }
 tell(rejected.join(' '));render();$('picker').value='';
}
async function save(bytes,name,type){try{tell('저장 위치를 선택하고 있습니다.');const result=await saveOutput({bytes,name,mime:type});tell(result?.cancelled?'저장을 취소했습니다. 결과 파일은 그대로 남아 있습니다.':'저장 요청을 완료했습니다.');}catch(error){tell(error.message||'파일 저장에 실패했습니다.');}}
function processOne(entry){return new Promise(async(resolve,reject)=>{
 const worker=new Worker('/worker.js');
 const finish=()=>{clearTimeout(timeout);worker.terminate();active=null;};
 const timeout=setTimeout(()=>{finish();reject(Error('처리 시간이 길어 중단했어요. 더 작은 파일로 다시 시도해 주세요.'));},90000);
 active={cancel(){finish();reject(Error('처리를 중단했어요.'));}};
 worker.onmessage=({data})=>{finish();resolve(data);};worker.onerror=()=>{finish();reject(Error('PDF 엔진 실행에 실패했어요. 기기의 사용 가능한 메모리를 확인하고 작은 파일로 다시 시도해 주세요.'));};
 try{const bytes=await entry.file.arrayBuffer();if(canceled){finish();return reject(Error('처리를 중단했어요.'));}worker.postMessage({bytes,password:entry.password},[bytes]);}catch(e){finish();reject(e);}
});}
$('choose').onclick=$('add').onclick=()=>$('picker').click();$('picker').onchange=e=>addFiles(e.target.files);
for(const name of ['dragenter','dragover'])$('drop').addEventListener(name,e=>{e.preventDefault();$('drop').classList.add('over');});
$('drop').addEventListener('dragleave',()=>$('drop').classList.remove('over'));
document.addEventListener('dragover',e=>e.preventDefault());document.addEventListener('drop',e=>{if(document.body.dataset.tool!=='unlock')return;e.preventDefault();$('drop').classList.remove('over');addFiles(e.dataTransfer.files);});
$('clear').onclick=()=>{for(const e of entries)e.password='';entries.length=0;tell('');render();};
$('run').onclick=async()=>{
 if(busy)return;busy=true;canceled=false;tell('파일을 이 브라우저에서 처리하고 있어요.');
 for(const entry of entries){
  if(canceled)break;if(entry.state==='done')continue;
  entry.state='working';entry.message='';render();
  try{const result=await processOne(entry);
   if(result.ok){entry.state='done';entry.result=new Uint8Array(result.bytes);entry.password='';entry.message=result.warning?'완료 · PDF 복구 경고, 결과 확인 필요':'암호 제거 완료';}
   else if(result.kind==='password'){entry.state='password';entry.message='올바른 열기 암호를 입력해 주세요.';}
   else{entry.state='error';entry.message=result.kind==='unsupported'?'지원하지 않는 암호화 형식이에요.':'손상되었거나 지원하지 않는 PDF예요.';}
  }catch(e){entry.state='error';entry.message=e.message;}
  render();
 }
 busy=false;active=null;render();const count=entries.filter(e=>e.state==='done').length;
 tell(canceled?'처리를 중단했어요. 완료된 파일은 다운로드할 수 있어요.':count===entries.length?count+'개 파일의 잠금 해제를 완료했어요. 다운로드해 주세요.':count+'개 완료. 암호 또는 오류 안내를 확인하고 다시 시도해 주세요.');
};
$('cancel').onclick=()=>{canceled=true;active?.cancel();};
$('zip').onclick=async()=>{try{const data=Object.create(null);let n=0;for(const entry of entries.filter(e=>e.state==='done')){n++;data[n+'_'+entry.outputName]=entry.result;}await save(fflate.zipSync(data,{level:0}),'unlocked_pdfs.zip','application/zip');}catch(error){tell(error.message||'ZIP 생성에 실패했습니다.');}};
render();

window.addEventListener('atelier-preview-ready',render);
window.addEventListener('atelier-preview-password',event=>{const entry=entries.find(e=>e.file===event.detail.file);if(entry){entry.password=event.detail.password;render();}});
