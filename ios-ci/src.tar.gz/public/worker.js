importScripts('/vendor/qpdf.js');
self.onmessage=async({data})=>{
 const messages=[];
 const capture=(...parts)=>{if(messages.length<100)messages.push(parts.join(' ').slice(0,1000));};
 console.log=capture;console.warn=capture;console.error=capture;
 try{
  const engine=await Module({locateFile:p=>'/vendor/'+p,noInitialRun:true,noExitRuntime:true,print:s=>messages.push(String(s)),printErr:s=>messages.push(String(s))});
  engine.FS.writeFile('/input.pdf',new Uint8Array(data.bytes));
  let code=0;
  try{code=engine.callMain(['--password='+data.password,'--decrypt','/input.pdf','/output.pdf'])||0;}catch(e){if(typeof e.status==='number')code=e.status;else throw e;}
  if(code!==0&&code!==3)throw Error(messages.join('\n')||'PDF 처리 실패');
  const bytes=engine.FS.readFile('/output.pdf');
  self.postMessage({ok:true,bytes:bytes.buffer,warning:code===3},[bytes.buffer]);
 }catch(e){
  const text=messages.join('\n')+' '+String(e.message||e);
  const kind=/invalid password|incorrect password|password is incorrect/i.test(text)?'password':/encrypt|unsupported|security handler/i.test(text)?'unsupported':'invalid';
  self.postMessage({ok:false,kind});
 }
};
