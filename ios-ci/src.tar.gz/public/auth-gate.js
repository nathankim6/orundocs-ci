import{a}from"./chunks/chunk-FSI3VSZN.js";import"./chunks/chunk-PHKIAKHS.js";export{a as getExamAIIdToken};
