// Android is fully local. No server discovery or version redirects.
