(()=>{
 function setup(){for(const button of document.querySelectorAll('.tool-tabs button')){const label=button.textContent.trim();button.setAttribute('aria-label',label);button.title=label;}const current=document.getElementById('app-current-title');const update=()=>{if(current)current.textContent=document.title.split(' · ').slice(1).join(' · ')||'모든 PDF 도구';};update();new MutationObserver(update).observe(document.querySelector('title'),{childList:true,subtree:true,characterData:true});
 const search=()=>{if(document.querySelector('.tool-tabs button:disabled'))return;document.getElementById('home-nav')?.click();document.getElementById('tool-search')?.focus();};document.querySelector('.app-quick-search')?.addEventListener('click',search);document.addEventListener('keydown',event=>{if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='k'){event.preventDefault();search();}});
 if(navigator.platform.toLowerCase().includes('mac')){const hint=document.querySelector('.app-quick-search kbd');if(hint)hint.textContent='⌘ K';}
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',setup,{once:true});else setup();
})();
