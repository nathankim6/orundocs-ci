/* Local qpdf WASM worker. Never emit raw exceptions, arguments or passwords. */
importScripts('/vendor/qpdf.js');
self.onmessage = async ({data}) => {
  const messages=[];
  const secrets=[data.password,data.ownerPassword].filter(x=>typeof x==='string' && x.length);
  const sanitize = value => {
    let text=String(value);
    for (const secret of secrets) text=text.split(secret).join('[redacted]');
    return text.slice(0,600);
  };
  const capture=(...parts)=>{if(messages.length<80)messages.push(sanitize(parts.join(' ')));};
  console.log=capture;console.warn=capture;console.error=capture;console.info=capture;
  let engine;
  try {
    if(!['protect','compress','repair'].includes(data.id))throw Error('operation');
    const bytes=new Uint8Array(data.bytes);
    if(!bytes.length || bytes.length>100*1024*1024)throw Error('size');
    if(data.id==='protect' && (typeof data.password!=='string' || !data.password.trim() || [data.password,data.ownerPassword].filter(x=>x!==undefined).some(x=>typeof x!=='string' || !x.trim() || x.includes('\0') || new TextEncoder().encode(x).length>127)))throw Error('password-validation');
    engine=await Module({locateFile:p=>'/vendor/'+p,noInitialRun:true,noExitRuntime:true,print:capture,printErr:capture});
    engine.FS.writeFile('/input.pdf',bytes);
    const run=args=>{try{return engine.callMain(args)||0;}catch(e){if(typeof e.status==='number')return e.status;throw e;}};
    const checkCode=run(['--show-npages','/input.pdf']);
    const count=messages.map(x=>x.trim()).filter(x=>/^\d+$/.test(x)).map(Number).pop();
    if(checkCode!==0 && checkCode!==3)throw Error('invalid');
    if(!count || count>500) {self.postMessage({ok:false,error:'PDF는 1~500페이지까지 지원합니다.'});return;}
    const args=data.id==='protect'
      ? ['--encrypt',data.password,data.ownerPassword ?? data.password,'256','--','/input.pdf','/output.pdf']
      : ['--object-streams=generate','--stream-data=compress','--recompress-flate','--compression-level=9','/input.pdf','/output.pdf'];
    const code=run(args);
    if(code!==0 && code!==3)throw Error('invalid');
    const output=engine.FS.readFile('/output.pdf');
    if(!output.length)throw Error('empty');
    const warnings=(checkCode===3 || code===3)
      ? (data.id==='protect' ? ['qpdf가 구조 경고와 함께 처리했습니다. 결과를 확인하세요.'] : messages.filter(x=>!/^\d+$/.test(x.trim())).slice(0,12)) : [];
    self.postMessage({ok:true,bytes:output.buffer,warnings},[output.buffer]);
  } catch {
    const text=messages.join('\n');
    const error=/invalid password|encrypted|password is incorrect/i.test(text)
      ? '암호가 있는 PDF입니다. 먼저 잠금 해제 도구를 사용하세요.'
      : 'qpdf가 PDF를 처리하지 못했습니다. 유효하지 않거나 복구할 수 없는 파일일 수 있습니다.';
    self.postMessage({ok:false,error});
  } finally {
    try {engine?.FS.unlink('/input.pdf');engine?.FS.unlink('/output.pdf');}catch{}
    data.password=undefined;data.ownerPassword=undefined;
  }
};
