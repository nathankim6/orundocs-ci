import test from 'node:test';
import assert from 'node:assert/strict';
import {
  applyPageSelection,
  buildPageActionPlan,
  clampZoom,
  pageRanges,
  pageSelectionGroups,
  pagesInRect,
  rangePages,
  zoomFromWheel,
} from '../src/pdf-preview-model.mjs';

test('clamps zoom and defaults invalid values', () => {
  assert.equal(clampZoom(9), 4);
  assert.equal(clampZoom(0), 0.25);
  assert.equal(clampZoom(Infinity), 1);
  assert.equal(clampZoom('2'), 1);
});

test('wheel zoom is smooth, supports modes, and clamps invalid extremes', () => {
  const pixel = zoomFromWheel(1, -100, 0);
  const line = zoomFromWheel(1, -2, 1);
  assert.ok(pixel > 1 && pixel < 4);
  assert.ok(line > 1);
  assert.equal(zoomFromWheel(4, -Infinity), 4);
  assert.equal(zoomFromWheel(0.25, Infinity), 0.25);
  assert.equal(zoomFromWheel(4, -10_000, 2), 4);
  assert.equal(zoomFromWheel(0.25, 10_000, 2), 0.25);
});

test('page selection supports Ctrl toggle without mutating current set', () => {
  const current = new Set([1, 2]);
  const next = applyPageSelection(current, [2, 3], { toggle: true });
  assert.deepEqual([...next].sort((a, b) => a - b), [1, 3]);
  assert.deepEqual([...current], [1, 2]);
});

test('page selection supports additive drag union', () => {
  assert.deepEqual(
    [...applyPageSelection(new Set([1, 4]), [2, 3], { additive: true })].sort((a, b) => a - b),
    [1, 2, 3, 4],
  );
});

test('ranges and rectangle selection handle reverse bounds and gaps', () => {
  assert.deepEqual(rangePages(5, 2, 8), [2, 3, 4, 5]);
  assert.deepEqual(rangePages(1, 100_001, 100_001), []);
  assert.deepEqual(
    pagesInRect([
      { page: 1, left: 0, top: 0, right: 10, bottom: 10 },
      { page: 2, left: 11, top: 0, right: 20, bottom: 10 },
      { page: 3, left: 10, top: 0, right: 12, bottom: 10 },
    ], { left: 15, top: 8, right: 5, bottom: -1 }),
    [1, 2, 3],
  );
  assert.equal(pageRanges([1, 2, 3, 5, 7, 8]), '1-3,5,7-8');
});

test('invalid page inputs are ignored by helper selectors', () => {
  assert.deepEqual([...applyPageSelection([1, -2, 2.5], [0, 3, '4'])], [3]);
  assert.deepEqual(pageSelectionGroups(4, [4, 2, 2, 0, 5]), {
    selected: [2, 4], remaining: [1, 3],
  });
  assert.deepEqual(pagesInRect([], { left: 0, top: 0, right: Infinity, bottom: 1 }), []);
});

test('builds noncontiguous exports and separate page labels', () => {
  assert.deepEqual(buildPageActionPlan('extract', [1, 3, 5], 5), {
    operation: 'organize', options: { pages: '1,3,5' }, labels: ['selected'],
  });
  assert.deepEqual(buildPageActionPlan('separate', [3, 1], 3), {
    operation: 'split', options: { mode: 'each', pages: '1,3' }, labels: ['page-1', 'page-3'],
  });
});

test('partitions with semicolon groups and handles all-selected as organize', () => {
  assert.deepEqual(buildPageActionPlan('partition', [1, 3], 4), {
    operation: 'split', options: { mode: 'ranges', ranges: '1,3;2,4' }, labels: ['selected', 'remaining'],
  });
  assert.deepEqual(buildPageActionPlan('partition', [3, 1, 2], 3), {
    operation: 'organize', options: { pages: '1-3' }, labels: ['selected'],
  });
});

test('action plans reject empty, invalid, and oversized requests', () => {
  assert.throws(() => buildPageActionPlan('extract', [], 2));
  assert.throws(() => buildPageActionPlan('extract', [3], 2));
  assert.throws(() => buildPageActionPlan('unknown', [1], 2));
  assert.throws(() => buildPageActionPlan('extract', [1], 501));
});
