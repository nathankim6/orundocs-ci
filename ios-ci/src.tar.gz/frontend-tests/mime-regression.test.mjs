import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createResultSaver} from '../src/native/save-bridge-core.mjs';
import {tools} from '../src/tool-catalog.js';
import {OFFICE_MIME} from '../src/native/local-office-export.mjs';
const source=fs.readFileSync(new URL('../src/native/save-bridge-core.mjs',import.meta.url),'utf8');
const bytes=new TextEncoder().encode('한국어 UTF-8 unchanged');
function nativeHarness(){
 const calls=[];
 const save=createResultSaver({isNativeAndroid:()=>true,nativeSave:async(result,options)=>{calls.push({result,options});return {saved:true};},browserSave:()=>assert.fail('native cannot use browser fallback')});
 return {save,calls};
}
test('MIME regex source is literal standard bare-MIME rule, not replacement expansion',()=>{
 const expected=String.raw`/^[a-z0-9][a-z0-9!#$&^_.+-]*\/[a-z0-9][a-z0-9!#$&^_.+-]*$/i`;
 assert.ok(source.includes(expected));
 assert.doesNotMatch(source,/\[[^\]\n]*try\s*\{/);
 assert.doesNotMatch(source,/try \{ return await \(isNativeAndroid\(\) \?/);
});
const malformed={
 whitespace:['text /plain','text/ plain','text/pl ain',' text/plain','text/plain ','text/plain\n','text/plain\r','text/plain\t','text/plain\u00a0','text/plain\u2028','text/plain\u2029'],
 braces:['text/pl{ain','te}xt/plain','text/{plain}','text/pl[ain]'],
 parentheses:['text/pl(ain','text/pl)ain','te(xt)/plain'],
 questionmark:['text/pl?ain','te?xt/plain','text/plain?download=true'],
 slashCount:['textplain','/text/plain','text/plain/','text//plain','text/plain/extra','text','/'],
 invalidPrefixes:['!text/plain','text/!plain','-text/plain','text/-plain','.text/plain','text/.plain','_text/plain','text/_plain','*/*','text/*','data:text/plain','https://text/plain',':text/plain','text/:plain','',null,undefined],
 extraPunctuation:['text/pl,ain','text/pl:ain','text/pl=ain','text/pl"ain',"text/pl'ain",'text/pl\\ain','text/pl@ain','text/pl%ain','text/pl|ain','text/pl\0ain']
};
for(const [category,values] of Object.entries(malformed))test('reject MIME '+category+' before native call; save gate recovers',async()=>{
 const {save,calls}=nativeHarness();
 for(const mime of values)await assert.rejects(save({name:'test',mime,bytes}),/MIME/,JSON.stringify(mime));
 assert.equal(calls.length,0);
 await save({name:'good.pdf',mime:'application/pdf',bytes});assert.equal(calls.length,1);
});
test('all 25 tool output MIME variants and ZIP accepted, same original byte object',async()=>{
 const overrides={'exam-scan':['application/pdf','image/jpeg','image/png','application/zip','application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
  'pdf-to-word':[OFFICE_MIME.docx], 'pdf-to-ppt':[OFFICE_MIME.pptx], 'pdf-to-excel':[OFFICE_MIME.xlsx],
  'pdf-to-images':['image/png','image/jpeg'], compare:['application/json','text/plain;charset=utf-8','image/png'],
  forms:['application/json','application/pdf'], markdown:['text/markdown;charset=utf-8']
 };
 const {save,calls}=nativeHarness();const covered=new Set();let expectedCount=0;
 for(const tool of tools){
  for(const mime of overrides[tool.id]||['application/pdf']){
   const result={name:tool.id,mime,bytes};const options={sourceBytes:bytes.length};
   await save(result,options);expectedCount++;
   const captured=calls.at(-1);assert.equal(captured.result.bytes,bytes);assert.equal(captured.options,options);
   assert.equal(captured.result.mime,mime.split(';')[0]);assert.equal(result.mime,mime);
   if(!mime.includes(';'))assert.equal(captured.result,result);
  }
  covered.add(tool.id);
 }
 assert.equal(covered.size,26);
 await save({name:'results.zip',mime:'application/zip',bytes});
 assert.equal(calls.length,expectedCount+1);assert.equal(calls.at(-1).result.bytes,bytes);
});
test('case normalization and charset stripping do not mutate MIME or UTF-8 bytes',async()=>{
 const {save,calls}=nativeHarness();
 for(const mime of ['TEXT/MARKDOWN;charset=utf-8','Text/Plain; charset=UTF-8','APPLICATION/JSON;charset=UTF-8','application/vnd.test!#$&^_.+-+xml']){
  const result={name:'test',mime,bytes};await save(result);
  assert.equal(calls.at(-1).result.mime,mime.split(';')[0].toLowerCase());
  assert.equal(calls.at(-1).result.bytes,bytes);assert.equal(result.mime,mime);
  assert.equal(new TextDecoder().decode(bytes),'한국어 UTF-8 unchanged');
 }
});
