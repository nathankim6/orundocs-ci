import test from 'node:test';
import assert from 'node:assert/strict';
import { admission, exportPages, runBatch, workerRequest, CurrentBitmaps, MAX_PHOTO_BYTES } from '../src/exam-batch.mjs';
import { buildPdf } from '../src/exam-scan-export.mjs';
import { PDFDocument } from 'pdf-lib';
const pages = n => Array.from({length:n}, (_,i) => ({id:i+1, status:'pending',file:{size:100}}));
test('page 3 failure isolates, page 4 continues, retry preserves prior results and order', async () => {
 const ps=pages(4),seen=[];
 await runBatch(ps,async p=>{seen.push(p.id);if(p.id===3)throw Error('bad page');p.result={id:p.id};});
 assert.deepEqual(seen,[1,2,3,4]);assert.deepEqual(ps.map(p=>p.status),['done','done','failed','done']);
 const first=ps[0].result;assert.throws(()=>exportPages(ps),/1장/);assert.deepEqual(exportPages(ps,true).map(p=>p.id),[1,2,4]);
 await runBatch(ps.filter(p=>p.status!=='done'),async p=>{p.result={id:p.id};});
 assert.equal(ps[0].result,first);assert.deepEqual(exportPages(ps).map(p=>p.id),[1,2,3,4]);
 [ps[0],ps[3]]=[ps[3],ps[0]];assert.deepEqual(exportPages(ps).map(p=>p.id),[4,2,3,1]);
 assert.throws(()=>exportPages(ps,false,new Set([ps[2]])),/1장/);
});
test('cancel stops sequential queue and preserves completed pages',async()=>{
 const ps=pages(5),c=new AbortController(),seen=[];
 const r=await runBatch(ps,async p=>{seen.push(p.id);if(p.id===3){c.abort();return;}p.result={id:p.id};},{signal:c.signal});
 assert.equal(r.cancelled,true);assert.deepEqual(seen,[1,2,3]);assert.equal(ps[0].result.id,1);assert.equal(ps[2].status,'cancelled');assert.equal(ps[3].status,'pending');assert.throws(()=>exportPages(ps),/3장/);
});
test('20-page, 30MiB individual, 500MiB aggregate limits',()=>{
 assert.equal(admission(pages(19),{size:1}),'');assert.match(admission(pages(20),{size:1}),/21번째/);
 assert.match(admission([],{size:MAX_PHOTO_BYTES+1}),/30 MiB/);
 const ps=Array.from({length:16},()=>({file:{size:MAX_PHOTO_BYTES}}));
 assert.equal(admission(ps,{size:20*1024*1024}),'');ps.push({file:{size:20*1024*1024}});assert.match(admission(ps,{size:1}),/500 MiB/);
});
class FakeWorker { terminated=false; postMessage(m){this.message=m;} terminate(){this.terminated=true;} }
test('worker timeout and abort terminate; new request succeeds',async()=>{
 const stalled=new FakeWorker();await assert.rejects(workerRequest(stalled,{id:1},{timeout:5}),/시간 초과/);assert.ok(stalled.terminated);
 const w=new FakeWorker(),c=new AbortController(),promise=workerRequest(w,{id:2},{signal:c.signal});c.abort();await assert.rejects(promise,/취소/);assert.ok(w.terminated);
 const good=new FakeWorker(),done=workerRequest(good,{id:3});good.onmessage({data:{id:3,ok:true}});assert.equal((await done).ok,true);assert.ok(good.terminated);
});
test('twenty bitmap switches retain only one pair and close stale races',async()=>{
 let active=0,peak=0;const decode=async()=>{active++;peak=Math.max(peak,active);let closed=false;return{close(){if(!closed){active--;closed=true;}}};};
 const cache=new CurrentBitmaps(decode),ps=pages(20);for(const p of ps)p.result={before:{},after:{}};
 for(const p of ps){cache.clear();assert.equal((await cache.get(p)).page,p);assert.equal(active,2);}
 cache.clear();assert.equal(active,0);const stale=cache.get(ps[0]);cache.clear();const current=cache.get(ps[1]);assert.equal(await stale,null);assert.equal((await current).page,ps[1]);cache.clear();assert.equal(active,0);assert.equal(peak,2);
});
test('in-flight stale decode closes both bitmaps; partial failure closes first',async()=>{
 let release,closed=0,calls=0;const cache=new CurrentBitmaps(async()=>{calls++;if(calls===1)await new Promise(r=>release=r);return{close(){closed++;}};});
 const p={result:{before:{},after:{}}},old=cache.get(p);await Promise.resolve();cache.clear();release();assert.equal(await old,null);assert.equal(closed,2);
 let n=0;const bad=new CurrentBitmaps(async()=>{if(++n===2)throw Error('decode');return{close(){closed++;}};});await assert.rejects(bad.get(p),/decode/);assert.equal(closed,3);
});
test('20-page PDF parsed by actual PDFDocument parser preserves count and page order',async()=>{
 const jpeg=new Uint8Array([255,216,255,192,0,17,8,0,1,0,1,3,1,17,0,2,17,0,3,17,0,255,217]);
 const input=Array.from({length:20},(_,i)=>({jpeg,width:100,height:120+i}));
 const bytes=await buildPdf(input,{paper:'image'}),pdf=await PDFDocument.load(bytes);
 assert.equal(pdf.getPageCount(),20);pdf.getPages().forEach((p,i)=>assert.ok(Math.abs(p.getHeight()-595.28*(120+i)/100)<0.001));
});
