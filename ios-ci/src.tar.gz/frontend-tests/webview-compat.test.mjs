import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const root=new URL('../',import.meta.url);
test('Android ships PDF.js legacy build for older System WebView (no native URL.parse)',()=>{
 const pdfjs=require('path').dirname(require.resolve('pdfjs-dist/package.json'));
 for(const name of ['pdf.mjs','pdf.worker.mjs']){
  const shipped=fs.readFileSync(new URL('public/vendor/pdfjs/'+name,root));
  assert.ok(shipped.equals(fs.readFileSync(pdfjs+'/legacy/build/'+name)),name+' must be legacy build');
 }
});
