import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {tools} from '../src/tool-catalog.js';
import {localCapabilities} from '../src/local-capabilities.js';
import {createResultSaver} from '../src/native/save-bridge-core.mjs';
import {saveResultWithPlugin,MAX_CHUNK_BYTES} from '../src/native/saf-save-core.mjs';
import {PDF_MAX_BYTES,TOTAL_MAX_BYTES} from '../src/file-limits.js';
const read=p=>fs.readFileSync(new URL('../'+p,import.meta.url),'utf8');
const expected=['merge','split','compress','pdf-to-word','pdf-to-ppt','pdf-to-excel','edit','pdf-to-images','images-to-pdf','sign','watermark','rotate','html-to-pdf','unlock','protect','organize','repair','page-numbers','exam-scan','scan','compare','redact','crop','forms','markdown','workflow'];
test('exactly 26 supported IDs with dispatcher coverage',()=>{
 assert.deepEqual(tools.map(t=>t.id),expected); assert.equal(new Set(expected).size,26);
 const dispatch=read('src/toolkit.js');
 for(const tool of tools){
  if(tool.engine==='existing'){
   assert.equal(tool.id,'unlock');
   assert.ok(dispatch.includes(`if(tool.engine==='existing'){document.querySelector('[data-mode="'+id+'"]').click();return;}`));
   assert.match(read('public/index.html'),/data-mode="unlock"/);
   assert.match(read('public/workspace.js'),/button.onclick=/);
   assert.match(read('public/workspace.js'),/atelier-view-change/);
   assert.match(read('public/app.js'),/await processOne\(entry\)/);
   assert.match(read('public/app.js'),/new Worker\('\/worker.js'\)/);
   continue;
  }
  assert.ok(dispatch.includes("tool.engine==='"+tool.engine+"'"),tool.id);
  const source={exam:'src/exam-scan-ui.js',pdf:'src/pdf-ops.js',edit:'src/pdf-edit-ops.js',convert:'src/pdf-convert-ops.js',html:'src/html-to-pdf.js',workflow:'src/toolkit.js'}[tool.engine];
  if(tool.engine==='html')assert.match(read(source),/export async function runLocalHtmlToPdf/);else assert.ok(read(source).includes(tool.id),tool.id);
 }
 assert.equal(tools.find(t=>t.id==='html-to-pdf').engine,'html');
});
test('Office status local, exclusions absent, policy limits unchanged',()=>{
 assert.equal(localCapabilities.export.available,true);assert.deepEqual(localCapabilities.export.kinds,['docx','pptx','xlsx']);
 assert.equal(localCapabilities.officeToPdf.available,false);
 assert.equal(PDF_MAX_BYTES,100*1024*1024);assert.equal(TOTAL_MAX_BYTES,500*1024*1024);
 assert.match(read('src/pdf-convert-ops.js'),/import \{ exportOffice \} from '.\/native\/local-office-export.mjs'/);
 assert.match(read('public/pdf-ops-worker.js'),/bytes.length>100\*1024\*1024/);
});
test('active frontend has no backend endpoints and local CSP/assets',()=>{
 for(const p of ['src/toolkit.js','src/pdf-convert-ops.js','src/html-to-pdf.js','public/app.js','public/version-bridge.js','public/toolkit.js']) assert.doesNotMatch(read(p),/\/api\/|localhost:\d|127\.0\.0\.1/);
 const html=read('public/index.html');assert.match(html,/옳은영어 김성진T/);assert.match(html,/wasm-unsafe-eval/);assert.match(html,/connect-src 'self' https:\/\/securetoken\.googleapis\.com https:\/\/firestore\.googleapis\.com https:\/\/identitytoolkit\.googleapis\.com;/);assert.doesNotMatch(html.replace(" https://securetoken.googleapis.com https://firestore.googleapis.com https://identitytoolkit.googleapis.com;",';'),/'unsafe-eval'|https?:\/\//);assert.match(html,/<html lang="ko" class="od-locked">/);assert.ok(html.indexOf('/auth-gate.js')>0&&html.indexOf('/auth-gate.js')<html.indexOf('/app.js'));assert.match(html,/viewport-fit=cover/);assert.match(html,/type="module" src="\/app.js"/);
 for(const asset of ['pdf.mjs','pdf.worker.mjs','cmaps','standard_fonts','wasm'])assert.ok(fs.existsSync(new URL('../public/vendor/pdfjs/'+asset,import.meta.url)));
});
test('all legacy and toolkit downloads await common bridge, anchors isolated to browser branch',()=>{
 for(const p of ['src/toolkit.js','public/app.js']){const source=read(p);assert.match(source,/await saveOutput\(/);assert.doesNotMatch(source,/\.download=|createElement\('a'\)/);assert.match(source,/result\?\.cancelled/);}
 assert.match(read('src/toolkit.js'),/await download\(zipSync/);
 assert.match(read('public/app.js'),/await save\(fflate.zipSync/);
 assert.match(read('src/native/save-bridge.mjs'),/\['android', 'ios'\]\.includes\(Capacitor\.getPlatform\(\)\)/);
 const meta=JSON.parse(read('frontend-tests/build-meta.json'));
 assert.equal(Object.keys(meta.inputs).filter(p=>p.endsWith('@capacitor/core/dist/index.js')).length,1);
 const entries=Object.values(meta.outputs).filter(o=>o.entryPoint);
 const native=entries.find(o=>o.entryPoint==='src/native/save-bridge.mjs');const toolkit=entries.find(o=>o.entryPoint==='src/toolkit.js');
 assert.ok(native.imports.some(n=>toolkit.imports.some(t=>t.path===n.path)),'both entry points use same shared chunk');
});
test('save singleton rejects overlap, preserves bytes, cancellation normal, recovers after error',async()=>{
 const bytes=new Uint8Array([1,2,3]);const output={bytes,name:'a.pdf',mime:'application/pdf'};let finish;
 const saver=createResultSaver({isNativeAndroid:()=>true,nativeSave:result=>{assert.equal(result,output);assert.equal(result.bytes,bytes);return new Promise(resolve=>finish=resolve);},browserSave:()=>assert.fail('browser fallback called on native')});
 const first=saver(output);await assert.rejects(saver(output),/다른 파일/);finish({cancelled:true});assert.deepEqual(await first,{cancelled:true});
 let attempts=0;const recover=createResultSaver({isNativeAndroid:()=>true,nativeSave:async()=>{if(!attempts++)throw Error('disk full');return {cancelled:false};}});
 await assert.rejects(recover(output),/disk full/);assert.deepEqual(await recover(output),{cancelled:false});
 const browser=createResultSaver({isNativeAndroid:()=>false,nativeSave:()=>assert.fail(),browserSave:async r=>{assert.equal(r,output);return {cancelled:false};}});await browser(output);
});
test('SAF streaming uses bounded chunks and cancellation does not write',async()=>{
 const bytes=new Uint8Array(MAX_CHUNK_BYTES*2+3);let chunks=0;
 const plugin={beginSave:async args=>{assert.equal(args.expectedBytes,bytes.length);return{id:'test'};},writeChunk:async args=>{assert.equal(args.index,chunks++);assert.ok(Buffer.from(args.base64,'base64').length<=MAX_CHUNK_BYTES);},finishSave:async()=>({saved:true})};
 assert.deepEqual(await saveResultWithPlugin(plugin,{name:'test.pdf',mime:'application/pdf',bytes}),{saved:true});assert.equal(chunks,3);
 assert.deepEqual(await saveResultWithPlugin({beginSave:async()=>({cancelled:true})},{name:'a.pdf',mime:'application/pdf',bytes}),{cancelled:true});
});

test('Android SAF gets bare MIME and unchanged UTF-8 bytes',async()=>{
 const bytes=new TextEncoder().encode('한국어 Markdown');
 const saver=createResultSaver({isNativeAndroid:()=>true,nativeSave:async result=>{assert.equal(result.mime,'text/markdown');assert.equal(result.bytes,bytes);return {saved:true};},browserSave:()=>assert.fail('native used anchor')});
 assert.deepEqual(await saver({name:'text.md',mime:'text/markdown;charset=utf-8',bytes}),{saved:true});
 await assert.rejects(saver({name:'text.md',mime:'*/*',bytes}),/MIME/);
});
