import test from 'node:test';
import assert from 'node:assert/strict';
import * as core from '../src/exam-scan-core.mjs';
import { buildDocx, buildPdf } from '../src/exam-scan-export.mjs';
import { unzipSync, strFromU8 } from 'fflate';

function page(w, h) { return core.makeImage(w, h, 255); }
function rect(img, x0, y0, x1, y1, [r, g, b]) { for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) { const i = (y * img.width + x) * 4; img.data[i] = r; img.data[i + 1] = g; img.data[i + 2] = b; } }

test('detects a light sheet on a saturated desk and orders corners', () => {
  const img = page(400, 300); rect(img, 0, 0, 400, 300, [140, 90, 50]);
  rect(img, 60, 40, 340, 270, [235, 235, 230]);
  const d = core.detectDocument(img);
  assert.equal(d.detected, true);
  const [tl, tr, br, bl] = d.corners;
  assert.ok(Math.abs(tl[0] - 60) < 6 && Math.abs(tl[1] - 40) < 6, 'TL ' + tl);
  assert.ok(Math.abs(br[0] - 339) < 6 && Math.abs(br[1] - 269) < 6, 'BR ' + br);
  assert.ok(tr[0] > tl[0] && bl[1] > tl[1]);
});

test('perspective warp maps a quad to an upright rectangle', () => {
  const img = page(200, 200); rect(img, 50, 50, 150, 150, [0, 0, 0]);
  const out = core.warpPerspective(img, [[50, 50], [149, 50], [149, 149], [50, 149]], { width: 40, height: 40 });
  let dark = 0; for (let i = 0; i < out.data.length; i += 4) if (out.data[i] < 50) dark++;
  assert.ok(dark > 1500, 'mostly black: ' + dark);
});

test('removes coloured pen and light pencil, keeps black print', () => {
  const img = page(300, 200);
  rect(img, 20, 20, 120, 28, [15, 15, 15]);      // printed bar (thick text-like)
  rect(img, 20, 60, 30, 110, [10, 10, 10]);      // printed glyph
  rect(img, 150, 20, 260, 26, [40, 60, 200]);    // blue pen stroke
  rect(img, 150, 60, 158, 120, [210, 40, 40]);   // red check
  rect(img, 180, 140, 250, 146, [150, 150, 150]);// light pencil
  const { image } = core.removeHandwriting(img, {});
  const at = (x, y) => image.data[(y * image.width + x) * 4];
  assert.ok(at(60, 24) < 40, 'print bar kept');
  assert.ok(at(25, 80) < 40, 'print glyph kept');
  assert.equal(at(200, 23), 255, 'blue pen removed');
  assert.equal(at(154, 90), 255, 'red mark removed');
  assert.equal(at(210, 143), 255, 'pencil removed');
});

test('brush erase and restore', () => {
  const orig = page(50, 50); rect(orig, 0, 0, 50, 50, [0, 0, 0]);
  const t = core.cloneImage(orig);
  core.applyBrush(t, orig, [[25, 25]], 5, 'erase'); assert.equal(t.data[(25 * 50 + 25) * 4], 255);
  core.applyBrush(t, orig, [[25, 25]], 5, 'restore'); assert.equal(t.data[(25 * 50 + 25) * 4], 0);
});

test('DOCX and PDF exports are structurally valid', async () => {
  const jpeg = new Uint8Array([0xff, 0xd8, 0xff, 0xe0, 0, 16, 0x4a, 0x46, 0x49, 0x46, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0, 0xff, 0xd9]);
  const docx = unzipSync(buildDocx([{ jpeg, width: 100, height: 140 }, { jpeg, width: 100, height: 140 }]));
  assert.ok(docx['word/document.xml'] && docx['word/media/image2.jpeg'] && docx['[Content_Types].xml']);
  assert.match(strFromU8(docx['word/document.xml']), /w:br w:type="page"/);
  await assert.rejects(buildPdf([]));
});
