import test from 'node:test';
import assert from 'node:assert/strict';
import {unzipSync,strFromU8} from 'fflate';
import {exportOffice} from '../src/native/local-office-export.mjs';
const png='iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aD1sAAAAASUVORK5CYII=';
const pages=[{page:1,width:595,height:842,text:'Local Korean 한국어',lines:[{text:'Local Korean 한국어',cells:['=1+1','한국어']}],image:png}];
for(const [kind,entry] of [['docx','word/document.xml'],['pptx','ppt/slides/slide1.xml'],['xlsx','xl/worksheets/sheet1.xml']])test('real local '+kind+' package export',async()=>{
 const output=await exportOffice(kind,'local-test',pages,{});assert.equal(output.name,'local-test.'+kind);assert.ok(output.bytes instanceof Uint8Array);
 const files=unzipSync(output.bytes);assert.ok(files[entry]);assert.ok(files['[Content_Types].xml']);
 if(kind==='docx')assert.match(strFromU8(files[entry]),/한국어/);
 if(kind==='xlsx')assert.doesNotMatch(strFromU8(files[entry]),/<f[ >]/);
});
