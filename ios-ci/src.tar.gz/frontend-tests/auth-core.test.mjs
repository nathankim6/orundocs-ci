import assert from 'node:assert/strict';
import { evaluateSession, parseCallback, offlineGrace, buildSigninUrl, randomState, decodeJwtPayload, AUTH_CONFIG } from '../src/auth/orundocs-auth-core.mjs';
const DAY = 86400000, T0 = Date.UTC(2026, 10, 1);
const b64 = o => Buffer.from(JSON.stringify(o)).toString('base64url');
const jwt = claims => 'h.' + b64(claims) + '.s';
function fakeFetch({ token = 200, provider = 'google.com', email = 'a@x.com', allow = 200, net = false, tokenErr = 'TOKEN_EXPIRED' } = {}) {
  const calls = [];
  const f = async (url, init) => {
    calls.push(url);
    if (net) throw new TypeError('Failed to fetch');
    if (url.startsWith('https://securetoken')) {
      if (token !== 200) return new Response(JSON.stringify({ error: { message: tokenErr } }), { status: token });
      return new Response(JSON.stringify({ id_token: jwt({ email, firebase: { sign_in_provider: provider } }), refresh_token: 'rotated-refresh-token-xxxxxxxx' }), { status: 200 });
    }
    if (url.includes('/allowlist/')) { assert.ok(url.endsWith(encodeURIComponent(email))); assert.match(init.headers.authorization, /^Bearer h\./); return new Response('{}', { status: allow }); }
    throw new Error('unexpected ' + url);
  };
  f.calls = calls; return f;
}
const S = (o = {}) => ({ v: 1, email: 'a@x.com', refreshToken: 'refresh-token-abcdefghijkl', lastVerifiedAt: T0, maxSeenAt: T0, ...o });
let n = 0; const t = async (name, fn) => { await fn(); n++; console.log('ok', name); };

await t('signed-out without session', async () => assert.equal((await evaluateSession(null)).status, 'signed-out'));
await t('allowed online updates lastVerifiedAt and rotates token', async () => {
  const r = await evaluateSession(S(), { fetch: fakeFetch(), now: T0 + 3 * DAY });
  assert.equal(r.status, 'allowed'); assert.equal(r.session.lastVerifiedAt, T0 + 3 * DAY); assert.equal(r.session.refreshToken, 'rotated-refresh-token-xxxxxxxx'); assert.equal(r.session.email, 'a@x.com');
});
await t('email comes from verified token, not callback', async () => {
  const r = await evaluateSession(S({ email: 'spoof@evil.com' }), { fetch: fakeFetch({ email: 'real@x.com' }), now: T0 });
  assert.equal(r.status, 'allowed'); assert.equal(r.session.email, 'real@x.com');
});
await t('removed from allowlist (404) -> blocked', async () => assert.equal((await evaluateSession(S(), { fetch: fakeFetch({ allow: 404 }), now: T0 })).status, 'blocked'));
await t('rules deny (403) -> blocked', async () => assert.equal((await evaluateSession(S(), { fetch: fakeFetch({ allow: 403 }), now: T0 })).status, 'blocked'));
await t('deleted Firebase user (400 USER_NOT_FOUND) -> blocked', async () => assert.equal((await evaluateSession(S(), { fetch: fakeFetch({ token: 400, tokenErr: 'USER_NOT_FOUND' }), now: T0 })).status, 'blocked'));
await t('Apple and admin-issued password accounts are accepted when allowlisted', async () => { for (const p of ['apple.com', 'password']) assert.equal((await evaluateSession(S(), { fetch: fakeFetch({ provider: p }), now: T0 })).status, 'allowed'); });
await t('unknown provider (anonymous/phone) blocked', async () => assert.equal((await evaluateSession(S(), { fetch: fakeFetch({ provider: 'anonymous' }), now: T0 })).status, 'blocked'));
await t('offline day 6.9 -> offline allowed', async () => {
  const r = await evaluateSession(S(), { fetch: fakeFetch({ net: true }), now: T0 + 6.9 * DAY });
  assert.equal(r.status, 'offline'); assert.equal(r.daysLeft, 1); assert.equal(r.session.maxSeenAt, T0 + 6.9 * DAY);
});
await t('offline after 7 days -> expired', async () => {
  const r = await evaluateSession(S(), { fetch: fakeFetch({ net: true }), now: T0 + 7 * DAY + 1 });
  assert.equal(r.status, 'offline-expired'); assert.equal(r.reason, 'expired');
});
await t('server 503 treated as offline (grace)', async () => assert.equal((await evaluateSession(S(), { fetch: fakeFetch({ token: 503 }), now: T0 + DAY })).status, 'offline'));
await t('clock rolled back -> no offline grace', async () => {
  const r = await evaluateSession(S({ maxSeenAt: T0 + 5 * DAY }), { fetch: fakeFetch({ net: true }), now: T0 + 1 * DAY });
  assert.equal(r.status, 'offline-expired'); assert.equal(r.reason, 'clock');
});
await t('never verified -> no offline grace', async () => assert.equal(offlineGrace({ lastVerifiedAt: 0 }, T0).ok, false));
await t('callback state must match', async () => {
  assert.throws(() => parseCallback('http://127.0.0.1:1/auth/callback#rt=xxxxxxxxxxxxxxxxxxxxxxxx&state=AAA', 'BBB'), /일치하지/);
  assert.equal(parseCallback('com.orundocs.app://auth#rt=xxxxxxxxxxxxxxxxxxxxxxxx&state=AAA&email=A%40X.com', 'AAA').email, 'a@x.com');
  assert.equal(parseCallback('rt=xxxxxxxxxxxxxxxxxxxxxxxx&state=AAA', 'AAA').refreshToken, 'xxxxxxxxxxxxxxxxxxxxxxxx');
  assert.throws(() => parseCallback('#state=AAA', 'AAA'), /비어/);
});
await t('signin URL and state', async () => {
  const s = randomState(); assert.match(s, /^[A-Za-z0-9_-]{43}$/);
  assert.equal(buildSigninUrl({ target: 'desktop', state: s, port: 50123 }), AUTH_CONFIG.signinUrl + '?target=desktop&state=' + s + '&port=50123');
  assert.equal(decodeJwtPayload(jwt({ email: '한글@x.com' })).email, '한글@x.com');
});
console.log(`auth-core: ${n} tests passed`);
