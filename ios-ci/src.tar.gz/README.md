# PDF Atelier Android 3.3.0

Private source-only CI project. Creator: 옳은영어 김성진T.

- 25 local PDF tools, PDF preview, local DOCX/PPTX/XLSX export, Android SAF saving.
- Android 10/API29 or later; compile/target API36.
- No OCR, Office-to-PDF, PDF/A, AI summary or translation.
- PDF input ceiling100MiB; aggregate500MiB. Phone-memory capacity may be lower.
- Personal documents and signing keys are not stored in this repository.
- The source capsule is source.zip; integrity and inventory are in source-manifest.json.
- Run only the manual private CI workflow using included/free standard Ubuntu runners.
- Build mode produces release and instrumentation APKs. Signing remains on the owner computer.
- Verify-signed mode runs the exact signed release APK and matching test APK on a clean Android emulator.
- Native verification is pending until that workflow actually passes.

## Approved development environment

Unzip source.zip, run npm ci --ignore-scripts, npm run build, npm exec cap sync android, then open android/ in Android Studio. Do not disable operating-system security controls to force a blocked toolchain.

Processing remains on-device. A user-selected Android document provider may itself be a cloud service; its own storage policy applies. No document-processing server, analytics SDK, account login or broad storage permission is included.
