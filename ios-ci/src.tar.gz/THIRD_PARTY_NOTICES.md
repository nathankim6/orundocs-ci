# Third-party notices

PDF Atelier is branded as **옳은영어 김성진T 제작**. Upstream components retain their own licenses and copyright; this credit does not replace their attribution.

- qpdf / @jspawn/qpdf-wasm 0.0.2: Apache-2.0; public/vendor/LICENSE.
- fflate 0.8.3: MIT; public/vendor/fflate-LICENSE.
- PDF.js 5.4.624: Apache-2.0; public/vendor/licenses/pdfjs-LICENSE. CMap and standard-font assets retain upstream notices.
- pdf-lib 1.17.1: MIT; public/vendor/licenses/pdf-lib-LICENSE.
- @pdf-lib/fontkit 1.1.1: MIT; font subset embedding.
- Noto Sans KR: SIL Open Font License 1.1; public/vendor/fonts/OFL.txt and SOURCE.md.
- Electron 44.9.0: MIT and Chromium third-party licenses. Official LICENSE and LICENSES.chromium.html remain in platform packages.
- Windows CPython 3.13.16 / macOS arm64 CPython 3.13.18: original Python licenses remain under resources/runtime/python-export. The macOS standalone distribution provenance is documented in docs/mac-python-runtime.md.
- Document export packages: python-docx, python-pptx, openpyxl, et_xmlfile, lxml, Pillow, typing_extensions and XlsxWriter. Original licenses/notices remain in their bundled dist-info directories; provenance in the platform runtime docs.
- Official LZMA SDK 26.04 installer module: public domain; desktop/build-resources/LZMA-SDK-LICENSE.txt.
- esbuild-wasm, resedit, pe-library and pngjs: MIT development-only tools. 7z-wasm: LGPL plus unRAR restriction, development-only and not part of the installed execution runtime.
- The app icon was generated for this project on Higgsfield using GPT Image 2, then background-trimmed/resized; docs/icon-provenance.md.

OCR engines, OCR model assets and IOPaint/LaMa inpainting are not included in 3.3.0. Optional LibreOffice remains separately installed and licensed. No upstream endorsement is implied.
