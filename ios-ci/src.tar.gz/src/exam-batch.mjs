// Local batch policy and sequential queue, independent of image algorithms.
export const MAX_PAGES = 20, MAX_PHOTO_BYTES = 30 * 1024 * 1024, MAX_BATCH_BYTES = 500 * 1024 * 1024;
export function admission(pages, file) {
  if (pages.length >= MAX_PAGES) return '최대 20장입니다. 21번째 이후 사진은 추가하지 않았습니다.';
  if (!file.size || file.size > MAX_PHOTO_BYTES) return '사진은 0 MB 초과, 30 MiB 이하여야 합니다.';
  if (pages.reduce((n,p) => n + p.file.size, 0) + file.size > MAX_BATCH_BYTES) return '전체 사진 합계 500 MiB를 초과하여 추가하지 않았습니다.';
  return '';
}
export function exportPages(pages, skip = false, dirty = new Set()) {
  const ready = p => !!p.result && p.status === 'done' && !dirty.has(p);
  const missing = pages.filter(p => !ready(p));
  if (missing.length && !skip) throw new Error(missing.length + '장 미완료. 재시도하거나 미완료 제외를 직접 선택해 주세요.');
  const valid = pages.filter(ready);
  if (!valid.length) throw new Error('저장할 완료 페이지가 없습니다.');
  return valid;
}
export async function runBatch(pages, process, { signal, onUpdate = () => {} } = {}) {
  let completed = 0;
  for (const p of pages) {
    if (signal?.aborted) break;
    p.status = 'processing'; p.error = ''; onUpdate(p, completed, pages.length);
    try {
      await process(p, signal);
      if (signal?.aborted) { p.status = 'cancelled'; break; }
      p.status = 'done';
    } catch (e) {
      p.status = signal?.aborted ? 'cancelled' : 'failed'; p.error = e.message || String(e);
    }
    completed++; onUpdate(p, completed, pages.length);
    if (signal?.aborted) break;
  }
  onUpdate(null, completed, pages.length);
  return { completed, cancelled: !!signal?.aborted };
}
export function workerRequest(worker, message, { signal, timeout = 90000 } = {}) {
  return new Promise((resolve, reject) => {
    let timer;
    const finish = (error, result) => {
      clearTimeout(timer); signal?.removeEventListener('abort', abort);
      worker.onmessage = worker.onerror = worker.onmessageerror = null;
      worker.terminate(); error ? reject(error) : resolve(result);
    };
    const abort = () => finish(new Error('처리를 취소했습니다.'));
    if (signal?.aborted) { abort(); return; }
    signal?.addEventListener('abort', abort, { once: true });
    timer = setTimeout(() => finish(new Error('사진 처리 시간 초과. 이 페이지만 다시 시도해 주세요.')), timeout);
    worker.onmessage = ({data}) => { if(data.id === message.id) finish(data.ok ? null : new Error(data.error || '처리 실패'), data); };
    worker.onerror = worker.onmessageerror = () => finish(new Error('이미지 처리 엔진 오류. 다시 시도해 주세요.'));
    try { worker.postMessage(message); } catch (e) { finish(e); }
  });
}
// At most one before/after pair is retained. Serialized decodes dispose stale results.
export class CurrentBitmaps {
  constructor(decode = blob => createImageBitmap(blob)) { this.decode = decode; this.serial = Promise.resolve(); this.version = 0; this.entry = null; }
  clear() { this.version++; this.entry?.before.close?.(); this.entry?.after.close?.(); this.entry = null; }
  async get(p) {
    const result = p.result, version = this.version;
    const task = this.serial.then(async () => {
      if (version !== this.version) return null;
      if (this.entry?.result === result) return this.entry;
      this.entry?.before.close?.(); this.entry?.after.close?.(); this.entry = null;
      let before, after;
      try {
        before = await this.decode(result.before); after = await this.decode(result.after);
        if (version !== this.version || p.result !== result) { before.close?.(); after.close?.(); return null; }
        return this.entry = { before, after, result, page: p };
      } catch(e) { before?.close?.(); after?.close?.(); throw e; }
    });
    this.serial = task.catch(() => {}); return task;
  }
}
