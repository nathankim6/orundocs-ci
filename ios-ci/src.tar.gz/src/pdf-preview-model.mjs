const MAX_HELPER_ITEMS = 100_000;
const MAX_ACTION_PAGES = 500;

function isPage(value) {
  return Number.isSafeInteger(value) && value > 0;
}

function boundedPages(iterable, { total = Infinity, strict = false, limit = MAX_HELPER_ITEMS } = {}) {
  if (iterable == null || typeof iterable[Symbol.iterator] !== 'function') {
    if (strict) throw new TypeError('pages must be iterable');
    return [];
  }

  const pages = [];
  let seen = 0;
  for (const value of iterable) {
    if (++seen > limit) {
      if (strict) throw new RangeError('too many pages');
      break;
    }
    if (!isPage(value) || value > total) {
      if (strict) throw new RangeError('invalid page');
      continue;
    }
    pages.push(value);
  }
  return pages;
}

function validTotal(total, max = MAX_HELPER_ITEMS) {
  return Number.isSafeInteger(total) && total > 0 && total <= max;
}

export function clampZoom(value, min = 0.25, max = 4) {
  const safeMin = Number.isFinite(min) && min > 0 ? min : 0.25;
  const safeMax = Number.isFinite(max) && max >= safeMin ? max : Math.max(4, safeMin);
  const zoom = Number.isFinite(value) ? value : 1;
  return Math.min(safeMax, Math.max(safeMin, zoom));
}

export function zoomFromWheel(current, deltaY, deltaMode = 0) {
  const zoom = clampZoom(current);
  if (!Number.isFinite(deltaY)) return zoom;
  const multiplier = deltaMode === 1 ? 16 : deltaMode === 2 ? 800 : 1;
  const candidate = zoom * Math.exp(-deltaY * multiplier * 0.0015);
  if (candidate === Infinity) return 4;
  if (candidate === 0) return 0.25;
  return clampZoom(candidate);
}

export function applyPageSelection(currentIterable, pagesIterable, { toggle = false, additive = false } = {}) {
  const current = new Set(boundedPages(currentIterable));
  const pages = boundedPages(pagesIterable);
  const result = additive || toggle ? new Set(current) : new Set();

  for (const page of pages) {
    if (toggle) {
      if (result.has(page)) result.delete(page);
      else result.add(page);
    } else {
      result.add(page);
    }
  }
  return result;
}

export function rangePages(anchor, page, total) {
  if (!validTotal(total) || !isPage(anchor) || !isPage(page) || anchor > total || page > total) return [];
  const first = Math.min(anchor, page);
  const last = Math.max(anchor, page);
  return Array.from({ length: last - first + 1 }, (_, index) => first + index);
}

export function pagesInRect(items, rect) {
  if (items == null || typeof items[Symbol.iterator] !== 'function' || rect == null) return [];
  const values = [rect.left, rect.top, rect.right, rect.bottom];
  if (!values.every(Number.isFinite)) return [];
  const left = Math.min(rect.left, rect.right);
  const right = Math.max(rect.left, rect.right);
  const top = Math.min(rect.top, rect.bottom);
  const bottom = Math.max(rect.top, rect.bottom);
  if (left === right || top === bottom) return [];

  const pages = [];
  const found = new Set();
  let count = 0;
  for (const item of items) {
    if (++count > MAX_HELPER_ITEMS) break;
    if (!item || !isPage(item.page)) continue;
    const coords = [item.left, item.top, item.right, item.bottom];
    if (!coords.every(Number.isFinite)) continue;
    const itemLeft = Math.min(item.left, item.right);
    const itemRight = Math.max(item.left, item.right);
    const itemTop = Math.min(item.top, item.bottom);
    const itemBottom = Math.max(item.top, item.bottom);
    const overlaps = Math.min(right, itemRight) > Math.max(left, itemLeft)
      && Math.min(bottom, itemBottom) > Math.max(top, itemTop);
    if (overlaps && !found.has(item.page)) {
      found.add(item.page);
      pages.push(item.page);
    }
  }
  return pages;
}

export function pageSelectionGroups(total, selected) {
  if (!validTotal(total)) return { selected: [], remaining: [] };
  const chosen = [...new Set(boundedPages(selected, { total }))].sort((a, b) => a - b);
  const selectedSet = new Set(chosen);
  const remaining = [];
  for (let page = 1; page <= total; page += 1) {
    if (!selectedSet.has(page)) remaining.push(page);
  }
  return { selected: chosen, remaining };
}

export function pageRanges(pages) {
  const sorted = [...new Set(boundedPages(pages))].sort((a, b) => a - b);
  const ranges = [];
  for (let index = 0; index < sorted.length;) {
    const start = sorted[index];
    let end = start;
    while (sorted[index + 1] === end + 1) end = sorted[++index];
    ranges.push(start === end ? String(start) : `${start}-${end}`);
    index += 1;
  }
  return ranges.join(',');
}

export function buildPageActionPlan(action, pages, total) {
  if (!validTotal(total, MAX_ACTION_PAGES)) throw new RangeError('total must be between 1 and 500');
  if (!['extract', 'separate', 'partition'].includes(action)) throw new TypeError('invalid action');

  const selected = [...new Set(boundedPages(pages, { total, strict: true, limit: MAX_ACTION_PAGES }))]
    .sort((a, b) => a - b);
  if (selected.length === 0) throw new RangeError('select at least one page');

  const ranges = pageRanges(selected);
  if (action === 'extract') {
    return { operation: 'organize', options: { pages: ranges }, labels: ['selected'] };
  }
  if (action === 'separate') {
    return {
      operation: 'split',
      options: { mode: 'each', pages: ranges },
      labels: selected.map((page) => `page-${page}`),
    };
  }

  const { remaining } = pageSelectionGroups(total, selected);
  if (remaining.length === 0) {
    return { operation: 'organize', options: { pages: ranges }, labels: ['selected'] };
  }
  return {
    operation: 'split',
    options: { mode: 'ranges', ranges: `${ranges};${pageRanges(remaining)}` },
    labels: ['selected', 'remaining'],
  };
}
