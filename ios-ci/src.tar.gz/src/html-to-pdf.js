import {PDF_MAX_BYTES,TOTAL_MAX_BYTES} from './file-limits.js';
import { PDFDocument } from 'pdf-lib';
import fontkit from '@pdf-lib/fontkit';

export const AI_PDF_LIMITS = Object.freeze({files:10,fileBytes:PDF_MAX_BYTES,totalBytes:TOTAL_MAX_BYTES,pages:100,characters:100000,htmlBytes:2*1024*1024,outputPages:100,fontBytes:20*1024*1024});
const L=AI_PDF_LIMITS, encoder=new TextEncoder();
let pdfjsPromise;
function fail(code,message,extra={}) { return Object.assign(new Error(message),{code,...extra}); }
function checkAbort(signal) { if(signal?.aborted) throw signal.reason || new DOMException('Cancelled','AbortError'); }
function bounded(n,fallback,max,label,min=1) { n=n===undefined?fallback:Number(n);if(!Number.isInteger(n)||n<min||n>max)throw fail('INVALID_OPTIONS',`${label} must be an integer from ${min} to ${max}.`);return n; }
const safeName=n=>String(n||'document').replace(/\.[^.]*$/,'').replace(/[\\/\x00-\x1f<>:"|?*]/g,'_').slice(0,100)||'document';
function notify(cb,phase,progress,message,extra={}) { cb({phase,progress:Math.max(0,Math.min(1,progress)),message,...extra}); }
async function abortable(promise,signal) {
  checkAbort(signal);if(!signal)return promise;
  let listener;const aborted=new Promise((_,reject)=>{listener=()=>reject(signal.reason||new DOMException('Cancelled','AbortError'));signal.addEventListener('abort',listener,{once:true});});
  try{return await Promise.race([promise,aborted]);}finally{signal.removeEventListener('abort',listener);}
}
async function pdfEngine() {
  if(!pdfjsPromise)pdfjsPromise=import('/vendor/pdfjs/pdf.mjs').then(p=>{p.GlobalWorkerOptions.workerSrc='/vendor/pdfjs/pdf.worker.mjs';return p;}).catch(e=>{pdfjsPromise=null;throw e;});
  return pdfjsPromise;
}
async function extractPdf(file,o,progress) {
  const engine=await pdfEngine();checkAbort(o.signal);
  const bytes=new Uint8Array(await abortable(file.arrayBuffer(),o.signal));
  const loading=engine.getDocument({data:bytes,isEvalSupported:false,disableFontFace:true,cMapUrl:'/vendor/pdfjs/cmaps/',cMapPacked:true,standardFontDataUrl:'/vendor/pdfjs/standard_fonts/'});
  const onAbort=()=>{void loading.destroy();};o.signal?.addEventListener('abort',onAbort,{once:true});
  try {
    const doc=await abortable(loading.promise,o.signal);let text='',readPages=0;
    const cap=Math.min(doc.numPages,o.maxPages);
    for(let p=1;p<=cap&&text.length<o.maxChars;p++) {
      checkAbort(o.signal);const page=await abortable(doc.getPage(p),o.signal);
      try {const content=await abortable(page.getTextContent(),o.signal);
        for(const item of content.items) {if(typeof item.str!=='string')continue;text+=(item.str+(item.hasEOL?'\n':' ')).slice(0,o.maxChars-text.length);if(text.length>=o.maxChars)break;}
        if(text.length<o.maxChars)text+='\n';
      }finally{page.cleanup();}
      readPages=p;notify(progress,'extract',p/cap,`Extracting ${file.name}: page ${p}/${cap}`);
    }
    if(!text.trim())throw fail('NO_TEXT','No embedded PDF text found. Run OCR first, then try again.',{suggestOCR:true});
    return {text:text.trim(),pages:readPages,totalPages:doc.numPages,truncated:readPages<doc.numPages||text.length>=o.maxChars};
  }finally{o.signal?.removeEventListener('abort',onAbort);await loading.destroy();}
}

/** Parse only attribute-free structural HTML, never the original active markup. */
export function htmlToText(html) {
  if(typeof html!=='string'||encoder.encode(html).length>L.htmlBytes)throw fail('INPUT_LIMIT','HTML must be a string no larger than 2 MiB.');
  if(typeof DOMParser==='undefined')throw fail('HTML_PARSER_UNAVAILABLE','This operation requires the browser DOMParser.');
  // Remove raw/non-document content before any DOM exists. Whitelist pass below is
  // the security boundary: not one original attribute or active tag reaches DOMParser.
  let inert=html.replace(/<!--[^]*?(?:-->|$)/g,'').replace(/<(script|style|noscript|iframe|object|svg|math|template|head)\b[^>]*>[^]*?(?:<\/\1\s*>|$)/gi,'');
  const allowed=new Set(['h1','h2','h3','h4','h5','h6','p','div','section','article','main','header','footer','blockquote','pre','ul','ol','li','br','hr','table','thead','tbody','tr','td','th','span','b','strong','i','em','a','code']);
  inert=inert.replace(/<[^]*?(?:>|$)/g,tag=>{const m=tag.match(/^<\s*(\/?)\s*([a-z][a-z0-9]*)\b/i);return m&&allowed.has(m[2].toLowerCase())?`<${m[1]}${m[2].toLowerCase()}>`:'';});
  const doc=new DOMParser().parseFromString(inert,'text/html');
  doc.querySelectorAll('script,style,noscript,iframe,object,embed,img,link,meta,base,form,input,button,textarea,select,svg,math,template').forEach(n=>n.remove());
  const out=[];const block=/^(H[1-6]|P|DIV|SECTION|ARTICLE|MAIN|HEADER|FOOTER|BLOCKQUOTE|PRE|UL|OL|LI|TABLE|TR)$/;
  function walk(node) {
    if(node.nodeType===3){out.push(node.nodeValue);return;}
    if(node.nodeType!==1)return;
    if(block.test(node.tagName))out.push('\n');
    if(node.tagName==='BR'||node.tagName==='HR')out.push('\n');
    for(const child of node.childNodes)walk(child);
    if(node.tagName==='TD'||node.tagName==='TH')out.push('\t');
    if(block.test(node.tagName))out.push('\n');
  }
  walk(doc.body);return out.join('').replace(/[ \t\r\f]+/g,' ').replace(/ *\n */g,'\n').replace(/\n{3,}/g,'\n\n').trim();
}

/** Searchable Unicode text reflow. No source layout, CSS, images or links retained. */
export async function textToPdf(text,options={}) {
  if(typeof text!=='string'||!text.trim()||text.length>L.characters)throw fail('INPUT_LIMIT',`Provide 1-${L.characters} text characters.`);
  checkAbort(options.signal);let fontBytes=options.fontBytes;
  if(fontBytes===undefined) {
    const response=await fetch('/vendor/fonts/noto-sans-kr.ttf',{signal:options.signal,credentials:'same-origin'});
    if(!response.ok)throw fail('FONT_UNAVAILABLE','Local Noto Sans KR font is missing.');
    fontBytes=new Uint8Array(await response.arrayBuffer());
  }
  if(!(fontBytes instanceof Uint8Array)||!fontBytes.length||fontBytes.length>L.fontBytes)throw fail('FONT_UNAVAILABLE','fontBytes must be a nonempty Uint8Array up to 20 MiB.');
  const doc=await PDFDocument.create();doc.registerFontkit(fontkit);
  // Subsetting assigns fresh glyph IDs and avoids duplicate-glyph ToUnicode
  // collisions in the supplied Korean font (notably spaces and ASCII digits).
  const font=await doc.embedFont(fontBytes,{subset:true});
  const supported=new Set(font.getCharacterSet());
  const clean=text.normalize('NFC').replace(/\r\n?/g,'\n').replace(/\t/g,'    ').replace(/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/g,'');
  for(const ch of clean)if(ch!=='\n'&&!supported.has(ch.codePointAt(0)))throw fail('UNSUPPORTED_GLYPH',`Local PDF font cannot represent U+${ch.codePointAt(0).toString(16).toUpperCase()}; use TXT output or provide a compatible fontBytes.`);
  const size=bounded(options.fontSize,11,24,'fontSize',8), margin=42,width=595.28,height=841.89,lineHeight=size*1.55,maxWidth=width-2*margin;
  let page,y;function newPage(){if(doc.getPageCount()>=L.outputPages)throw fail('OUTPUT_LIMIT','Reflow exceeds 100 output pages. Reduce input text.');page=doc.addPage([width,height]);y=height-margin-size;}
  newPage();function line(s){checkAbort(options.signal);if(y<margin)newPage();if(s)page.drawText(s,{x:margin,y,size,font});y-=lineHeight;}
  let steps=0;
  for(const para of clean.split('\n')) {
    let current='',currentWidth=0;
    // Character wrapping supports Korean and long unbroken words without overflow.
    for(const ch of para) {
      const cw=font.widthOfTextAtSize(ch,size);
      if(current&&currentWidth+cw>maxWidth){line(current);current='';currentWidth=0;}
      current+=ch;currentWidth+=cw;
      if(++steps%4096===0){await new Promise(r=>setTimeout(r,0));checkAbort(options.signal);}
    }
    line(current);
  }
  checkAbort(options.signal);const saved=await doc.save();checkAbort(options.signal);return saved;
}

/** Local HTML text reflow only. No model APIs, cloud services, URLs, or visual capture. */
export async function runLocalHtmlToPdf(files,options={},progress=()=>{}) {
  if(!Array.isArray(files)||files.length>10)throw fail('INPUT_LIMIT','Use up to 10 files.');
  if(typeof progress!=='function')throw fail('INVALID_OPTIONS','progress must be a function.');
  if(options.html!==undefined&&files.length)throw fail('INVALID_OPTIONS','Choose uploaded HTML files or options.html, not both.');
  const inputs=options.html!==undefined?[{name:'html-document.html',text:async()=>options.html,size:encoder.encode(String(options.html)).length}]:files;
  if(!inputs.length)throw fail('NO_INPUT','Upload .html/.htm files or provide options.html.');
  let total=0,remaining=L.characters;const result=[];
  for(const file of inputs){
    checkAbort(options.signal);
    if(!file||typeof file.name!=='string'||typeof file.text!=='function'||!Number.isFinite(file.size)||file.size<=0||file.size>L.htmlBytes)throw fail('INPUT_LIMIT','Each HTML file must be nonempty and at most 2 MiB.');
    if(!/\.html?$/i.test(file.name))throw fail('INVALID_FILE','HTML conversion accepts only .html or .htm files, not URLs.');
    total+=file.size;if(total>TOTAL_MAX_BYTES)throw fail('INPUT_LIMIT','Combined inputs exceed 500 MiB.');
    const text=htmlToText(await abortable(file.text(),options.signal));
    if(!text)throw fail('NO_TEXT','HTML contains no usable document text.');
    if(text.length>remaining)throw fail('INPUT_LIMIT','HTML text exceeds the 100000-character combined limit.');
    remaining-=text.length;notify(progress,'pdf',result.length/inputs.length,`Reflowing local HTML text: ${file.name}`);
    result.push({name:`${safeName(file.name)}.pdf`,bytes:await textToPdf(text,options),mime:'application/pdf'});
  }
  notify(progress,'done',1,'HTML text PDF ready');
  return {files:result,summary:'Local HTML text conversion: headings and paragraphs reflowed into searchable Unicode PDF. Scripts, CSS, images, forms, external assets and original layout are not retained. This is not a visual webpage capture.'};
}
