import {PDF_MAX_BYTES,TOTAL_MAX_BYTES,isPdfInput} from './file-limits.js';
import { PDFDocument } from 'pdf-lib';
import { exportOffice } from './native/local-office-export.mjs';

const MAX_PAGES = 100, MAX_FILE = 50 * 1024 * 1024, MAX_TOTAL = TOTAL_MAX_BYTES;
const MAX_OUTPUT = 150 * 1024 * 1024;
const encoder = new TextEncoder();
let pdfjsPromise;
const DISCLAIMERS = {
  markdown: 'Markdown preserves extracted text, page boundaries and heuristic headings, not exact layout. No OCR is performed.',
  'pdf-to-word': 'Word contains extracted paragraphs only, not exact formatting or layout. No OCR is performed.',
  'pdf-to-ppt': 'Each PDF page is a slide background image, not editable text. Mixed page sizes are fitted without cropping.',
  'pdf-to-excel': 'Excel rows and cells are grouped heuristically from text positions, not perfect table reconstruction. No OCR is performed.'
};
const IDS = ['pdf-to-images','images-to-pdf','scan','markdown','pdf-to-word','pdf-to-ppt','pdf-to-excel'];
const safeName = name => String(name || 'document').replace(/\.[^.]*$/, '').replace(/[\\/\x00-\x1f<>:"|?*]/g, '_').slice(0,120) || 'document';
function number(value, fallback, min, max, label) {
  const n = value === undefined ? fallback : Number(value);
  if (!Number.isFinite(n) || n < min || n > max) throw Error(`${label} must be between ${min} and ${max}.`);
  return n;
}
function choice(value, fallback, values, label) {
  const v = value === undefined ? fallback : value;
  if (!values.includes(v)) throw Error(`Invalid ${label}: use ${values.join(', ')}.`);
  return v;
}
function normalizeOptions(options) {
  const o = {...options};
  o.maxDimension = Math.round(number(o.maxDimension,1400,1000,1600,'maxDimension'));
  o.format = choice(o.format,'png',['png','jpeg'],'format');
  o.quality = number(o.quality,0.9,0.5,1,'quality');
  o.pageSize = choice(o.pageSize,'A4',['A4','original'],'pageSize');
  o.orientation = choice(o.orientation,'auto',['auto','portrait','landscape'],'orientation');
  o.margin = number(o.margin,24,0,200,'margin');
  o.enhancement = choice(o.enhancement,'none',['none','grayscale','threshold'],'enhancement');
  o.threshold = o.threshold === undefined || o.threshold === 'auto' ? 'auto' : number(o.threshold,128,0,255,'threshold');
  if (o.pages !== undefined && (!Array.isArray(o.pages) || !o.pages.length || o.pages.some(p=>!Number.isInteger(p)||p<1))) throw Error('pages must be a nonempty array of one-based page numbers.');
  return o;
}
async function pdfEngine() {
  if (!pdfjsPromise) pdfjsPromise = import('/vendor/pdfjs/pdf.mjs').then(engine => {
    engine.GlobalWorkerOptions.workerSrc = '/vendor/pdfjs/pdf.worker.mjs';
    return engine;
  }).catch(e=>{pdfjsPromise=null;throw e;});
  return pdfjsPromise;
}
function canvasOf(width,height) {
  const canvas=document.createElement('canvas');
  canvas.width=Math.max(1,Math.round(width)); canvas.height=Math.max(1,Math.round(height));
  return canvas;
}
async function canvasBytes(canvas,mime='image/png',quality=0.9) {
  const blob=await new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(Error('Image encoding failed.')),mime,quality));
  return new Uint8Array(await blob.arrayBuffer());
}
function base64(bytes) {
  let s='';for(let i=0;i<bytes.length;i+=32768)s+=String.fromCharCode(...bytes.subarray(i,i+32768));return btoa(s);
}
async function renderPage(page,o) {
  const raw=page.getViewport({scale:1});
  if (!(raw.width>0&&raw.height>0)) throw Error('Invalid PDF page dimensions.');
  const view=page.getViewport({scale:o.maxDimension/Math.max(raw.width,raw.height)});
  const canvas=canvasOf(view.width,view.height);
  try { await page.render({canvasContext:canvas.getContext('2d'),viewport:view,background:'#ffffff'}).promise;return canvas; }
  catch(e){canvas.width=canvas.height=1;throw e;}
}
// Coordinates are top-left viewport points. Grouping deliberately remains heuristic.
export function groupTextLines(items,viewport,transform) {
  const spans=items.filter(i=>typeof i.str==='string'&&i.str.trim()).map(i=>{
    const t=transform(viewport.transform,i.transform);
    const h=Math.max(1,Math.hypot(t[2],t[3]));
    return {text:i.str,x:t[4],y:t[5]-h,width:Math.abs(i.width||0),height:h,fontSize:h};
  }).sort((a,b)=>a.y-b.y||a.x-b.x);
  const lines=[];
  for(const span of spans){
    let line=lines.length?lines[lines.length-1]:null;
    if(!line||Math.abs(line.y-span.y)>Math.max(2,Math.min(line.height,span.height)*0.4)){
      line={text:'',x:span.x,y:span.y,width:span.width,height:span.height,fontSize:span.fontSize,cells:[],spans:[]};lines.push(line);
    }
    line.spans.push(span);line.height=Math.max(line.height,span.height);line.fontSize=Math.max(line.fontSize,span.fontSize);
  }
  for(const line of lines){
    line.spans.sort((a,b)=>a.x-b.x);let cell='',previous=null;
    for(const s of line.spans){
      const gap=previous?s.x-(previous.x+previous.width):0;
      if(previous&&gap>Math.max(12,line.fontSize*1.5)){line.cells.push(cell.trim());cell='';}
      const separator=cell&&gap>line.fontSize*0.12&&!/\s$/.test(cell)&&!/^\s/.test(s.text)?' ':'';
      cell+=separator+s.text;previous=s;
    }
    if(cell.trim())line.cells.push(cell.trim());
    line.text=line.cells.join('  ');line.x=line.spans[0].x;line.width=Math.max(...line.spans.map(s=>s.x+s.width))-line.x;
  }
  return lines;
}
function paragraphs(lines) {
  const out=[];let current='',previous=null;
  for(const line of lines){
    const gap=previous?line.y-previous.y:0;
    if(current&&(gap>Math.max(line.height,previous.height)*1.6||line.fontSize>previous.fontSize*1.2||previous.fontSize>line.fontSize*1.2)) {out.push(current);current='';}
    current+=(current?' ':'')+line.text;previous=line;
  }
  if(current)out.push(current);return out;
}
function markdownEscape(text){return text.replace(/([\\`*_{}\[\]<>#|])/g,'\\$1');}
export function pagesToMarkdown(pages,name) {
  let out=`# ${markdownEscape(name)}\n\n> Text extraction with heuristic headings; not exact PDF layout.\n`;
  for(const p of pages){
    out+=`\n---\n\n## Page ${p.page}\n\n`;
    if(!p.text.trim()){out+='[No embedded text on this page. OCR is required for scanned content.]\n';continue;}
    const heights=p.lines.map(l=>l.fontSize).sort((a,b)=>a-b), median=heights[Math.floor(heights.length/2)]||12;
    let buffer=[];const flush=()=>{if(buffer.length){out+=paragraphs(buffer).map(markdownEscape).join('\n\n')+'\n\n';buffer=[];}};
    for(const line of p.lines){
      const heading=line.text.length<140&&(line.fontSize>=median*1.25||(/^[\p{Lu}\d\s:.,()\-]+$/u.test(line.text)&&line.text.length>3&&line.text.length<70));
      if(heading){flush();out+=`### ${markdownEscape(line.text)}\n\n`;}else buffer.push(line);
    }
    flush();
  }
  return out;
}
function otsu(data) {
  const histogram=new Uint32Array(256);let total=0,sum=0;
  for(let i=0;i<data.length;i+=4){const gray=Math.round(.2126*data[i]+.7152*data[i+1]+.0722*data[i+2]);histogram[gray]++;total++;sum+=gray;}
  let background=0,backgroundSum=0,best=-1,threshold=127;
  for(let t=0;t<256;t++){background+=histogram[t];if(!background)continue;const foreground=total-background;if(!foreground)break;backgroundSum+=t*histogram[t];const difference=backgroundSum/background-(sum-backgroundSum)/foreground;const variance=background*foreground*difference*difference;if(variance>best){best=variance;threshold=t;}}
  return threshold;
}
async function imageCanvas(file,o,enhance) {
  if(!/^image\/(png|jpeg|webp)$/.test(file.type)&&! /\.(png|jpe?g|webp)$/i.test(file.name))throw Error('Choose PNG, JPEG or WebP images.');
  const bitmap=await createImageBitmap(file);let canvas;
  try {
    if(!bitmap.width||!bitmap.height||bitmap.width*bitmap.height>40000000)throw Error('Images must contain at most 40 million pixels.');
    const scale=Math.min(1,o.maxDimension/Math.max(bitmap.width,bitmap.height));canvas=canvasOf(bitmap.width*scale,bitmap.height*scale);
    const ctx=canvas.getContext('2d',{willReadFrequently:enhance});ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(bitmap,0,0,canvas.width,canvas.height);
    if(enhance&&o.enhancement!=='none'){
      const image=ctx.getImageData(0,0,canvas.width,canvas.height),d=image.data;
      const cutoff=o.threshold==='auto'?otsu(d):o.threshold;
      for(let i=0;i<d.length;i+=4){let gray=Math.round(.2126*d[i]+.7152*d[i+1]+.0722*d[i+2]);if(o.enhancement==='threshold')gray=gray<=cutoff?0:255;d[i]=d[i+1]=d[i+2]=gray;d[i+3]=255;}ctx.putImageData(image,0,0);
    }
    return {canvas,width:bitmap.width,height:bitmap.height};
  }catch(e){if(canvas)canvas.width=canvas.height=1;throw e;}finally{bitmap.close();}
}
async function imagePDF(files,o,notify,scan) {
  const pdf=await PDFDocument.create();
  for(let i=0;i<files.length;i++){
    notify(i,files.length,`Preparing image ${i+1} of ${files.length}`);
    const {canvas,width,height}=await imageCanvas(files[i],o,scan);
    try{
      const image=await pdf.embedPng(await canvasBytes(canvas));
      let [w,h]=o.pageSize==='A4'?[595.28,841.89]:[width*.75+o.margin*2,height*.75+o.margin*2];
      const landscape=o.orientation==='landscape'||o.orientation==='auto'&&width>height;
      if(landscape&&w<h||!landscape&&w>h)[w,h]=[h,w];
      const availableW=w-o.margin*2,availableH=h-o.margin*2;
      if(availableW<=0||availableH<=0)throw Error('Margins leave no room for this image.');
      const scale=Math.min(availableW/image.width,availableH/image.height),iw=image.width*scale,ih=image.height*scale;
      pdf.addPage([w,h]).drawImage(image,{x:(w-iw)/2,y:(h-ih)/2,width:iw,height:ih});
    }finally{canvas.width=canvas.height=1;}
  }
  return {name:`${safeName(files[0].name)}-${scan?'scan':'images'}.pdf`,bytes:await pdf.save(),mime:'application/pdf'};
}
/** Browser-only operations. Progress receives {completed,total,percent,message}. */
export async function runConvertOp(id,files,options={},progress=()=>{}) {
  if(!IDS.includes(id))throw Error(`Unknown conversion: ${id}`);
  if(!Array.isArray(files)||!files.length)throw Error('Choose at least one input file.');
  if(files.length>MAX_PAGES)throw Error('At most 100 files/pages per conversion.');
  if(files.some(f=>!f||typeof f.arrayBuffer!=='function'||f.size>(isPdfInput(f)?PDF_MAX_BYTES:MAX_FILE)))throw Error('Each PDF must be at most 100 MB; images at most 50 MB.');
  if(files.reduce((n,f)=>n+f.size,0)>MAX_TOTAL)throw Error('Combined inputs must be at most 500 MB.');
  const o=normalizeOptions(options),output=[],data=[];let outputSize=0;
  const notify=(completed,total,message)=>progress({completed,total,percent:Math.round(100*completed/Math.max(1,total)),message});
  const add=file=>{outputSize+=file.bytes.byteLength;if(outputSize>MAX_OUTPUT)throw Error('Output exceeds 150 MB. Select fewer pages or use JPEG.');output.push(file);};
  notify(0,1,'Starting local conversion');
  if(id==='images-to-pdf'||id==='scan'){
    add(await imagePDF(files,o,notify,id==='scan'));notify(1,1,'Complete');
    return {files:output,summary:`Created ${files.length}-page PDF, one image per page. ${id==='scan'?`Enhancement: ${o.enhancement}. No OCR, deskew or perspective correction is performed.`:'Images are fitted without cropping; raster dimensions are bounded to '+o.maxDimension+' pixels.'}`};
  }
  const engine=await pdfEngine();let totalPages=0;
  for(let fileIndex=0;fileIndex<files.length;fileIndex++){
    const file=files[fileIndex];
    if(file.type!=='application/pdf'&&!/\.pdf$/i.test(file.name))throw Error('This conversion requires PDF input.');
    const name=safeName(file.name)+(files.length>1?`-${fileIndex+1}`:'');
    const task=engine.getDocument({data:new Uint8Array(await file.arrayBuffer()),isEvalSupported:false,useSystemFonts:true,cMapUrl:'/vendor/pdfjs/cmaps/',cMapPacked:true,standardFontDataUrl:'/vendor/pdfjs/standard_fonts/',wasmUrl:'/vendor/pdfjs/wasm/'});
    let pdf;
    try{
      pdf=await task.promise;totalPages+=pdf.numPages;
      if(totalPages>MAX_PAGES)throw Error('PDF inputs must contain at most 100 pages in total. Split the PDF first.');
      const selected=o.pages?[...new Set(o.pages)].sort((a,b)=>a-b):Array.from({length:pdf.numPages},(_,i)=>i+1);
      if(selected.some(p=>p>pdf.numPages))throw Error(`Selected page exceeds ${file.name}'s ${pdf.numPages} pages.`);
      const pages=[];let pagePayloadSize=0;
      for(let index=0;index<selected.length;index++){
        const pageNumber=selected[index];notify(index,selected.length,`${file.name}: page ${pageNumber} (${fileIndex+1}/${files.length} files)`);
        const page=await pdf.getPage(pageNumber);
        try{
          const view=page.getViewport({scale:1});const entry={page:pageNumber,width:view.width,height:view.height,text:'',lines:[]};
          if(id!=='pdf-to-images'&&id!=='pdf-to-ppt'){
            const content=await page.getTextContent();entry.lines=groupTextLines(content.items,view,engine.Util.transform);
            entry.text=paragraphs(entry.lines).join('\n\n');
          }
          if(id==='pdf-to-images'||id==='pdf-to-ppt'){
            const canvas=await renderPage(page,o);
            try{
              const mime=id==='pdf-to-ppt'?'image/png':`image/${o.format}`;
              const bytes=await canvasBytes(canvas,mime,o.quality);
              if(id==='pdf-to-images')add({name:`${name}-page-${String(pageNumber).padStart(3,'0')}.${o.format==='jpeg'?'jpg':'png'}`,bytes,mime});
              else{entry.image=base64(bytes);pagePayloadSize+=entry.image.length;if(pagePayloadSize>MAX_TOTAL*.95)throw Error('Slide image payload is too large. Select fewer pages.');}
            }finally{canvas.width=canvas.height=1;}
          }
          pages.push(entry);
        }finally{page.cleanup();}
      }
      if(!['pdf-to-images','pdf-to-ppt'].includes(id)&&!pages.some(p=>p.text.trim()))throw Error('No embedded text was found. This may be a scanned PDF. Run OCR first, then export a searchable PDF.');
      if(id==='markdown')add({name:`${name}.md`,bytes:encoder.encode(pagesToMarkdown(pages,name)),mime:'text/markdown;charset=utf-8'});
      const kind={'pdf-to-word':'docx','pdf-to-ppt':'pptx','pdf-to-excel':'xlsx'}[id];
      if(kind){notify(selected.length,selected.length,'Creating Office file locally on this device');add(await exportOffice(kind,name,pages,o));}
      if(!['pdf-to-images','pdf-to-ppt'].includes(id)&&pages.some(p=>!p.text.trim()))data.push({name,warning:'Some pages have no embedded text and require OCR.',pagesWithoutText:pages.filter(p=>!p.text.trim()).map(p=>p.page)});
    }catch(e){if(e.name==='PasswordException')throw Error('This PDF is password-protected. Unlock it first.');throw e;}
    finally{if(pdf)await pdf.destroy();else await task.destroy();}
  }
  notify(1,1,'Complete');
  return {files:output,summary:`Created ${output.length} file(s). ${DISCLAIMERS[id]||'Rendered complete PDF pages, not extracted embedded images.'}${data.some(d=>d.warning)?' Some pages contain no embedded text; OCR is needed for those pages.':''}`,data};
}
