export const localCapabilities = Object.freeze({
  local: true,
  export: Object.freeze({available: true, kinds: Object.freeze(['docx','pptx','xlsx']), reason: '기기 내 Office 내보내기'}),
  officeToPdf: Object.freeze({available: false}),
  ocr: Object.freeze({available: false}),
  pdfa: Object.freeze({available: false}),
  ai: Object.freeze({available: false})
});
