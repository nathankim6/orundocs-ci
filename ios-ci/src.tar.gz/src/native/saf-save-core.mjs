export const MAX_SOURCE_BYTES = 100 * 1024 * 1024;
export const MAX_SAVE_BYTES = 500 * 1024 * 1024;
export const MAX_CHUNK_BYTES = 128 * 1024;

/** Encode only one bounded chunk at a time; no spread/apply argument expansion. */
export function chunkToBase64(bytes) {
  let binary = '';
  // A small loop prevents huge function-argument lists and bounds this temporary string.
  for (let i = 0; i < bytes.length; i += 1) binary += String.fromCharCode(bytes[i]);
  if (typeof btoa !== 'function') throw new Error('This runtime does not provide btoa');
  return btoa(binary);
}

function requireBytes(value, label) {
  if (!(value instanceof Uint8Array)) throw new TypeError(`${label} must be a Uint8Array`);
  return value;
}

/**
 * Save an already-produced result using the supplied Capacitor plugin proxy.
 * A cancellation from beginSave is a normal result, not an exception.
 */
export async function saveResultWithPlugin(plugin, result, options = {}) {
  if (!plugin || typeof plugin.beginSave !== 'function') throw new TypeError('A SAF plugin is required');
  if (!result || typeof result.name !== 'string' || typeof result.mime !== 'string') {
    throw new TypeError('result must include name and mime');
  }
  const bytes = requireBytes(result.bytes, 'result.bytes');
  const sourceBytes = options.sourceBytes ?? result.sourceBytes;
  if (sourceBytes != null && (!Number.isSafeInteger(sourceBytes) || sourceBytes < 0 || sourceBytes > MAX_SOURCE_BYTES)) {
    throw new RangeError('sourceBytes exceeds the 100 MiB source policy');
  }
  if (bytes.byteLength > MAX_SAVE_BYTES) throw new RangeError('result exceeds the 500 MiB SAF save cap');

  const started = await plugin.beginSave({
    suggestedName: result.name,
    mime: result.mime,
    expectedBytes: bytes.byteLength,
  });
  if (started?.cancelled) return { cancelled: true };
  if (!started?.id) throw new Error('SAF plugin returned no save id');

  const id = started.id;
  const onProgress = options.onProgress;
  try {
    let index = 0;
    for (let offset = 0; offset < bytes.byteLength; offset += MAX_CHUNK_BYTES) {
      const chunk = bytes.subarray(offset, Math.min(offset + MAX_CHUNK_BYTES, bytes.byteLength));
      await plugin.writeChunk({ id, base64: chunkToBase64(chunk), index });
      index += 1;
      if (onProgress) onProgress({ writtenBytes: offset + chunk.byteLength, totalBytes: bytes.byteLength });
    }
    return await plugin.finishSave({ id });
  } catch (error) {
    try { await plugin.abortSave({ id }); } catch (_) { /* preserve the original write/finalize error */ }
    throw error;
  }
}
