import { Capacitor } from '@capacitor/core';
import { saveResultFile } from './saf-save-adapter.mjs';
import { createResultSaver } from './save-bridge-core.mjs';
// Both frontend entry points import this singleton through an esbuild shared chunk.
export const saveOutput = createResultSaver({
  // Android: SAF document picker. iOS: Files export sheet. Same AtelierSaf contract.
  isNativeAndroid: () => Capacitor.isNativePlatform() && ['android', 'ios'].includes(Capacitor.getPlatform()),
  nativeSave: saveResultFile,
  browserSave: async result => {
    const url = URL.createObjectURL(new Blob([result.bytes], {type: result.mime}));
    const anchor = document.createElement('a');
    anchor.href = url; anchor.download = result.name;
    document.body.append(anchor);
    try { anchor.click(); } finally { anchor.remove(); setTimeout(() => URL.revokeObjectURL(url), 60000); }
    return {cancelled: false};
  }
});
