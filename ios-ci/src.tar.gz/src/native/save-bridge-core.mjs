/** A single shared gate prevents overlapping native pickers/writes, including across workspaces. */
export function createResultSaver({isNativeAndroid, nativeSave, browserSave}) {
  let saving = false;
  return async function saveOutput(result, options = {}) {
    if (saving) throw new Error('다른 파일을 저장하고 있습니다. 저장을 마친 뒤 다시 시도해 주세요.');
    saving = true;
    try {
      if (!isNativeAndroid()) return await browserSave(result);
      // SAF requires a concrete bare MIME. Only metadata changes; UTF-8 bytes stay untouched.
      const mime = String(result?.mime || '').split(';', 1)[0].toLowerCase();
      // Reject whitespace explicitly: JavaScript $ otherwise also matches before a final newline.
      if (/\s/.test(mime) || !/^[a-z0-9][a-z0-9!#$&^_.+-]*\/[a-z0-9][a-z0-9!#$&^_.+-]*$/i.test(mime)) {
        throw new Error('저장할 파일의 MIME 형식이 올바르지 않습니다.');
      }
      return await nativeSave(mime === result.mime ? result : {...result, mime}, options);
    }
    finally { saving = false; }
  };
}
