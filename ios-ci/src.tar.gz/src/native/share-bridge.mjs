import { Capacitor, registerPlugin } from '@capacitor/core';
import { chunkToBase64, MAX_CHUNK_BYTES } from './saf-save-core.mjs';

const AtelierShare = registerPlugin('AtelierShare');
const MIME = /^[a-z0-9!#$&^_.+-]+\/[a-z0-9!#$&^_.+-]+$/;

/** Share already-produced result files through the Android share sheet (local cache + FileProvider only). */
export async function shareFiles(files, { plugin = AtelierShare, title = 'OrunDocs 공유' } = {}) {
  if (!(Capacitor.isNativePlatform() && ['android', 'ios'].includes(Capacitor.getPlatform()))) throw new Error('이 환경에서는 시스템 공유를 사용할 수 없습니다.');
  if (!Array.isArray(files) || !files.length || files.length > 20) throw new Error('공유할 파일은 1~20개여야 합니다.');
  await plugin.reset();
  const ids = [];
  for (const f of files) {
    const mime = String(f.mime || '').toLowerCase().split(';')[0].trim();
    if (!MIME.test(mime) || !(f.bytes instanceof Uint8Array)) throw new Error('공유할 파일 형식이 올바르지 않습니다.');
    const { id } = await plugin.beginFile({ name: f.name, mime, expectedBytes: f.bytes.byteLength });
    let index = 0;
    for (let off = 0; off < f.bytes.byteLength; off += MAX_CHUNK_BYTES) {
      await plugin.writeChunk({ id, index: index++, base64: chunkToBase64(f.bytes.subarray(off, Math.min(off + MAX_CHUNK_BYTES, f.bytes.byteLength))) });
    }
    await plugin.finishFile({ id });
    ids.push(id);
  }
  return plugin.share({ ids, title });
}
