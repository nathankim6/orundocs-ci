import {PDF_MAX_BYTES} from './file-limits.js';
import { PDFDocument, StandardFonts, rgb, PDFName } from 'pdf-lib';

// All public coordinates are PDF points, relative to the unrotated lower-left.
const MAX_BYTES = 40 * 1024 * 1024, MAX_PAGES = 100;
let rendererPromise;
async function renderer() {
  rendererPromise ||= import('/vendor/pdfjs/pdf.mjs').then(p => {
    p.GlobalWorkerOptions.workerSrc = '/vendor/pdfjs/pdf.worker.mjs'; return p;
  });
  return rendererPromise;
}
const enc = new TextEncoder();
const fail = message => { throw new Error(message); };
function number(value, fallback, min = -100000, max = 100000) {
  const n = value === undefined ? fallback : Number(value);
  if (!Number.isFinite(n) || n < min || n > max) fail(`Number must be between ${min} and ${max}.`);
  return n;
}
function name(file, suffix, ext = 'pdf') {
  return `${String(file?.name || 'document').replace(/\.[^.]+$/, '').replace(/[\\/\x00-\x1f]/g, '_')}-${suffix}.${ext}`;
}
function out(name, bytes, mime = 'application/pdf') { return { name, bytes: bytes instanceof Uint8Array ? bytes : enc.encode(bytes), mime }; }
async function input(file, isImage = false) {
  const limit = isImage ? MAX_BYTES : PDF_MAX_BYTES;
  if (!file?.arrayBuffer) fail('Choose a PDF file.');
  if (file.size > limit) fail(isImage ? 'Image must be 40 MB or smaller.' : 'Each PDF must be 100 MB or smaller.');
  const bytes = new Uint8Array(await file.arrayBuffer());
  if (bytes.length > limit) fail(isImage ? 'Image must be 40 MB or smaller.' : 'Each PDF must be 100 MB or smaller.');
  return bytes;
}
async function load(bytes) {
  let doc;
  try { doc = await PDFDocument.load(bytes, { updateMetadata: false }); }
  catch (e) { fail(`Cannot open PDF. Unlock encrypted PDFs first. ${e.message}`); }
  if (doc.getPageCount() > MAX_PAGES) fail(`Maximum ${MAX_PAGES} pages. Split this PDF first.`);
  if (!doc.getPageCount()) fail('The PDF has no pages.');
  return doc;
}
function pages(value, count, fallback = 'all') {
  value ??= fallback;
  if (value === 'all' || value === '') return Array.from({ length: count }, (_, i) => i + 1);
  let list = [];
  if (Array.isArray(value)) list = value;
  else for (const part of String(value).split(',')) {
    const match = part.trim().match(/^(\d+)(?:\s*-\s*(\d+))?$/);
    if (!match) fail('Pages must be one-based numbers or ranges, for example 1,3-5.');
    const a = Number(match[1]), b = Number(match[2] || a);
    if (b < a || b > count) fail('Page range is outside the document.');
    for (let p = a; p <= b; p++) list.push(p);
  }
  list = [...new Set(list.map(Number))];
  if (!list.length || list.some(p => !Number.isInteger(p) || p < 1 || p > count)) fail('Page number is outside the document.');
  return list;
}
function singlePage(value, count) {
  const p = number(value, 1, 1, count);
  if (!Number.isInteger(p)) fail('Page must be a one-based integer.');
  return p;
}
function color(value = '#000000') {
  if (!/^#[0-9a-f]{6}$/i.test(value)) fail('Color must be #RRGGBB.');
  return rgb(...[1, 3, 5].map(i => parseInt(value.slice(i, i + 2), 16) / 255));
}
function canvas(w, h) {
  if (typeof document === 'undefined') fail('This operation requires a browser canvas.');
  const c = document.createElement('canvas'); c.width = Math.ceil(w); c.height = Math.ceil(h);
  if (!c.width || !c.height || c.width * c.height > 17000000) fail('Canvas size exceeds the safety limit.');
  return c;
}
async function png(c) { return new Uint8Array(await (await new Promise((resolve, reject) => c.toBlob(b => b ? resolve(b) : reject(Error('PNG encoding failed.')), 'image/png'))).arrayBuffer()); }
async function renderDoc(bytes) {
  const p = await renderer();
  return p.getDocument({ data: bytes.slice(), useSystemFonts: true, isEvalSupported: false, cMapUrl: '/vendor/pdfjs/cmaps/', cMapPacked: true, standardFontDataUrl:'/vendor/pdfjs/standard_fonts/',wasmUrl:'/vendor/pdfjs/wasm/' }).promise;
}
async function renderPage(doc, index, maxDimension = 1600) {
  const p = await doc.getPage(index), raw = p.getViewport({ scale: 1 });
  const viewport = p.getViewport({ scale: Math.min(3, maxDimension / Math.max(raw.width, raw.height)) });
  const c = canvas(viewport.width, viewport.height), ctx = c.getContext('2d', { willReadFrequently: true });
  await p.render({ canvasContext: ctx, viewport, background: '#ffffff' }).promise;
  return { canvas: c, viewport, page: p };
}
async function image(doc, file, dataURL) {
  let bytes;
  if (dataURL) {
    if (typeof dataURL !== 'string' || !/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(dataURL) || dataURL.length > MAX_BYTES * 1.4) fail('signaturePng must be a bounded PNG base64 data URL.');
    bytes = Uint8Array.from(atob(dataURL.split(',')[1]), c => c.charCodeAt(0));
  } else bytes = await input(file, true);
  // Decode dimensions first to prevent huge image allocations during embedding.
  const bitmap = await createImageBitmap(new Blob([bytes]));
  const pixels = bitmap.width * bitmap.height; bitmap.close();
  if (pixels > 16000000) fail('Image must be 16 megapixels or smaller.');
  if (bytes[0] === 137 && bytes[1] === 80) return doc.embedPng(bytes);
  if (bytes[0] === 255 && bytes[1] === 216) return doc.embedJpg(bytes);
  fail('Only PNG and JPEG images are supported.');
}
async function drawText(doc, page, text, options) {
  if (text.length > 10000) fail('Text overlay is limited to 10,000 characters.');
  const x = number(options.x, 40), y = number(options.y, 40), size = number(options.fontSize, 18, 4, 200);
  const fill = color(options.color);
  if (/[^\x20-\x7e\r\n]/.test(text)) {
    // Browser/system fonts support Korean without external fonts or network calls.
    const lines = text.split(/\r?\n/), measure = canvas(1, 1).getContext('2d');
    measure.font = `${size * 3}px sans-serif`;
    const w = Math.max(1, ...lines.map(t => measure.measureText(t).width)) + 12;
    const h = lines.length * size * 3 * 1.4 + 12, c = canvas(w, h), ctx = c.getContext('2d');
    ctx.font = measure.font; ctx.fillStyle = options.color || '#000000'; ctx.textBaseline = 'alphabetic';
    lines.forEach((line, i) => ctx.fillText(line, 6, 6 + size * 3 + i * size * 3 * 1.4));
    const img = await doc.embedPng(await png(c));
    page.drawImage(img, { x: x - 2, y: y - (h - 6 - size * 3) / 3, width: w / 3, height: h / 3 });
  } else {
    const font = await doc.embedFont(StandardFonts.Helvetica);
    page.drawText(text, { x, y, size, font, color: fill, lineHeight: size * 1.4 });
  }
}
async function overlay(id, files, options, progress) {
  const doc = await load(await input(files[0]));
  const chosen = id === 'sign' ? [singlePage(options.page, doc.getPageCount())] : pages(options.pages, doc.getPageCount());
  const text = String(options.text || '');
  if (!text && !files[1] && !options.signaturePng) fail('Provide overlay text or a PNG/JPEG image.');
  const img = files[1] || (id === 'sign' && options.signaturePng) ? await image(doc, files[1], options.signaturePng) : null;
  for (let i = 0; i < chosen.length; i++) {
    const page = doc.getPage(chosen[i] - 1);
    if (text) await drawText(doc, page, text, options);
    if (img) {
      const width = number(options.width, 160, 1, 5000), height = number(options.height, width * img.height / img.width, 1, 5000);
      page.drawImage(img, { x: number(options.x, 40), y: number(options.y, 40), width, height });
    }
    progress((i + 1) / chosen.length, `Page ${chosen[i]}`);
  }
  return { files: [out(name(files[0], id), await doc.save())], summary: id === 'sign' ? `Visible signature added to page ${chosen[0]}. This is NOT a certified digital signature and provides no identity verification.` : `Added overlays on ${chosen.length} page(s). Existing content is preserved; overlays do not remove underlying text. Unicode/Korean text is a raster overlay using installed system fonts.` };
}
function getFieldInfo(field) {
  const type = field.constructor.name;
  let value = null;
  if (field.getText) value = field.getText() ?? '';
  else if (field.isChecked) value = field.isChecked();
  else if (field.getSelected) value = field.getSelected();
  return { name: field.getName(), type, value, readOnly: field.isReadOnly(), ...(field.getOptions ? { options: field.getOptions() } : {}) };
}
async function forms(files, options, progress) {
  const doc = await load(await input(files[0]));
  const form = doc.getForm(), action = options.action || 'inspect';
  if (form.hasXFA()) fail('XFA forms are not supported. Use the source application to export a standard AcroForm PDF.');
  if (action === 'inspect') {
    const fields = form.getFields().map(getFieldInfo), report = { fields, limitations: 'AcroForm fields only. PDF.js rendering and XFA support are limited; XFA is rejected. Existing digital signatures are not validated.' };
    return { files: [out(name(files[0], 'fields', 'json'), JSON.stringify(report, null, 2), 'application/json')], fields, summary: `Found ${fields.length} AcroForm field(s). XFA is not supported.` };
  }
  if (action === 'fill') {
    if (!options.values || typeof options.values !== 'object' || Array.isArray(options.values)) fail('values must be an object keyed by existing field names.');
    for (const [key, value] of Object.entries(options.values)) {
      const field = form.getField(key);
      if (field.isReadOnly()) fail(`Field ${key} is read-only.`);
      if (field.setText) {
        if (/[^\x20-\x7e\r\n]/.test(String(value ?? ''))) fail('Form values currently support ASCII only. Korean overlay text is available in Edit, not interactive forms.');
        field.setText(String(value ?? ''));
      } else if (field.check && field.uncheck) {
        if (typeof value !== 'boolean') fail(`Checkbox ${key} requires true or false.`);
        value ? field.check() : field.uncheck();
      } else if (field.select) {
        if (value === null && field.clear) field.clear(); else field.select(value);
      } else fail(`Unsupported field type: ${field.constructor.name}.`);
    }
  } else if (action === 'create') {
    if (!Array.isArray(options.fields) || !options.fields.length || options.fields.length > 100) fail('fields must contain 1–100 field definitions.');
    for (const spec of options.fields) {
      if (typeof spec.name !== 'string' || !spec.name.trim() || spec.name.length > 200) fail('Each field requires a nonempty name, maximum 200 characters.');
      const pageNumber = singlePage(spec.page, doc.getPageCount()), page = doc.getPage(pageNumber - 1);
      const box = { x: number(spec.x, 40, 0), y: number(spec.y, 40, 0), width: number(spec.width, spec.type === 'checkbox' ? 20 : 180, 1, 5000), height: number(spec.height, spec.type === 'checkbox' ? 20 : 28, 1, 5000), borderWidth: 1 };
      if (box.x + box.width > page.getWidth() || box.y + box.height > page.getHeight()) fail('Field rectangle is outside its page.');
      if (spec.type === 'checkbox') {
        const field = form.createCheckBox(spec.name); field.addToPage(page, box);
        if (spec.value === true) field.check();
      } else if (!spec.type || spec.type === 'text') {
        const field = form.createTextField(spec.name);
        if (spec.multiline) field.enableMultiline();
        if (/[^\x20-\x7e\r\n]/.test(String(spec.value ?? ''))) fail('Form values currently support ASCII only.');
        field.setText(String(spec.value ?? '')); field.addToPage(page, box); field.setFontSize(number(spec.fontSize, 12, 4, 100));
      } else fail('Only text and checkbox field creation is supported.');
    }
  } else fail('Forms action must be inspect, fill, or create.');
  form.updateFieldAppearances(await doc.embedFont(StandardFonts.Helvetica));
  const fields = form.getFields().map(getFieldInfo);
  if (options.flatten === true) form.flatten();
  progress(1, 'Forms complete');
  return { files: [out(name(files[0], 'forms'), await doc.save())], fields, summary: `${action === 'create' ? 'Created' : 'Filled'} AcroForm fields${options.flatten ? ' and permanently flattened field appearances' : ''}. XFA is unsupported. Changes invalidate existing digital signatures.` };
}
async function redact(files, options, progress) {
  const bytes = await input(files[0]), source = await load(bytes);
  const rects = options.rects ?? [{ page: options.page ?? 1, x: options.x, y: options.y, width: options.width, height: options.height }];
  if (!Array.isArray(rects) || !rects.length || rects.length > 500) fail('Provide 1–500 redaction rectangles.');
  const groups = new Map();
  for (const spec of rects) {
    const p = number(spec.page, 1, 1, source.getPageCount()); if (!Number.isInteger(p)) fail('Page must be an integer.');
    const page = source.getPage(p - 1), media = page.getMediaBox(), crop = page.getCropBox();
    if (page.getRotation().angle % 360 !== 0 || media.x !== 0 || media.y !== 0 || crop.x !== 0 || crop.y !== 0 || crop.width !== media.width || crop.height !== media.height || page.node.get(PDFName.of('UserUnit'))) fail('Redaction requires unrotated pages with standard origin, identical MediaBox/CropBox, and default UserUnit. Normalize this PDF first.');
    const r = { x: number(spec.x, undefined, 0), y: number(spec.y, undefined, 0), width: number(spec.width, undefined, 0.1), height: number(spec.height, undefined, 0.1) };
    if (r.x + r.width > media.width || r.y + r.height > media.height) fail('Redaction rectangle is outside its page.');
    if (!groups.has(p)) groups.set(p, []); groups.get(p).push(r);
  }
  const render = await renderDoc(bytes), output = await PDFDocument.create();
  try {
    // A new document is essential: saving a modified source would retain orphan objects.
    // Flatten forms before copying unaffected pages, then remove annotations so their
    // destination references cannot pull original redacted pages into the new file.
    const form = source.getForm();
    if (form.hasXFA()) fail('XFA redaction is not supported. Export a standard PDF first.');
    if (form.getFields().length) form.flatten();
    for (const page of source.getPages()) page.node.delete(PDFName.of('Annots'));
    const resolution = number(options.maxDimension, 2000, 512, 3000);
    for (let i = 1; i <= source.getPageCount(); i++) {
      if (groups.has(i)) {
        const { canvas: c, viewport } = await renderPage(render, i, resolution), ctx = c.getContext('2d');
        ctx.fillStyle = '#000000';
        for (const r of groups.get(i)) {
          const [x1, y1, x2, y2] = viewport.convertToViewportRectangle([r.x, r.y, r.x + r.width, r.y + r.height]);
          // Conservative outward rounding covers boundary antialiasing pixels.
          const left = Math.max(0, Math.floor(Math.min(x1, x2)) - 1), top = Math.max(0, Math.floor(Math.min(y1, y2)) - 1);
          ctx.fillRect(left, top, Math.ceil(Math.max(x1, x2)) + 1 - left, Math.ceil(Math.max(y1, y2)) + 1 - top);
        }
        const original = source.getPage(i - 1), page = output.addPage([original.getWidth(), original.getHeight()]);
        const img = await output.embedPng(await png(c)); page.drawImage(img, { x: 0, y: 0, width: page.getWidth(), height: page.getHeight() });
        c.width = c.height = 1;
      } else output.addPage((await output.copyPages(source, [i - 1]))[0]);
      progress(i / source.getPageCount(), `Secure replacement: page ${i}`);
    }
    return { files: [out(name(files[0], 'redacted'), await output.save())], summary: `Irreversibly raster-redacted ${groups.size} page(s) in a fresh PDF. Original text/image objects from replaced pages are not copied. Selected pages lose searchability, links, and editable forms. Other pages retain page content/text; forms are flattened and annotations, document metadata, bookmarks, attachments, and digital signatures are not retained. Repeated sensitive content on other pages is NOT removed. Review the output before sharing.` };
  } finally { await render.destroy(); }
}
async function compare(files, options, progress) {
  if (files.length !== 2) fail('Compare requires exactly two PDF files.');
  const aBytes = await input(files[0]), bBytes = await input(files[1]);
  await load(aBytes); await load(bBytes);
  const a = await renderDoc(aBytes); let b;
  try {
    b = await renderDoc(bBytes);
    const count = Math.max(a.numPages, b.numPages), limit = number(options.maxDimension, 768, 256, 1200);
    const threshold = number(options.pixelThreshold, 20, 0, 255), results = [], differences = [];
    for (let n = 1; n <= count; n++) {
      if (n > a.numPages || n > b.numPages) results.push({ page: n, status: n > a.numPages ? 'added' : 'removed', textChanged: true, visualChanged: true });
      else {
        const pa = await a.getPage(n), pb = await b.getPage(n);
        const ta = (await pa.getTextContent()).items.map(i => i.str + (i.hasEOL ? '\n' : ' ')).join('').trim();
        const tb = (await pb.getTextContent()).items.map(i => i.str + (i.hasEOL ? '\n' : ' ')).join('').trim();
        const va = pa.getViewport({ scale: 1 }), vb = pb.getViewport({ scale: 1 });
        const scale = Math.min(2, limit / Math.max(va.width, va.height, vb.width, vb.height));
        const width = Math.ceil(Math.max(va.width, vb.width) * scale), height = Math.ceil(Math.max(va.height, vb.height) * scale);
        const ca = canvas(width, height), cb = canvas(width, height);
        for (const [p, c] of [[pa, ca], [pb, cb]]) {
          const ctx = c.getContext('2d', { willReadFrequently: true }); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, width, height);
          await p.render({ canvasContext: ctx, viewport: p.getViewport({ scale }), background: '#ffffff' }).promise;
        }
        const da = ca.getContext('2d').getImageData(0, 0, width, height), db = cb.getContext('2d').getImageData(0, 0, width, height);
        let changed = 0, absolute = 0;
        for (let p = 0; p < da.data.length; p += 4) {
          let delta = 0; for (let c = 0; c < 3; c++) { const d = Math.abs(da.data[p + c] - db.data[p + c]); delta = Math.max(delta, d); absolute += d; }
          const different = delta > threshold; if (different) changed++;
          da.data[p] = different ? 230 : 255; da.data[p + 1] = different ? 30 : 255; da.data[p + 2] = different ? 30 : 255; da.data[p + 3] = 255;
        }
        const sizeChanged = Math.abs(va.width - vb.width) > .01 || Math.abs(va.height - vb.height) > .01;
        const textChanged = ta !== tb, visualChanged = changed > 0 || sizeChanged;
        let firstTextDifference = null;
        if (textChanged) {
          let at = 0; while (at < Math.min(ta.length, tb.length) && ta[at] === tb[at]) at++;
          firstTextDifference = { offset: at, before: ta.slice(Math.max(0, at - 80), at + 240), after: tb.slice(Math.max(0, at - 80), at + 240) };
        }
        results.push({ page: n, status: textChanged || visualChanged ? 'changed' : 'unchanged', textChanged, visualChanged, sizeChanged, changedPixels: changed, totalPixels: width * height, changedPercent: Number((changed / (width * height) * 100).toFixed(4)), meanChannelDifference: Number((absolute / (width * height * 3)).toFixed(4)), firstTextDifference });
        if (options.includeDiffImages === true && visualChanged && differences.length < 20) { ca.getContext('2d').putImageData(da, 0, 0); differences.push(out(`difference-page-${n}.png`, await png(ca), 'image/png')); }
        ca.width = ca.height = cb.width = cb.height = 1;
      }
      progress(n / count, `Compare page ${n}`);
    }
    const changed = results.filter(p => p.status !== 'unchanged').length;
    const report = { version: 1, before: files[0].name, after: files[1].name, pageCounts: [a.numPages, b.numPages], maxDimension: limit, pixelThreshold: threshold, changedPages: changed, pages: results, limitations: 'Position-based page comparison, not semantic page matching. Raster comparison is bounded-resolution and thresholded; small differences may be missed. Embedded text is compared without OCR. Does not compare metadata, attachments, signatures, scripts, or hidden objects. No detected difference is not proof of equivalence.' };
    const text = [`PDF comparison: ${files[0].name} -> ${files[1].name}`, `${changed}/${count} pages changed`, report.limitations, '', ...results.map(p => `Page ${p.page}: ${p.status}; text=${p.textChanged}; visual=${p.visualChanged}${p.changedPercent !== undefined ? `; pixels=${p.changedPercent}%` : ''}${p.firstTextDifference ? `\n  Before: ${JSON.stringify(p.firstTextDifference.before)}\n  After: ${JSON.stringify(p.firstTextDifference.after)}` : ''}`)].join('\n');
    return { files: [out('comparison.json', JSON.stringify(report, null, 2), 'application/json'), out('comparison.txt', text, 'text/plain;charset=utf-8'), ...differences], report, summary: `${changed} of ${count} page(s) differ in embedded text, dimensions, or bounded-resolution pixels. This is not a full forensic comparison. Reports may contain source text. Optional difference images are capped at 20.` };
  } finally { await a.destroy(); if (b) await b.destroy(); }
}

export async function runEditOp(id, files, options = {}, progress = () => {}) {
  if (!['edit', 'sign', 'redact', 'forms', 'compare'].includes(id)) fail(`Unknown editing operation: ${id}`);
  if (!Array.isArray(files) || !files.length) fail('Choose at least one PDF.');
  if (files.length > (['edit', 'sign', 'compare'].includes(id) ? 2 : 1)) fail('Too many input files for this operation.');
  progress(0, 'Opening PDF');
  const result = id === 'edit' || id === 'sign' ? await overlay(id, files, options, progress) : id === 'forms' ? await forms(files, options, progress) : id === 'redact' ? await redact(files, options, progress) : await compare(files, options, progress);
  progress(1, 'Complete'); return result;
}
