import {PDF_MAX_BYTES,TOTAL_MAX_BYTES} from './file-limits.js';
import { PDFDocument, StandardFonts, degrees, rgb } from 'pdf-lib';

const MAX_FILES = 20, MAX_FILE_BYTES = PDF_MAX_BYTES, MAX_TOTAL_BYTES = TOTAL_MAX_BYTES;
const MAX_PAGES = 500, MAX_RASTER_PAGES = 50;
const IDS = new Set(['merge','split','organize','rotate','compress','protect','repair','crop','page-numbers','watermark']);
const fail = message => { throw new Error(message); };
const number = (value, fallback, min, max, label) => {
  const n = value === undefined || value === '' ? fallback : Number(value);
  if (!Number.isFinite(n) || n < min || n > max) fail(`${label}: ${min}~${max} 범위의 숫자를 입력하세요.`);
  return n;
};
const stem = file => (file.name || 'document.pdf').replace(/\.pdf$/i,'').replace(/[\\/\x00-\x1f<>:"|?*]/g,'_').slice(0,120) || 'document';
const resultFile = (name, bytes) => ({ name, bytes: new Uint8Array(bytes), mime: 'application/pdf' });

/** One-based pages; empty selection means all. Descending ranges are supported. */
export function parsePages(text, count, {allowDuplicates = false} = {}) {
  if (!Number.isInteger(count) || count < 1 || count > MAX_PAGES) fail(`PDF는 1~${MAX_PAGES}페이지까지 지원합니다.`);
  if (text == null || String(text).trim() === '') return Array.from({length:count},(_,i)=>i+1);
  const out = [], seen = new Set();
  if (String(text).length > 10000) fail('페이지 선택이 너무 깁니다.');
  for (const token of String(text).split(',')) {
    const match = token.trim().match(/^(\d+)\s*(?:-\s*(\d+))?$/);
    if (!match) fail('페이지는 1,3-5처럼 입력하세요.');
    const a = Number(match[1]), b = Number(match[2] || match[1]);
    if (a < 1 || b < 1 || a > count || b > count) fail(`페이지 범위는 1~${count}입니다.`);
    const step = a <= b ? 1 : -1;
    for (let p = a; ; p += step) {
      if (allowDuplicates || !seen.has(p)) {out.push(p);seen.add(p);}
      if (out.length > MAX_PAGES) fail(`출력은 최대 ${MAX_PAGES}페이지까지 가능합니다.`);
      if (p === b) break;
    }
  }
  return out;
}

async function load(bytes) {
  try {
    const pdf = await PDFDocument.load(bytes.slice(), {updateMetadata:false, throwOnInvalidObject:true});
    if (pdf.getPageCount() < 1 || pdf.getPageCount() > MAX_PAGES) fail(`PDF는 1~${MAX_PAGES}페이지까지 지원합니다.`);
    return pdf;
  } catch(e) {
    if (/encrypt/i.test(e.message)) fail('암호가 있는 PDF입니다. 먼저 잠금 해제 도구를 사용하세요.');
    if (/페이지까지/.test(e.message)) throw e;
    fail('PDF를 읽을 수 없습니다. 손상된 파일은 복구 도구를 먼저 시도하세요.');
  }
}

function qpdf(id, bytes, options) {
  if (typeof Worker === 'undefined') fail('이 작업은 Web Worker를 지원하는 브라우저가 필요합니다.');
  return new Promise((resolve,reject)=>{
    const worker = new Worker('/pdf-ops-worker.js');
    const end = (error, value) => {clearTimeout(timer);worker.terminate();error ? reject(new Error(error)) : resolve(value);};
    const timer = setTimeout(()=>end('PDF 처리 제한 시간(120초)을 넘겼습니다.'),120000);
    worker.onerror = () => end('로컬 PDF 엔진을 시작하지 못했습니다.');
    worker.onmessage = ({data}) => data.ok ? end(null,data) : end(data.error || 'PDF 처리에 실패했습니다.');
    const copy = bytes.slice();
    worker.postMessage({id,bytes:copy.buffer,password:options.password,ownerPassword:options.ownerPassword,maxPages:MAX_PAGES},[copy.buffer]);
  });
}

async function textImage(text, fontSize) {
  if (typeof document === 'undefined') fail('한국어/유니코드 워터마크는 브라우저의 시스템 글꼴이 필요합니다. 이 환경에서는 영문 ASCII만 지원합니다.');
  const canvas = document.createElement('canvas');
  const font = `${fontSize * 2}px "Apple SD Gothic Neo", "Malgun Gothic", "Noto Sans CJK KR", sans-serif`;
  const ctx = canvas.getContext('2d');
  if (!ctx) fail('문자 워터마크를 그릴 Canvas를 사용할 수 없습니다.');
  if (document.fonts?.ready) await document.fonts.ready;
  ctx.font = font;
  const metrics = ctx.measureText(text);
  canvas.width = Math.ceil(metrics.width + fontSize * 2);canvas.height = Math.ceil(fontSize * 3.2);
  if (canvas.width > 16000 || canvas.width * canvas.height > 8000000) fail('워터마크 문구가 너무 깁니다.');
  ctx.font = font;ctx.fillStyle = '#555';ctx.textBaseline = 'middle';ctx.fillText(text,fontSize,canvas.height/2);
  const blob = await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));
  if (!blob) fail('워터마크 이미지를 생성하지 못했습니다.');
  return {bytes:new Uint8Array(await blob.arrayBuffer()),width:canvas.width/2,height:canvas.height/2};
}

async function rasterCompress(bytes, options, progress) {
  if (typeof document === 'undefined') fail('이미지 압축은 브라우저에서만 사용할 수 있습니다.');
  const pdfjs = await import('/vendor/pdfjs/pdf.mjs');
  pdfjs.GlobalWorkerOptions.workerSrc = '/vendor/pdfjs/pdf.worker.mjs';
  const dpi = number(options.dpi,100,36,200,'DPI');
  const quality = number(options.quality,0.7,0.1,1,'JPEG 품질');
  const task = pdfjs.getDocument({data:bytes.slice(),isEvalSupported:false,useSystemFonts:true,cMapUrl:'/vendor/pdfjs/cmaps/',cMapPacked:true,standardFontDataUrl:'/vendor/pdfjs/standard_fonts/',wasmUrl:'/vendor/pdfjs/wasm/'});
  let pdf;
  try {
    pdf = await task.promise;
    if (pdf.numPages > MAX_RASTER_PAGES) fail(`손실 압축은 최대 ${MAX_RASTER_PAGES}페이지까지 가능합니다.`);
    const out = await PDFDocument.create();
    for (let p = 1; p <= pdf.numPages; p++) {
      const page = await pdf.getPage(p), raw = page.getViewport({scale:1});
      const scale = Math.min(dpi/72,Math.sqrt(8000000/(raw.width*raw.height)),4096/Math.max(raw.width,raw.height));
      const view = page.getViewport({scale});
      const canvas = document.createElement('canvas');canvas.width=Math.max(1,Math.ceil(view.width));canvas.height=Math.max(1,Math.ceil(view.height));
      try {
        await page.render({canvasContext:canvas.getContext('2d'),viewport:view,background:'#fff'}).promise;
        const blob = await new Promise(resolve=>canvas.toBlob(resolve,'image/jpeg',quality));
        if (!blob) fail('페이지 이미지를 생성하지 못했습니다.');
        const image = await out.embedJpg(await blob.arrayBuffer());
        out.addPage([raw.width,raw.height]).drawImage(image,{x:0,y:0,width:raw.width,height:raw.height});
      } finally {canvas.width=1;canvas.height=1;page.cleanup();}
      progress(`이미지 압축 ${p}/${pdf.numPages}`);
    }
    return await out.save();
  } finally {await task.destroy();}
}

/** Local-only PDF transformations. Original input File objects are never changed. */
export async function runPdfOp(id, files, options = {}, progress = ()=>{}) {
  if (!IDS.has(id)) fail('지원하지 않는 PDF 작업입니다.');
  files = Array.from(files || []);
  if (!files.length || files.length > MAX_FILES) fail(`PDF 파일 1~${MAX_FILES}개를 선택하세요.`);
  if (id !== 'merge' && files.length !== 1) fail('이 작업은 PDF 한 개씩 처리합니다.');
  let total = 0;
  for (const file of files) {
    if (!file || typeof file.arrayBuffer !== 'function' || !Number.isFinite(file.size) || !file.size || file.size > MAX_FILE_BYTES) fail('각 PDF는 0바이트 초과, 100 MB 이하여야 합니다.');
    total += file.size;
  }
  if (total > MAX_TOTAL_BYTES) fail('전체 파일 크기는 500 MB 이하여야 합니다.');
  if (id === 'protect') {
    if (typeof options.password !== 'string' || !options.password.trim()) fail('열기 암호를 입력하세요.');
    if (options.ownerPassword !== undefined && (typeof options.ownerPassword !== 'string' || !options.ownerPassword.trim())) fail('소유자 암호를 입력하거나 비워 두세요.');
    for (const p of [options.password,options.ownerPassword].filter(x=>x!==undefined)) if (p.includes('\0') || new TextEncoder().encode(p).length > 127) fail('암호는 NUL 문자를 제외한 UTF-8 127바이트 이하여야 합니다.');
  }
  progress('PDF를 읽는 중');
  const inputs = [];
  for (const file of files) inputs.push(new Uint8Array(await file.arrayBuffer()));
  const name = stem(files[0]);
  if (['compress','protect','repair'].includes(id)) {
    if (options.pages != null && String(options.pages).trim()) fail('압축, 암호 설정, 복구는 전체 문서에 적용됩니다. 페이지 선택을 비워 주세요.');
    if (id === 'compress' && options.lossy === true) {
      const bytes = await rasterCompress(inputs[0],options,progress);
      progress('완료');
      return {files:[resultFile(`${name}-compressed-image.pdf`,bytes)],summary:`손실 JPEG 이미지 압축 완료 (${total} → ${bytes.length}바이트). 텍스트 검색, 링크, 양식, 접근성 정보가 보존되지 않습니다. 파일 크기 감소는 보장하지 않습니다.`};
    }
    progress(id === 'protect' ? 'AES-256 암호 설정 중' : '로컬 qpdf 처리 중');
    const out = await qpdf(id,inputs[0],options);
    progress('완료');
    const notes = out.warnings?.length ? ` 경고: ${out.warnings.join(' | ')}` : '';
    return {files:[resultFile(`${name}-${id}.pdf`,out.bytes)],summary:`${id === 'protect' ? 'AES-256 암호 설정' : id === 'repair' ? 'qpdf 구조 재작성' : '무손실 qpdf 재작성'} 완료 (${total} → ${out.bytes.byteLength}바이트).${id === 'compress' ? ' 파일 크기 감소는 보장하지 않습니다.' : ''}${notes}${id === 'repair' ? ' 누락된 페이지나 원본 내용을 복원한 것은 아닙니다. 결과를 확인하세요.' : ''}`};
  }
  if (id === 'merge') {
    const out = await PDFDocument.create();let count=0;
    for (let i=0;i<inputs.length;i++) {
      const pdf = await load(inputs[i]), pages = parsePages(options.pages,pdf.getPageCount());count += pages.length;
      if (count > MAX_PAGES) fail(`병합 결과는 최대 ${MAX_PAGES}페이지입니다.`);
      for (const page of await out.copyPages(pdf,pages.map(p=>p-1))) out.addPage(page);
      progress(`병합 ${i+1}/${inputs.length}`);
    }
    return {files:[resultFile('merged.pdf',await out.save())],summary:`${files.length}개 PDF를 ${count}페이지로 병합했습니다. 책갈피, 문서 수준 양식 및 서명 보존은 보장하지 않습니다.`};
  }
  const pdf = await load(inputs[0]);
  const selected = parsePages(options.pages,pdf.getPageCount(),{allowDuplicates:id==='organize'});
  if (id === 'split' || id === 'organize') {
    let groups;
    if (id === 'organize') groups=[selected];
    else if (!options.mode || options.mode === 'each') groups=selected.map(p=>[p]);
    else if (options.mode === 'ranges') {
      if (!String(options.ranges || '').trim()) fail('분할 범위를 입력하세요. 예: 1-3,4-6');
      const text=String(options.ranges);
      groups=text.split(/[;\n]/.test(text) ? /[;\n]/ : /,/).map(x=>{if(!x.trim())fail('빈 분할 범위가 있습니다.');return parsePages(x,pdf.getPageCount());});
      if (options.pages != null && String(options.pages).trim()) fail('범위 분할에서는 pages 대신 ranges만 사용하세요.');
    } else fail('분할 모드는 each 또는 ranges입니다.');
    if (groups.reduce((sum,g)=>sum+g.length,0)>MAX_PAGES) fail(`전체 출력은 최대 ${MAX_PAGES}페이지입니다.`);
    const output=[];
    for (let i=0;i<groups.length;i++) {
      const out = await PDFDocument.create();
      for (const p of await out.copyPages(pdf,groups[i].map(n=>n-1))) out.addPage(p);
      output.push(resultFile(`${name}-${id}-${String(i+1).padStart(3,'0')}.pdf`,await out.save()));
      progress(`${i+1}/${groups.length} PDF 생성`);
    }
    return {files:output,summary:`${output.length}개 PDF를 생성했습니다. 페이지 순서는 입력한 순서입니다. 문서 수준 양식, 책갈피 및 서명은 보존되지 않을 수 있습니다.`};
  }
  let font, overlay;
  const fontSize=number(options.fontSize,id==='watermark'?36:12,6,200,'글자 크기');
  let opacity=0.25, start=1;
  if (id==='watermark') {
    const text=String(options.text || '').trim();
    if (!text || text.length>300 || /[\r\n\x00-\x1f]/.test(text)) fail('워터마크는 1~300자의 한 줄 문구로 입력하세요.');
    opacity=number(options.opacity,0.25,0.01,1,'불투명도');
    if (/[^\x20-\x7e]/.test(text)) {const img=await textImage(text,fontSize);overlay={...img,image:await pdf.embedPng(img.bytes)};}
    else {font=await pdf.embedFont(StandardFonts.Helvetica);overlay={text};}
  }
  if (id==='page-numbers') {font=await pdf.embedFont(StandardFonts.Helvetica);start=number(options.start,1,0,999999,'시작 번호');if(!Number.isInteger(start))fail('시작 번호는 정수여야 합니다.');}
  const rotation=id==='rotate'?Number(options.rotation ?? 90):0;
  if (id==='rotate' && ![90,180,270].includes(rotation)) fail('회전은 90, 180, 270도만 가능합니다.');
  const crop=id==='crop'?Object.fromEntries(['top','right','bottom','left'].map(k=>[k,number(options[k],0,0,10000,k)])):null;
  for (let i=0;i<selected.length;i++) {
    const page=pdf.getPage(selected[i]-1), box=page.getCropBox();
    if (id==='rotate') page.setRotation(degrees((page.getRotation().angle+rotation)%360));
    if (id==='crop') {
      const w=box.width-crop.left-crop.right,h=box.height-crop.top-crop.bottom;
      if(w<=0 || h<=0)fail(`${selected[i]}페이지의 자르기 여백이 페이지 크기보다 큽니다.`);
      page.setCropBox(box.x+crop.left,box.y+crop.bottom,w,h);
    }
    if (id==='watermark') {
      if (overlay.image) {
        const scale=Math.min(1,box.width*0.9/overlay.width,box.height*0.9/overlay.height);
        const w=overlay.width*scale,h=overlay.height*scale;
        page.drawImage(overlay.image,{x:box.x+(box.width-w)/2,y:box.y+(box.height-h)/2,width:w,height:h,opacity});
      } else {
        const size=Math.min(fontSize,box.width*0.9/font.widthOfTextAtSize(overlay.text,1),box.height*0.9);
        page.drawText(overlay.text,{x:box.x+(box.width-font.widthOfTextAtSize(overlay.text,size))/2,y:box.y+box.height/2-size/3,size,font,color:rgb(0.33,0.33,0.33),opacity});
      }
    }
    if (id==='page-numbers') {
      const text=String(start+i),w=font.widthOfTextAtSize(text,fontSize);
      if(w>box.width || fontSize+12>box.height)fail('페이지가 번호를 넣기에 너무 작습니다.');
      page.drawText(text,{x:box.x+(box.width-w)/2,y:box.y+12,size:fontSize,font,color:rgb(0.2,0.2,0.2)});
    }
    progress(`${i+1}/${selected.length}페이지 처리`);
  }
  const bytes=await pdf.save();
  return {files:[resultFile(`${name}-${id}.pdf`,bytes)],summary:`${selected.length}페이지 처리 완료.${id==='crop'?' CropBox를 바꿨습니다. 잘린 내용은 삭제되지 않으므로 기밀정보 가리기에 사용하지 마세요.':''}${id==='watermark' && overlay?.image?' 유니코드 문구만 시스템 글꼴의 PNG로 삽입했습니다. 글꼴에 따라 표시가 달라질 수 있습니다.':''}${['watermark','page-numbers'].includes(id)?' 문구 위치는 회전 전 PDF 좌표 기준입니다.':''} 디지털 서명은 유지되지 않을 수 있습니다.`};
}
