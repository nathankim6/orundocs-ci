// No provider credentials belong in the client. Parent integration fills this HTTPS origin.
export const EXAM_AI_BASE_URL = 'https://orunpdf-ai.5554ksj2.workers.dev';
export const MAX_AI_INPUT = 2 * 1024 * 1024;
export const MAX_AI_RESPONSE = 16 * 1024 * 1024;
export class ExamAIError extends Error { constructor(code, message) { super(message); this.code = code; } }
const fail = (code, message) => { throw new ExamAIError(code, message); };
export function checkCancelled(signal) { if (signal?.aborted) { const e = new Error('취소했습니다. 이미 전송한 요청은 처리·과금될 수 있습니다.'); e.name = 'AbortError'; throw e; } }
export function requireConsent(consent) { if (consent !== true) fail('consent', '이번 작업의 사진 전송·과금 동의가 필요합니다.'); }
function endpoint(base, route) { let u; try { u = new URL(base); } catch {} if (!u || u.protocol !== 'https:' || u.username || u.password || u.search || u.hash) fail('config', 'GPT AI 서버가 아직 연결되지 않았습니다. 기기 처리를 직접 선택해 주세요.'); return u.origin + u.pathname.replace(/\/$/, '') + route; }
export async function readLimitedJSON(response, max = MAX_AI_RESPONSE) {
  if (Number(response.headers?.get('content-length')) > max) fail('response', 'AI 응답이 허용 크기를 넘었습니다.');
  if (!response.body?.getReader) fail('response', '이 환경에서는 AI 응답을 안전하게 읽을 수 없습니다.');
  const reader = response.body.getReader(); let size = 0; const chunks = [];
  try { for (;;) { const { done, value } = await reader.read(); if (done) break; size += value.byteLength; if (size > max) fail('response', 'AI 응답이 허용 크기를 넘었습니다.'); chunks.push(value); } }
  catch (e) { await reader.cancel().catch(() => {}); throw e; } finally { reader.releaseLock(); }
  const bytes = new Uint8Array(size); let off = 0; for (const c of chunks) { bytes.set(c, off); off += c.length; }
  try { return JSON.parse(new TextDecoder().decode(bytes)); } catch { fail('response', 'AI 응답을 읽을 수 없습니다.'); }
}
export function imageHeader(bytes, mime) {
  const u = bytes, dv = new DataView(u.buffer, u.byteOffset, u.byteLength); let width, height;
  if (mime === 'image/png') {
    if (u.length < 24 || ![137,80,78,71,13,10,26,10].every((n,i)=>u[i]===n) || String.fromCharCode(...u.subarray(12,16)) !== 'IHDR') fail('image','AI 이미지 형식이 올바르지 않습니다.');
    width = dv.getUint32(16); height = dv.getUint32(20);
  } else if (mime === 'image/jpeg') {
    if (u.length < 4 || u[0] !== 255 || u[1] !== 216) fail('image','AI 이미지 형식이 올바르지 않습니다.');
    let i = 2; while (i + 3 < u.length) {
      if (u[i++] !== 255) break; while (u[i] === 255) i++;
      const marker = u[i++]; if (marker === 217 || marker === 218) break;
      if (marker === 1 || (marker >= 208 && marker <= 215)) continue;
      if (i + 2 > u.length) break; const len = dv.getUint16(i); if (len < 2 || i + len > u.length) break;
      if ([192,193,194,195,197,198,199,201,202,203,205,206,207].includes(marker) && len >= 8) { height = dv.getUint16(i+3); width = dv.getUint16(i+5); break; } i += len;
    }
  } else fail('image','AI 이미지 형식이 지원되지 않습니다.');
  if (!width || !height || width > 4096 || height > 4096) fail('image','AI 이미지 크기가 허용 범위를 벗어났습니다.');
  return { width, height };
}
export async function validateAIImage(data, requestId, decode = globalThis.createImageBitmap) {
  if (!data || data.requestId !== requestId || typeof data.imageBase64 !== 'string' || data.imageBase64.length > MAX_AI_RESPONSE || data.imageBase64.length % 4 !== 0 || !/^[A-Za-z0-9+/]+={0,2}$/.test(data.imageBase64)) fail('response','AI 응답을 확인하지 못했습니다.');
  const raw = atob(data.imageBase64), bytes = Uint8Array.from(raw, c => c.charCodeAt(0));
  const size = imageHeader(bytes, data.mimeType); const blob = new Blob([bytes], { type: data.mimeType }); let bitmap;
  try { bitmap = await decode(blob); if (!bitmap.width || !bitmap.height || bitmap.width > 4096 || bitmap.height > 4096 || bitmap.width !== size.width || bitmap.height !== size.height) fail('image','AI 이미지 크기가 올바르지 않습니다.'); }
  catch { fail('image','AI 이미지를 안전하게 열 수 없습니다.'); } finally { bitmap?.close?.(); }
  return { blob, ...size, usage: data.usage, costUSD: Number.isFinite(data.costUSD) && data.costUSD >= 0 ? data.costUSD : null };
}
export function createExamAIClient({ baseURL = EXAM_AI_BASE_URL, getIdToken, fetchImpl = globalThis.fetch, online = () => globalThis.navigator?.onLine !== false, decode } = {}) {
  async function request(route, { signal, body } = {}) {
    checkCancelled(signal); if (!online()) fail('offline','GPT AI는 인터넷 연결이 필요합니다. 기기 처리를 직접 선택할 수 있습니다.');
    const url = endpoint(baseURL, route); let token;
    try { token = await getIdToken?.(); } catch { fail('auth','온라인 로그인 확인이 필요합니다. 다시 로그인해 주세요.'); }
    checkCancelled(signal); if (typeof token !== 'string' || !token || /[\r\n]/.test(token)) fail('auth','온라인 로그인 확인이 필요합니다.');
    let response; try { response = await fetchImpl(url, { method: body ? 'POST' : 'GET', headers: { Authorization: 'Bearer ' + token, ...(body ? { 'Content-Type': 'application/json' } : {}) }, ...(body ? { body: JSON.stringify(body) } : {}), signal, credentials: 'omit', redirect: 'error', cache: 'no-store' }); }
    catch (e) { checkCancelled(signal); fail('network','AI 요청 결과를 확인할 수 없습니다. 이미 전송했다면 과금될 수 있습니다. 자동 재시도하지 않습니다.'); }
    checkCancelled(signal); if (!response.ok) { await response.body?.cancel?.().catch(() => {}); fail('server', response.status === 401 || response.status === 403 ? '로그인 또는 AI 사용 권한을 확인해 주세요.' : response.status === 429 ? 'AI 사용 한도에 도달했습니다. 잠시 후 사용량을 확인해 주세요.' : 'AI 처리에 실패했습니다. 자동 재시도하지 않습니다. 전송된 요청은 과금될 수 있습니다.'); }
    try { return await readLimitedJSON(response, body ? MAX_AI_RESPONSE : 64 * 1024); } catch (e) { checkCancelled(signal); if (e instanceof ExamAIError) throw e; fail('response', 'AI 응답을 안전하게 읽을 수 없습니다. 이미 전송된 요청은 과금될 수 있습니다.'); }
  }
  return {
    status: signal => request('/v1/status', { signal }),
    async cleanup({ imageBase64, mimeType, orientation, requestId, consent, signal }) {
      requireConsent(consent); if (mimeType !== 'image/jpeg' || typeof imageBase64 !== 'string' || imageBase64.length > Math.ceil(MAX_AI_INPUT / 3) * 4 || !/^[A-Za-z0-9+/]+={0,2}$/.test(imageBase64) || !requestId || !['portrait','landscape','square'].includes(orientation)) fail('input','전송할 사진을 확인해 주세요.');
      const data = await request('/v1/cleanup', { signal, body: { imageBase64, mimeType, orientation: orientation === 'square' ? 'portrait' : orientation, requestId } }); checkCancelled(signal);
      const result = await validateAIImage(data, requestId, decode); checkCancelled(signal); return result;
    }
  };
}
export async function prepareAIImage(blob, { signal, decode = globalThis.createImageBitmap, makeCanvas = () => document.createElement('canvas') } = {}) {
  checkCancelled(signal); let bmp, canvas;
  try {
    bmp = await decode(blob); const scale = Math.min(1, 2048 / Math.max(bmp.width, bmp.height)); canvas = makeCanvas(); canvas.width = Math.max(1, Math.round(bmp.width * scale)); canvas.height = Math.max(1, Math.round(bmp.height * scale));
    canvas.getContext('2d').drawImage(bmp, 0, 0, canvas.width, canvas.height);
    let out; for (const quality of [0.9,0.8,0.65,0.5,0.35]) { checkCancelled(signal); out = await new Promise(r => canvas.toBlob(r, 'image/jpeg', quality)); if (out?.size <= MAX_AI_INPUT) break; }
    if (!out || out.type !== 'image/jpeg' || out.size > MAX_AI_INPUT) fail('input','사진을 안전한 전송 크기로 줄이지 못했습니다. 기기 처리를 선택해 주세요.');
    const bytes = new Uint8Array(await out.arrayBuffer()); let binary = ''; for (let i=0; i<bytes.length; i+=8192) binary += String.fromCharCode(...bytes.subarray(i,i+8192)); checkCancelled(signal);
    return { imageBase64: btoa(binary), mimeType: 'image/jpeg', orientation: canvas.width === canvas.height ? 'square' : canvas.width > canvas.height ? 'landscape' : 'portrait', before: out, width: canvas.width, height: canvas.height };
  } finally { bmp?.close?.(); if (canvas) canvas.width = canvas.height = 1; }
}
