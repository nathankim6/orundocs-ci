import {PDF_MAX_BYTES,TOTAL_MAX_BYTES} from './file-limits.js';
import { PDFDocument } from 'pdf-lib';
import fontkit from '@pdf-lib/fontkit';

export const AI_PDF_LIMITS = Object.freeze({files:10,fileBytes:PDF_MAX_BYTES,totalBytes:TOTAL_MAX_BYTES,pages:100,characters:100000,htmlBytes:2*1024*1024,outputPages:100,fontBytes:20*1024*1024});
const L=AI_PDF_LIMITS, encoder=new TextEncoder();
let pdfjsPromise;
function fail(code,message,extra={}) { return Object.assign(new Error(message),{code,...extra}); }
function checkAbort(signal) { if(signal?.aborted) throw signal.reason || new DOMException('Cancelled','AbortError'); }
function bounded(n,fallback,max,label,min=1) { n=n===undefined?fallback:Number(n);if(!Number.isInteger(n)||n<min||n>max)throw fail('INVALID_OPTIONS',`${label} must be an integer from ${min} to ${max}.`);return n; }
const safeName=n=>String(n||'document').replace(/\.[^.]*$/,'').replace(/[\\/\x00-\x1f<>:"|?*]/g,'_').slice(0,100)||'document';
function notify(cb,phase,progress,message,extra={}) { cb({phase,progress:Math.max(0,Math.min(1,progress)),message,...extra}); }
async function abortable(promise,signal) {
  checkAbort(signal);if(!signal)return promise;
  let listener;const aborted=new Promise((_,reject)=>{listener=()=>reject(signal.reason||new DOMException('Cancelled','AbortError'));signal.addEventListener('abort',listener,{once:true});});
  try{return await Promise.race([promise,aborted]);}finally{signal.removeEventListener('abort',listener);}
}
async function pdfEngine() {
  if(!pdfjsPromise)pdfjsPromise=import('/vendor/pdfjs/pdf.mjs').then(p=>{p.GlobalWorkerOptions.workerSrc='/vendor/pdfjs/pdf.worker.mjs';return p;}).catch(e=>{pdfjsPromise=null;throw e;});
  return pdfjsPromise;
}
async function extractPdf(file,o,progress) {
  const engine=await pdfEngine();checkAbort(o.signal);
  const bytes=new Uint8Array(await abortable(file.arrayBuffer(),o.signal));
  const loading=engine.getDocument({data:bytes,isEvalSupported:false,disableFontFace:true,cMapUrl:'/vendor/pdfjs/cmaps/',cMapPacked:true,standardFontDataUrl:'/vendor/pdfjs/standard_fonts/'});
  const onAbort=()=>{void loading.destroy();};o.signal?.addEventListener('abort',onAbort,{once:true});
  try {
    const doc=await abortable(loading.promise,o.signal);let text='',readPages=0;
    const cap=Math.min(doc.numPages,o.maxPages);
    for(let p=1;p<=cap&&text.length<o.maxChars;p++) {
      checkAbort(o.signal);const page=await abortable(doc.getPage(p),o.signal);
      try {const content=await abortable(page.getTextContent(),o.signal);
        for(const item of content.items) {if(typeof item.str!=='string')continue;text+=(item.str+(item.hasEOL?'\n':' ')).slice(0,o.maxChars-text.length);if(text.length>=o.maxChars)break;}
        if(text.length<o.maxChars)text+='\n';
      }finally{page.cleanup();}
      readPages=p;notify(progress,'extract',p/cap,`Extracting ${file.name}: page ${p}/${cap}`);
    }
    if(!text.trim())throw fail('NO_TEXT','No embedded PDF text found. Run OCR first, then try again.',{suggestOCR:true});
    return {text:text.trim(),pages:readPages,totalPages:doc.numPages,truncated:readPages<doc.numPages||text.length>=o.maxChars};
  }finally{o.signal?.removeEventListener('abort',onAbort);await loading.destroy();}
}

/** Parse only attribute-free structural HTML, never the original active markup. */
export function htmlToText(html) {
  if(typeof html!=='string'||encoder.encode(html).length>L.htmlBytes)throw fail('INPUT_LIMIT','HTML must be a string no larger than 2 MiB.');
  if(typeof DOMParser==='undefined')throw fail('HTML_PARSER_UNAVAILABLE','This operation requires the browser DOMParser.');
  // Remove raw/non-document content before any DOM exists. Whitelist pass below is
  // the security boundary: not one original attribute or active tag reaches DOMParser.
  let inert=html.replace(/<!--[^]*?(?:-->|$)/g,'').replace(/<(script|style|noscript|iframe|object|svg|math|template|head)\b[^>]*>[^]*?(?:<\/\1\s*>|$)/gi,'');
  const allowed=new Set(['h1','h2','h3','h4','h5','h6','p','div','section','article','main','header','footer','blockquote','pre','ul','ol','li','br','hr','table','thead','tbody','tr','td','th','span','b','strong','i','em','a','code']);
  inert=inert.replace(/<[^]*?(?:>|$)/g,tag=>{const m=tag.match(/^<\s*(\/?)\s*([a-z][a-z0-9]*)\b/i);return m&&allowed.has(m[2].toLowerCase())?`<${m[1]}${m[2].toLowerCase()}>`:'';});
  const doc=new DOMParser().parseFromString(inert,'text/html');
  doc.querySelectorAll('script,style,noscript,iframe,object,embed,img,link,meta,base,form,input,button,textarea,select,svg,math,template').forEach(n=>n.remove());
  const out=[];const block=/^(H[1-6]|P|DIV|SECTION|ARTICLE|MAIN|HEADER|FOOTER|BLOCKQUOTE|PRE|UL|OL|LI|TABLE|TR)$/;
  function walk(node) {
    if(node.nodeType===3){out.push(node.nodeValue);return;}
    if(node.nodeType!==1)return;
    if(block.test(node.tagName))out.push('\n');
    if(node.tagName==='BR'||node.tagName==='HR')out.push('\n');
    for(const child of node.childNodes)walk(child);
    if(node.tagName==='TD'||node.tagName==='TH')out.push('\t');
    if(block.test(node.tagName))out.push('\n');
  }
  walk(doc.body);return out.join('').replace(/[ \t\r\f]+/g,' ').replace(/ *\n */g,'\n').replace(/\n{3,}/g,'\n\n').trim();
}

/** Searchable Unicode text reflow. No source layout, CSS, images or links retained. */
export async function textToPdf(text,options={}) {
  if(typeof text!=='string'||!text.trim()||text.length>L.characters)throw fail('INPUT_LIMIT',`Provide 1-${L.characters} text characters.`);
  checkAbort(options.signal);let fontBytes=options.fontBytes;
  if(fontBytes===undefined) {
    const response=await fetch('/vendor/fonts/noto-sans-kr.ttf',{signal:options.signal,credentials:'same-origin'});
    if(!response.ok)throw fail('FONT_UNAVAILABLE','Local Noto Sans KR font is missing.');
    fontBytes=new Uint8Array(await response.arrayBuffer());
  }
  if(!(fontBytes instanceof Uint8Array)||!fontBytes.length||fontBytes.length>L.fontBytes)throw fail('FONT_UNAVAILABLE','fontBytes must be a nonempty Uint8Array up to 20 MiB.');
  const doc=await PDFDocument.create();doc.registerFontkit(fontkit);
  // Subsetting assigns fresh glyph IDs and avoids duplicate-glyph ToUnicode
  // collisions in the supplied Korean font (notably spaces and ASCII digits).
  const font=await doc.embedFont(fontBytes,{subset:true});
  const supported=new Set(font.getCharacterSet());
  const clean=text.normalize('NFC').replace(/\r\n?/g,'\n').replace(/\t/g,'    ').replace(/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/g,'');
  for(const ch of clean)if(ch!=='\n'&&!supported.has(ch.codePointAt(0)))throw fail('UNSUPPORTED_GLYPH',`Local PDF font cannot represent U+${ch.codePointAt(0).toString(16).toUpperCase()}; use TXT output or provide a compatible fontBytes.`);
  const size=bounded(options.fontSize,11,24,'fontSize',8), margin=42,width=595.28,height=841.89,lineHeight=size*1.55,maxWidth=width-2*margin;
  let page,y;function newPage(){if(doc.getPageCount()>=L.outputPages)throw fail('OUTPUT_LIMIT','Reflow exceeds 100 output pages. Reduce input text.');page=doc.addPage([width,height]);y=height-margin-size;}
  newPage();function line(s){checkAbort(options.signal);if(y<margin)newPage();if(s)page.drawText(s,{x:margin,y,size,font});y-=lineHeight;}
  let steps=0;
  for(const para of clean.split('\n')) {
    let current='',currentWidth=0;
    // Character wrapping supports Korean and long unbroken words without overflow.
    for(const ch of para) {
      const cw=font.widthOfTextAtSize(ch,size);
      if(current&&currentWidth+cw>maxWidth){line(current);current='';currentWidth=0;}
      current+=ch;currentWidth+=cw;
      if(++steps%4096===0){await new Promise(r=>setTimeout(r,0));checkAbort(options.signal);}
    }
    line(current);
  }
  checkAbort(options.signal);const saved=await doc.save();checkAbort(options.signal);return saved;
}

function language(value,fallback,label) {
  const v=value??fallback;if(typeof v!=='string'||!/^[a-z]{2,3}(?:-[a-z0-9]{2,8})*$/i.test(v))throw fail('INVALID_OPTIONS',`${label} must be a BCP-47 language code.`);return v;
}
function modelError(e) {
  if(e?.name==='NotSupportedError')return fail('UNSUPPORTED_LANGUAGE','The browser model does not support these languages or options. No substitute summary/translation was generated.',{cause:e});
  return e;
}
async function createModel(kind,settings,o,progress) {
  const api=globalThis[kind];
  if(typeof api?.availability!=='function'||typeof api?.create!=='function')throw fail('MODEL_UNAVAILABLE',`${kind} API is not available in this browser. No remote service or fallback is used.`);
  let availability;try{availability=await abortable(api.availability(settings),o.signal);}catch(e){throw modelError(e);}
  if(availability==='unavailable')throw fail('MODEL_UNAVAILABLE',`${kind} is unavailable for the selected languages/options on this device. Availability does not identify whether language, hardware or browser policy caused it.`);
  if(!['available','downloadable','downloading'].includes(availability))throw fail('MODEL_UNAVAILABLE',`Unknown ${kind} availability: ${availability}.`);
  if(availability!=='available'&&o.allowModelDownload!==true)throw fail('MODEL_DOWNLOAD_REQUIRED',`${kind} needs a browser-managed model download. Enable the explicit model download option and start again. Download size is controlled by the browser and may be large.`,{availability});
  notify(progress,'model',0,availability==='available'?`Opening local ${kind}`:`Downloading local ${kind} model; document text stays on device`);
  let instance;
  try {
    const pending=api.create({...settings,signal:o.signal,monitor(monitor){monitor.addEventListener('downloadprogress',event=>{
      const fraction=event.total>0?event.loaded/event.total:event.loaded;
      notify(progress,'download',Number.isFinite(fraction)?fraction:0,'Downloading browser AI model (not uploading documents)',{loaded:event.loaded,total:event.total});
    });}});
    // If an older implementation ignores AbortSignal, dispose a late result.
    Promise.resolve(pending).then(model=>{if(o.signal?.aborted)model.destroy?.();},()=>{});
    instance=await abortable(pending,o.signal);return instance;
  }catch(e){instance?.destroy?.();throw modelError(e);}
}
function chunks(text,max=2000) {
  const out=[];let rest=text;
  while(rest.length>max){let cut=rest.lastIndexOf('\n',max);if(cut<max/2)cut=rest.lastIndexOf(' ',max);if(cut<max/2)cut=max;if(/[\uD800-\uDBFF]/.test(rest[cut-1]))cut--;out.push(rest.slice(0,cut));rest=rest.slice(cut);}
  if(rest)out.push(rest);return out;
}

export async function runAiOp(id,files,options={},progress=()=>{}) {
  if(!['translate','ai-summary','html-to-pdf'].includes(id))throw fail('UNKNOWN_OPERATION',`Unknown AI operation: ${id}`);
  if(!Array.isArray(files)||files.length>L.files)throw fail('INPUT_LIMIT','Use up to 10 files.');
  if(typeof progress!=='function')throw fail('INVALID_OPTIONS','progress must be a function.');
  if(options.allowModelDownload!==undefined&&typeof options.allowModelDownload!=='boolean')throw fail('INVALID_OPTIONS','allowModelDownload must be a boolean.');
  let total=0;for(const file of files){if(!file||typeof file.arrayBuffer!=='function'||typeof file.name!=='string'||!Number.isFinite(file.size)||file.size<=0||file.size>L.fileBytes)throw fail('INPUT_LIMIT','Each uploaded file must be nonempty and at most 100 MiB.');total+=file.size;}
  if(total>L.totalBytes)throw fail('INPUT_LIMIT','Combined inputs exceed 500 MiB.');
  const controller=new AbortController(),external=options.signal,onAbort=()=>controller.abort(external.reason);
  checkAbort(external);external?.addEventListener('abort',onAbort,{once:true});
  const timeoutMs=bounded(options.timeoutMs,300000,900000,'timeoutMs',1000);
  const timer=setTimeout(()=>controller.abort(new DOMException('Operation timed out','TimeoutError')),timeoutMs);
  const o={...options,signal:controller.signal};let model;
  try {
    o.maxPages=bounded(o.maxPages,100,L.pages,'maxPages');o.maxChars=bounded(o.maxChars,id==='ai-summary'?12000:30000,L.characters,'maxChars');
    const result=[],details=[];let remaining=L.characters;
    if(id==='html-to-pdf') {
      if(o.html!==undefined&&files.length)throw fail('INVALID_OPTIONS','Choose uploaded HTML files or options.html, not both.');
      const inputs=o.html!==undefined?[{name:'html-document.html',text:async()=>o.html,size:encoder.encode(String(o.html)).length}]:files;
      if(!inputs.length)throw fail('NO_INPUT','Upload .html/.htm files or provide options.html.');
      for(const file of inputs) {
        checkAbort(o.signal);if(!/\.html?$/i.test(file.name))throw fail('INVALID_FILE','HTML conversion accepts only .html or .htm files, not URLs.');
        if(file.size>L.htmlBytes)throw fail('INPUT_LIMIT','Each HTML file must be at most 2 MiB.');
        const text=htmlToText(await abortable(file.text(),o.signal));
        if(!text)throw fail('NO_TEXT','HTML contains no usable document text.');
        if(text.length>o.maxChars||text.length>remaining)throw fail('INPUT_LIMIT','HTML text exceeds character limit. Reduce the input or increase maxChars (up to 100000).');remaining-=text.length;
        notify(progress,'pdf',0,`Reflowing local HTML text: ${file.name}`);
        result.push({name:`${safeName(file.name)}.pdf`,bytes:await textToPdf(text,o),mime:'application/pdf'});
      }
      notify(progress,'done',1,'HTML text PDF ready');return {files:result,summary:'Local HTML text conversion: headings and paragraphs reflowed into searchable Unicode PDF. Scripts, CSS, images, forms, external assets and original layout are not retained. This is not a visual webpage capture.'};
    }
    if(!files.length)throw fail('NO_INPUT','Upload PDF files first.');
    for(const file of files)if(!/\.pdf$/i.test(file.name))throw fail('INVALID_FILE','Translation and AI summary accept PDF files with embedded text.');
    let settings;
    if(id==='translate')settings={sourceLanguage:language(o.sourceLang,'ko','sourceLang'),targetLanguage:language(o.targetLang,'en','targetLang')};
    else {
      const langs=o.inputLanguages??[o.sourceLang??'en'];
      if(!Array.isArray(langs)||!langs.length||langs.length>10)throw fail('INVALID_OPTIONS','inputLanguages must contain 1-10 BCP-47 codes.');
      settings={type:o.type??'key-points',format:'plain-text',length:o.length??'medium',expectedInputLanguages:langs.map(l=>language(l,null,'inputLanguages'))};
      if(!['key-points','tldr','teaser','headline'].includes(settings.type)||!['short','medium','long'].includes(settings.length))throw fail('INVALID_OPTIONS','Invalid summarizer type or length.');
      // Output language is conditional: omission lets the browser use its default.
      if(o.outputLanguage!==undefined)settings.outputLanguage=language(o.outputLanguage,null,'outputLanguage');
    }
    model=await createModel(id==='translate'?'Translator':'Summarizer',settings,o,progress);
    for(const file of files) {
      if(remaining<=0)throw fail('INPUT_LIMIT','Combined extracted text exceeds 100000 characters.');
      const extracted=await extractPdf(file,{...o,maxChars:Math.min(o.maxChars,remaining)},progress);remaining-=extracted.text.length;
      let output='';
      try {
        if(id==='translate') {
          const parts=chunks(extracted.text);for(let i=0;i<parts.length;i++) {
            checkAbort(o.signal);output+=(i?'\n':'')+await abortable(model.translate(parts[i],{signal:o.signal}),o.signal);
            if(output.length>L.characters)throw fail('OUTPUT_LIMIT','Translation exceeds 100000 output characters.');
            notify(progress,'translate',(i+1)/parts.length,`Translating ${file.name}: chunk ${i+1}/${parts.length}`);
          }
        }else {
          if(typeof model.measureInputUsage==='function'&&Number.isFinite(model.inputQuota)) {
            const usage=await abortable(model.measureInputUsage(extracted.text),o.signal);
            if(usage>model.inputQuota)throw fail('MODEL_INPUT_LIMIT','Extracted text exceeds the local summary model context. Reduce maxChars and retry.');
          }
          notify(progress,'summarize',0,`Generating a real local AI summary: ${file.name}`);
          output=await abortable(model.summarize(extracted.text,{signal:o.signal}),o.signal);
        }
      }catch(e){if(e?.name==='QuotaExceededError')throw fail('MODEL_INPUT_LIMIT','Local model context exceeded. Reduce maxChars and retry.',{cause:e});throw modelError(e);}
      if(typeof output!=='string'||!output.trim())throw fail('EMPTY_MODEL_OUTPUT','The local model returned no text.');
      if(output.length>L.characters)throw fail('OUTPUT_LIMIT','Model output exceeds 100000 characters.');
      const name=`${safeName(file.name)}-${id==='translate'?settings.targetLanguage:'ai-summary'}`;
      result.push({name:`${name}.txt`,bytes:encoder.encode(output),mime:'text/plain;charset=utf-8'});
      if(o.outputPdf===true)result.push({name:`${name}.pdf`,bytes:await textToPdf(output,o),mime:'application/pdf'});
      details.push(`${file.name}: ${extracted.pages}/${extracted.totalPages} pages${extracted.truncated?' (LIMITED INPUT: source truncated by page/character cap)':''}`);
    }
    notify(progress,'done',1,'Local AI output ready');
    return {files:result,summary:`${id==='translate'?'Browser Translator translation':'Browser Summarizer generative AI summary'}; documents processed locally, no remote service or extractive fallback. ${details.join('; ')}. Review AI output for errors. PDF output, if selected, is text reflow, not layout preservation. No OCR performed.`};
  }finally{clearTimeout(timer);external?.removeEventListener('abort',onAbort);model?.destroy?.();}
}
