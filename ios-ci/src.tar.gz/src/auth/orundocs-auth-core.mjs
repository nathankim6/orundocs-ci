// OrunDocs sign-in gate core. Platform-neutral, no DOM. Documents never leave the device:
// the only network calls are Google's token refresh and a read of the user's OWN allowlist entry.
export const AUTH_CONFIG = Object.freeze({
  apiKey: 'AIzaSyCtvGwVSwR0YoxPwNiVBLAWTDkyr-hDh3c', // public Firebase web key (not a secret)
  projectId: 'orundocs',
  signinUrl: 'https://orundocs.web.app/signin',
  adminUrl: 'https://orundocs.web.app/admin',
  appScheme: 'com.orundocs.app',
  offlineDays: 7,
  recheckHours: 6,
});
export const ALLOWED_PROVIDERS = Object.freeze(['google.com', 'apple.com', 'password']);
const DAY = 86400000, SKEW = 10 * 60000;
export class AuthError extends Error { constructor(code, message) { super(message); this.code = code; } }

export function randomState(bytes = 32, rng = globalThis.crypto) {
  const a = new Uint8Array(bytes); rng.getRandomValues(a);
  return btoa(String.fromCharCode(...a)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
export function buildSigninUrl({ target, state, port }, cfg = AUTH_CONFIG) {
  const q = new URLSearchParams({ target, state }); if (port != null) q.set('port', String(port));
  return cfg.signinUrl + '?' + q.toString();
}
export function decodeJwtPayload(token) {
  const part = String(token || '').split('.')[1]; if (!part) return null;
  try {
    const b = atob(part.replace(/-/g, '+').replace(/_/g, '/').padEnd(Math.ceil(part.length / 4) * 4, '='));
    return JSON.parse(decodeURIComponent(Array.from(b, c => '%' + c.charCodeAt(0).toString(16).padStart(2, '0')).join('')));
  } catch { return null; }
}
// Parses the fragment/query handed back by https://orundocs.web.app/signin.
export function parseCallback(urlOrFragment, expectedState) {
  const s = String(urlOrFragment || ''); const i = s.indexOf('#'); const j = s.indexOf('?');
  const raw = i >= 0 ? s.slice(i + 1) : j >= 0 ? s.slice(j + 1) : s;
  const p = new URLSearchParams(raw);
  if (!expectedState || p.get('state') !== expectedState) throw new AuthError('state', '로그인 요청이 일치하지 않습니다. 다시 시도해 주세요.');
  const refreshToken = p.get('rt');
  if (!refreshToken || refreshToken.length < 20) throw new AuthError('token', '로그인 정보가 비어 있습니다. 다시 시도해 주세요.');
  return { refreshToken, email: (p.get('email') || '').toLowerCase() };
}
function isNetworkFailure(e) { return e && (e.name === 'TypeError' || e.name === 'AbortError' || e.code === 'network'); }
async function timedFetch(fetchImpl, url, init, ms = 15000) {
  const ac = typeof AbortController === 'function' ? new AbortController() : null;
  const t = ac ? setTimeout(() => ac.abort(), ms) : null;
  try { return await fetchImpl(url, { ...init, signal: ac?.signal }); } finally { if (t) clearTimeout(t); }
}
// Online check. Returns {kind:'allowed', session} | {kind:'blocked', reason} | throws {code:'network'} when offline/unreachable.
export async function checkOnline(session, { fetch: f = globalThis.fetch, now = Date.now(), cfg = AUTH_CONFIG } = {}) {
  let tr;
  try {
    tr = await timedFetch(f, 'https://securetoken.googleapis.com/v1/token?key=' + encodeURIComponent(cfg.apiKey), {
      method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ grant_type: 'refresh_token', refresh_token: session.refreshToken }).toString(),
    });
  } catch (e) { if (isNetworkFailure(e)) throw new AuthError('network', '인터넷에 연결할 수 없습니다.'); throw e; }
  if (tr.status >= 500 || tr.status === 429) throw new AuthError('network', '로그인 서버가 잠시 응답하지 않습니다.');
  const tj = await tr.json().catch(() => ({}));
  if (!tr.ok || !tj.id_token) return { kind: 'blocked', reason: 'token:' + (tj.error?.message || tr.status) };
  const claims = decodeJwtPayload(tj.id_token) || {};
  const email = String(claims.email || '').toLowerCase();
  if (!email || !ALLOWED_PROVIDERS.includes(claims.firebase?.sign_in_provider)) return { kind: 'blocked', reason: 'provider' };
  let ar;
  try {
    ar = await timedFetch(f, 'https://firestore.googleapis.com/v1/projects/' + cfg.projectId + '/databases/(default)/documents/allowlist/' + encodeURIComponent(email), {
      headers: { authorization: 'Bearer ' + tj.id_token },
    });
  } catch (e) { if (isNetworkFailure(e)) throw new AuthError('network', '인터넷에 연결할 수 없습니다.'); throw e; }
  if (ar.status >= 500 || ar.status === 429) throw new AuthError('network', '허용 목록 서버가 잠시 응답하지 않습니다.');
  if (ar.status !== 200) return { kind: 'blocked', reason: 'allowlist:' + ar.status, email };
  return { kind: 'allowed', session: { v: 1, email, refreshToken: tj.refresh_token || session.refreshToken, lastVerifiedAt: now, maxSeenAt: Math.max(now, session.maxSeenAt || 0) } };
}
// Offline grace: up to cfg.offlineDays after the last successful online check. Clock rollback voids the grace.
export function offlineGrace(session, now = Date.now(), cfg = AUTH_CONFIG) {
  const last = Number(session?.lastVerifiedAt) || 0, maxSeen = Number(session?.maxSeenAt) || last;
  if (!last) return { ok: false, reason: 'never-verified' };
  if (now + SKEW < last || now + SKEW < maxSeen) return { ok: false, reason: 'clock' };
  const left = last + cfg.offlineDays * DAY - now;
  if (left <= 0) return { ok: false, reason: 'expired' };
  return { ok: true, msLeft: left, daysLeft: Math.ceil(left / DAY) };
}
// Full launch decision.
export async function evaluateSession(session, opts = {}) {
  const now = opts.now ?? Date.now(), cfg = opts.cfg || AUTH_CONFIG;
  if (!session || !session.refreshToken) return { status: 'signed-out' };
  try {
    const r = await checkOnline(session, { ...opts, now, cfg });
    if (r.kind === 'allowed') return { status: 'allowed', session: r.session };
    return { status: 'blocked', reason: r.reason, email: r.email || session.email };
  } catch (e) {
    if (e?.code !== 'network') throw e;
    const g = offlineGrace(session, now, cfg);
    if (g.ok) return { status: 'offline', session: { ...session, maxSeenAt: Math.max(now, session.maxSeenAt || 0) }, daysLeft: g.daysLeft, msLeft: g.msLeft };
    return { status: 'offline-expired', reason: g.reason, email: session.email };
  }
}

// Permanently deletes the signed-in Firebase account (App Store 5.1.1(v)). Requires network.
export async function deleteAccount(session, { fetch: f = globalThis.fetch, cfg = AUTH_CONFIG } = {}) {
  let tr;
  try {
    tr = await timedFetch(f, 'https://securetoken.googleapis.com/v1/token?key=' + encodeURIComponent(cfg.apiKey), { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ grant_type: 'refresh_token', refresh_token: session.refreshToken }).toString() });
  } catch (e) { throw new AuthError('network', '인터넷에 연결되어 있어야 계정을 삭제할 수 있습니다.'); }
  const tj = await tr.json().catch(() => ({}));
  if (!tr.ok || !tj.id_token) { if (tr.status === 400) return { deleted: true, already: true }; throw new AuthError('server', '계정을 확인하지 못했습니다. 잠시 후 다시 시도하세요.'); }
  let dr;
  try { dr = await timedFetch(f, 'https://identitytoolkit.googleapis.com/v1/accounts:delete?key=' + encodeURIComponent(cfg.apiKey), { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ idToken: tj.id_token }) }); }
  catch (e) { throw new AuthError('network', '인터넷에 연결되어 있어야 계정을 삭제할 수 있습니다.'); }
  if (!dr.ok) throw new AuthError('server', '계정을 삭제하지 못했습니다. 잠시 후 다시 시도하세요.');
  return { deleted: true };
}
