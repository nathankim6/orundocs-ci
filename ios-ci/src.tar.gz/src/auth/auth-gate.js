// OrunDocs sign-in gate (UI + platform adapters). Loaded before the workspace scripts.
// <html class="od-locked"> hides the workspace until an allowed session is confirmed.
import { AUTH_CONFIG, AuthError, randomState, buildSigninUrl, parseCallback, evaluateSession, deleteAccount } from './orundocs-auth-core.mjs';

const LS_KEY = 'orundocs.session.v1', PENDING_KEY = 'orundocs.pending', PENDING_MS = 10 * 60000;
function platform() {
  const desk = globalThis.pdfDesktop?.auth;
  if (desk) return {
    name: 'desktop',
    get: () => desk.get(), set: s => desk.set(s), clear: () => desk.clear(),
    // Main process runs a 127.0.0.1 loopback receiver, opens the system browser and resolves with the fragment.
    signIn: state => desk.signIn(state),
    open: url => desk.openExternal(url),
  };
  const cap = globalThis.Capacitor, plug = cap?.Plugins?.OrunAuth;
  if (cap?.isNativePlatform?.() && plug) return {
    name: cap.getPlatform?.() || 'mobile',
    get: async () => { try { return JSON.parse(localStorage.getItem(LS_KEY) || 'null'); } catch { return null; } },
    set: async s => localStorage.setItem(LS_KEY, JSON.stringify(s)),
    clear: async () => localStorage.removeItem(LS_KEY),
    // Android: browser + com.orundocs.app://auth deep link. iOS: ASWebAuthenticationSession.
    signIn: async state => (await plug.signIn({ url: buildSigninUrl({ target: 'app', state }), scheme: AUTH_CONFIG.appScheme })).url,
    open: url => plug.openExternal({ url }),
    // Android only: callback that arrived after the app process was restarted.
    coldStart: async () => { try { return (await plug.consumeColdStartUrl?.())?.url || null; } catch { return null; } },
  };
  return null;
}

const el = (tag, props = {}, ...kids) => { const e = Object.assign(document.createElement(tag), props); e.append(...kids); return e; };
const fmtLeft = ms => { const h = Math.max(1, Math.round(ms / 3600000)); return h >= 48 ? `${Math.ceil(h / 24)}일` : `${h}시간`; };

class Gate {
  constructor(p) {
    this.p = p; this.session = null; this.busy = false;
    this.msg = el('p', { className: 'od-msg', role: 'status' });
    this.btn = el('button', { type: 'button', className: 'od-google', onclick: () => this.signIn() },
      el('span', { className: 'od-g', textContent: 'G', ariaHidden: 'true' }), el('span', { textContent: '로그인 (Google · Apple)' }));
    this.retry = el('button', { type: 'button', className: 'od-ghost', textContent: '다시 확인', hidden: true, onclick: () => this.boot() });
    const admin = el('button', { type: 'button', className: 'od-link', textContent: '관리자 페이지(허용 이메일 관리)', onclick: () => this.p?.open(AUTH_CONFIG.adminUrl) });
    this.root = el('div', { id: 'od-gate', role: 'dialog', ariaModal: 'true', ariaLabel: 'OrunDocs 로그인' },
      el('div', { className: 'od-card' },
        el('img', { className: 'od-logo', src: '/app-icon.png', alt: '' }),
        el('h1', { textContent: 'OrunDocs' }),
        this.msg, this.btn, this.retry,
        el('p', { className: 'od-note', textContent: '관리자가 허용한 계정만 사용할 수 있습니다. 문서는 서버로 보내지 않고 이 기기에서만 처리합니다.' }),
        admin));
    this.chip = el('button', { type: 'button', id: 'od-account', hidden: true, onclick: () => this.toggleMenu() });
    this.menu = el('div', { id: 'od-account-menu', hidden: true });
  }
  mount() {
    document.body.append(this.root, this.menu);
    const bar = document.querySelector('.app-topbar-actions');
    if (bar) { this.chip.classList.add('od-inline'); bar.prepend(this.chip); } else document.body.append(this.chip);
    document.addEventListener('click', e => { if (!this.menu.hidden && !this.menu.contains(e.target) && e.target !== this.chip) this.menu.hidden = true; });
  }
  say(text, kind = '') { this.msg.textContent = text; this.msg.dataset.kind = kind; }
  lock(text, kind, { canSignIn = true, canRetry = false } = {}) {
    document.documentElement.classList.add('od-locked'); this.root.hidden = false; this.chip.hidden = true; this.menu.hidden = true;
    this.say(text, kind); this.btn.hidden = !canSignIn; this.retry.hidden = !canRetry; this.btn.disabled = false;
  }
  unlock(session, offline) {
    this.session = session; this.root.hidden = true; document.documentElement.classList.remove('od-locked');
    this.chip.hidden = false; this.chip.textContent = (offline ? '오프라인 · ' : '') + session.email;
    this.chip.title = offline ? `인터넷 연결 없이 ${fmtLeft(offline)} 더 사용할 수 있습니다.` : '로그인 계정';
    document.dispatchEvent(new CustomEvent('orundocs:auth', { detail: { email: session.email, offline: !!offline } }));
  }
  toggleMenu() {
    if (!this.menu.hidden) { this.menu.hidden = true; return; }
    this.menu.replaceChildren(
      el('div', { className: 'od-menu-email', textContent: this.session?.email || '' }),
      el('button', { type: 'button', textContent: '관리자 페이지', onclick: () => { this.menu.hidden = true; this.p.open(AUTH_CONFIG.adminUrl); } }),
      el('button', { type: 'button', textContent: '로그아웃', onclick: () => this.signOut() }),
      el('button', { type: 'button', className: 'od-danger', textContent: '계정 삭제', onclick: () => this.deleteAccount() }));
    this.menu.hidden = false;
    if (this.chip.classList.contains('od-inline')) { const r = this.chip.getBoundingClientRect(); this.menu.style.cssText = 'top:' + Math.round(r.bottom + 6) + 'px;right:' + Math.max(8, Math.round(innerWidth - r.right)) + 'px;left:auto;bottom:auto'; }
  }
  async deleteAccount() {
    this.menu.hidden = true;
    if (!confirm('로그인 계정을 영구 삭제할까요? 삭제 후에는 다시 로그인해야 하며, 다시 사용하려면 관리자의 허용이 필요할 수 있습니다. 기기에 저장한 문서는 지워지지 않습니다.')) return;
    try { await deleteAccount(await this.p.get()); await this.p.clear(); this.session = null; this.lock('계정을 삭제했습니다.', '', {}); }
    catch (e) { alert(e?.message || '계정을 삭제하지 못했습니다.'); }
  }
  async signOut() { await this.p.clear(); this.session = null; this.lock('로그아웃했습니다.', '', {}); }
  async apply(result) {
    switch (result.status) {
      case 'allowed': await this.p.set(result.session); this.unlock(result.session, 0); return true;
      case 'offline': await this.p.set(result.session); this.unlock(result.session, result.msLeft); return true;
      case 'blocked': await this.p.clear(); this.lock(`${result.email || '이 계정'}은(는) 사용 허용이 취소되었거나 허용되지 않은 이메일입니다. 관리자에게 문의하세요.`, 'err'); return false;
      case 'offline-expired': this.lock(result.reason === 'clock'
        ? '기기 시간이 바뀌어 오프라인 사용을 확인할 수 없습니다. 인터넷에 연결한 뒤 다시 확인해 주세요.'
        : '마지막 확인 후 7일이 지나 인터넷 연결이 필요합니다. 연결한 뒤 다시 확인해 주세요.', 'err', { canSignIn: false, canRetry: true }); return false;
      default: this.lock('Google 계정으로 로그인해 주세요.', ''); return false;
    }
  }
  async boot() {
    if (!this.p) { this.lock('이 환경에서는 로그인할 수 없습니다. OrunDocs 앱을 사용해 주세요.', 'err', { canSignIn: false }); return; }
    this.lock('로그인 상태를 확인하는 중…', '', { canSignIn: false });
    const cold = await this.p.coldStart?.();
    if (cold) {
      let pend = null; try { pend = JSON.parse(localStorage.getItem(PENDING_KEY) || 'null'); } catch {}
      localStorage.removeItem(PENDING_KEY);
      if (pend && Date.now() - pend.at < PENDING_MS) { await this.complete(cold, pend.state); return; }
    }
    let r; try { r = await evaluateSession(await this.p.get()); } catch (e) { r = { status: 'signed-out' }; }
    await this.apply(r);
  }
  async signIn() {
    if (this.busy) return; this.busy = true; this.btn.disabled = true;
    this.say('브라우저에서 Google 로그인을 마친 뒤 이 앱으로 돌아오세요…');
    try {
      const state = randomState();
      try { localStorage.setItem(PENDING_KEY, JSON.stringify({ state, at: Date.now() })); } catch {}
      const back = await this.p.signIn(state);
      await this.complete(back, state, true);
    } catch (e) {
      this.lock(e?.code === 'cancelled' || /cancel/i.test(e?.message || '') ? '로그인을 취소했습니다.' : (e?.message || '로그인하지 못했습니다.'), 'err');
    } finally { this.busy = false; this.btn.disabled = false; try { localStorage.removeItem(PENDING_KEY); } catch {} }
  }
  async complete(back, state, rethrow = false) {
    try {
      const { refreshToken } = parseCallback(back, state);
      this.say('허용된 이메일인지 확인하는 중…');
      const r = await evaluateSession({ v: 1, refreshToken, lastVerifiedAt: 0 });
      if (r.status === 'offline' || r.status === 'offline-expired') throw new AuthError('network', '인터넷에 연결되어 있어야 처음 로그인할 수 있습니다.');
      await this.apply(r);
    } catch (e) { if (rethrow) throw e; this.lock(e?.message || '로그인하지 못했습니다.', 'err'); }
  }
  // While the app stays open, re-check periodically; revoked users are locked out on the next online check.
  schedule() {
    setInterval(async () => {
      if (!this.session || this.busy) return;
      try { await this.apply(await evaluateSession(await this.p.get())); } catch {}
    }, AUTH_CONFIG.recheckHours * 3600000);
  }
}

function start() {
  const g = new Gate(platform()); g.mount(); g.boot(); g.schedule();
  globalThis.__orundocsGate = { status: () => ({ locked: document.documentElement.classList.contains('od-locked'), email: g.session?.email || null }) };
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true }); else start();
