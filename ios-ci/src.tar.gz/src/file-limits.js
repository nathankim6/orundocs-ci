// MB labels follow the app's existing binary-size convention: 1 MB = 1024*1024 bytes.
export const PDF_MAX_BYTES = 100 * 1024 * 1024;
export const TOTAL_MAX_BYTES = 500 * 1024 * 1024;
export const OTHER_UI_MAX_BYTES = 30 * 1024 * 1024;
export const REQUEST_MAX_BYTES = 160 * 1024 * 1024; // accommodates base64 of one 100 MB PDF
export function isPdfInput(file){return file?.type==='application/pdf'||/\.pdf$/i.test(String(file?.name||''));}
export function inputByteLimit(file,otherLimit=OTHER_UI_MAX_BYTES){return isPdfInput(file)?PDF_MAX_BYTES:otherLimit;}
