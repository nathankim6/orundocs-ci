// Background worker for the exam scanner. Decodes photos, detects the sheet, flattens it and removes handwriting.
// Everything stays inside this device; no network access is used.
import { detectDocument, processPage, downscale, MAX_SIDE } from './exam-scan-core.mjs';

const MAX_INPUT_BYTES = 30 * 1024 * 1024;

async function decode(file, maxSide) {
  if (!file || typeof file.size !== 'number' || file.size <= 0 || file.size > MAX_INPUT_BYTES) throw new Error('사진은 30 MB 이하여야 합니다.');
  let bitmap;
  try { bitmap = await createImageBitmap(file, { imageOrientation: 'from-image' }); }
  catch { throw new Error('사진을 읽을 수 없습니다. JPG·PNG·WebP 사진을 선택해 주세요.'); }
  const scale = Math.min(1, maxSide / Math.max(bitmap.width, bitmap.height));
  const w = Math.max(1, Math.round(bitmap.width * scale)), h = Math.max(1, Math.round(bitmap.height * scale));
  const canvas = new OffscreenCanvas(w, h), ctx = canvas.getContext('2d', { willReadFrequently: true });
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(bitmap, 0, 0, w, h);
  bitmap.close?.();
  const data = ctx.getImageData(0, 0, w, h);
  return { width: w, height: h, data: data.data };
}

async function encode(img, type, quality) {
  const canvas = new OffscreenCanvas(img.width, img.height);
  canvas.getContext('2d').putImageData(new ImageData(img.data, img.width, img.height), 0, 0);
  return canvas.convertToBlob({ type, quality });
}

self.onmessage = async ({ data }) => {
  const { id, cmd } = data;
  try {
    if (cmd === 'detect') {
      const img = await decode(data.file, 1600);
      const found = detectDocument(img);
      // Corners are returned normalised (0..1) so they survive any later resolution change.
      const corners = found.corners.map(([x, y]) => [x / (img.width - 1), y / (img.height - 1)]);
      self.postMessage({ id, ok: true, corners, detected: found.detected, confidence: found.confidence, aspect: img.width / img.height });
      return;
    }
    if (cmd === 'process') {
      const img = await decode(data.file, data.maxInputSide || 3200);
      const corners = data.corners.map(([x, y]) => [x * (img.width - 1), y * (img.height - 1)]);
      const r = processPage(img, { corners, rotate: data.rotate || 0, removeColor: data.removeColor, removePencil: data.removePencil, pencilSensitivity: data.pencilSensitivity, mode: data.mode, erase: data.erase !== false, maxSide: data.maxSide || MAX_SIDE });
      const quality = 0.9;
      const after = await encode(r.after, 'image/jpeg', quality);
      const before = await encode(r.before, 'image/jpeg', quality);
      self.postMessage({ id, ok: true, width: r.after.width, height: r.after.height, after, before, removedRatio: r.removedRatio });
      return;
    }
    throw new Error('Unknown command');
  } catch (error) {
    self.postMessage({ id, ok: false, error: error?.message || String(error) });
  }
};

export { downscale };
