import {PDFPreview as BasePreview} from './pdf-preview-base.js';
import {clampZoom,zoomFromWheel,applyPageSelection,rangePages,pagesInRect,pageSelectionGroups,pageRanges} from './pdf-preview-model.mjs';
import {zipSync} from 'fflate';

// Keep the existing password handling, local PDF.js loader and bounded single-page
// renderer. Gallery canvases are lazy, bounded and never uploaded or persisted.
const WINDOW_SIZE=100, LIVE_CANVASES=100, TILE_PIXELS=500000;
const svg=(path)=>`<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${path}"/></svg>`;
const fullscreenIcon=svg('M8 3H3v5M16 3h5v5M3 16v5h5M21 16v5h-5');
const singleIcon=svg('M6 3h12v18H6z');
const gridIcon=svg('M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z');

export class PDFPreview extends BasePreview {
  constructor(options){
    super(options);
    const priorOnPage=this.onPage;this.onPage=ctx=>{if(ctx)this.lastPageWidth=ctx.width;priorOnPage(ctx);};
    this._enhanced=true;this.viewMode='single';this.selectedPages=new Set();this.anchor=1;
    this.expanded=false;this.actionBusy=false;this.touchSelect=false;this.galleryStart=1;
    this.gridEpoch=0;this.gridTasks=new Map();this.gridQueue=[];this.liveCanvases=new Map();
    this.onPageAction=options.onPageAction;this.onDownload=options.onDownload;
    this.isAppBusy=options.isAppBusy||(()=>false);
    this.scroll=this.el('preview-scroll');this.scroll.tabIndex=0;this.scroll.setAttribute('role','region');
    this.scroll.setAttribute('aria-label','PDF 미리보기. Ctrl+마우스 휠로 확대 또는 축소');
    this.root.dataset.previewMode='single';
    const expand=document.createElement('button');expand.type='button';expand.className='secondary pdf-expand-button';expand.id=this.prefix+'-preview-expand';
    expand.innerHTML=fullscreenIcon+'<span>크게 보기</span>';expand.setAttribute('aria-label','PDF 미리보기 전체화면으로 크게 보기');expand.setAttribute('aria-pressed','false');
    this.root.querySelector('.pdf-preview-heading').append(expand);expand.onclick=()=>this.setExpanded(!this.expanded);
    const toolbar=this.root.querySelector('.pdf-preview-toolbar');
    const views=document.createElement('div');views.className='pdf-view-switch';views.setAttribute('role','group');views.setAttribute('aria-label','페이지 보기 방식');
    views.innerHTML=`<button type="button" id="${this.prefix}-preview-single" aria-pressed="true">${singleIcon}<span>한 페이지</span></button><button type="button" id="${this.prefix}-preview-grid" aria-pressed="false">${gridIcon}<span>여러 페이지</span></button>`;toolbar.prepend(views);
    const zoom=this.el('preview-zoom');zoom.replaceChildren();
    for(const [value,label] of [['fit','너비 맞춤'],['0.25','25%'],['0.5','50%'],['0.75','75%'],['1','100%'],['1.25','125%'],['1.5','150%'],['2','200%'],['3','300%'],['4','400%']])zoom.add(new Option(label,value));
    zoom.value='fit';zoom.onchange=()=>this.scheduleDraw();
    for(const [suffix,text,label,delta] of [['zoom-out','−','미리보기 축소',-1],['zoom-in','+','미리보기 확대',1]]){
      const b=document.createElement('button');b.type='button';b.className='secondary pdf-zoom-button';b.id=this.prefix+'-'+suffix;b.textContent=text;b.setAttribute('aria-label',label);b.onclick=()=>this.setZoom(this.currentZoom()*(delta>0?1.2:1/1.2));
      if(delta<0)zoom.before(b);else zoom.after(b);
    }
    const hint=document.createElement('small');hint.className='pdf-zoom-hint';hint.textContent='Ctrl + 휠로 크기 조절';toolbar.append(hint);
    this.el('preview-single').onclick=()=>this.setViewMode('single');this.el('preview-grid').onclick=()=>this.setViewMode('grid');
    const selection=document.createElement('div');selection.className='pdf-page-selectionbar';selection.id=this.prefix+'-selectionbar';
    selection.innerHTML=`<span id="${this.prefix}-selected-count" aria-live="polite">선택 없음</span><div><button type="button" class="text-button" id="${this.prefix}-select-all">전체 선택</button><button type="button" class="text-button" id="${this.prefix}-select-none">선택 해제</button><button type="button" class="secondary" id="${this.prefix}-touch-select" aria-pressed="false">다중 선택</button><button type="button" class="secondary" id="${this.prefix}-page-actions" aria-haspopup="menu" aria-expanded="false">선택 작업 ▾</button></div>`;
    toolbar.after(selection);
    this.el('select-all').onclick=()=>{if(!this.doc)return;this.selectedPages=new Set(Array.from({length:Math.min(this.doc.numPages,100000)},(_,i)=>i+1));this.updateSelection();};
    this.el('select-none').onclick=()=>{this.selectedPages.clear();this.updateSelection();};
    this.el('touch-select').onclick=()=>{this.touchSelect=!this.touchSelect;this.el('touch-select').setAttribute('aria-pressed',String(this.touchSelect));this.root.classList.toggle('pdf-touch-select',this.touchSelect);};
    this.el('page-actions').onclick=()=>{const r=this.el('page-actions').getBoundingClientRect();this.openMenu(r.left,r.bottom+5,this.el('page-actions'));};
    this.gallery=document.createElement('div');this.gallery.className='pdf-preview-grid';this.gallery.id=this.prefix+'-page-grid';this.gallery.hidden=true;this.gallery.setAttribute('aria-label','여러 PDF 페이지. 클릭, Ctrl+클릭 또는 드래그로 선택');this.scroll.append(this.gallery);
    this.windowBar=document.createElement('div');this.windowBar.className='pdf-gallery-window';this.windowBar.hidden=true;
    this.windowBar.innerHTML=`<button type="button" class="secondary" id="${this.prefix}-gallery-prev">이전 100페이지</button><span id="${this.prefix}-gallery-range"></span><button type="button" class="secondary" id="${this.prefix}-gallery-next">다음 100페이지</button>`;this.scroll.after(this.windowBar);
    this.el('gallery-prev').onclick=()=>{this.galleryStart=Math.max(1,this.galleryStart-WINDOW_SIZE);this.page=this.galleryStart;this.renderGallery();};
    this.el('gallery-next').onclick=()=>{if(this.doc){this.galleryStart=Math.min(Math.floor((this.doc.numPages-1)/WINDOW_SIZE)*WINDOW_SIZE+1,this.galleryStart+WINDOW_SIZE);this.page=this.galleryStart;this.renderGallery();}};
    this.marquee=document.createElement('div');this.marquee.className='pdf-selection-marquee';this.marquee.hidden=true;this.root.append(this.marquee);
    this.menu=document.createElement('div');this.menu.className='pdf-page-context-menu';this.menu.hidden=true;this.menu.setAttribute('role','menu');this.menu.setAttribute('aria-label','선택한 PDF 페이지 작업');
    for(const [action,label,description] of [['extract','선택 페이지 내보내기','선택한 페이지를 PDF 하나로 저장'],['separate','페이지별로 각각 분리','선택한 페이지마다 별도 PDF 생성'],['partition','선택 / 나머지로 분할','선택 페이지와 나머지를 별도 PDF로 생성']]){
      const b=document.createElement('button');b.type='button';b.setAttribute('role','menuitem');b.dataset.action=action;const strong=document.createElement('strong'),small=document.createElement('small');strong.textContent=label;small.textContent=description;b.append(strong,small);b.onclick=()=>this.performAction(action);this.menu.append(b);
    }
    const menuNote=document.createElement('p');menuNote.textContent='원본은 유지됩니다. 결과를 확인한 뒤 저장하세요.';this.menu.append(menuNote);this.root.append(this.menu);
    this.result=document.createElement('section');this.result.className='pdf-page-action-results';this.result.hidden=true;this.result.setAttribute('aria-label','선택 페이지 작업 결과');this.root.append(this.result);
    this.gallery.addEventListener('click',e=>this.clickPage(e));
    this.gallery.addEventListener('dblclick',e=>{const tile=e.target.closest('.pdf-page-tile');if(tile){this.page=Number(tile.dataset.page);this.setViewMode('single');}});
    this.gallery.addEventListener('keydown',e=>this.galleryKey(e));
    this.scroll.addEventListener('wheel',e=>this.wheel(e),{passive:false});
    this.scroll.addEventListener('pointerdown',e=>this.startDrag(e));
    this.scroll.addEventListener('pointermove',e=>this.moveDrag(e));
    this.scroll.addEventListener('pointerup',e=>this.endDrag(e));
    this.scroll.addEventListener('pointercancel',e=>this.endDrag(e));
    this.root.addEventListener('contextmenu',e=>{
      if(!this.doc||!(e.target.closest('.pdf-page-tile')||e.target.closest('.pdf-preview-stage')||e.target===this.gallery))return;
      e.preventDefault();const tile=e.target.closest('.pdf-page-tile'),n=tile?Number(tile.dataset.page):this.page;
      // macOS emits contextmenu, not click, for Ctrl+LEFT click. Preserve the requested selection gesture.
      if(tile&&e.ctrlKey&&e.button===0){this.clickPage({target:tile,ctrlKey:true,metaKey:e.metaKey,shiftKey:e.shiftKey,detail:0});this.suppressClick=true;return;}
      if(!this.selectedPages.has(n)){this.selectedPages=new Set([n]);this.page=n;this.anchor=n;this.updateSelection();}
      this.openMenu(e.clientX,e.clientY,tile||this.canvas);
    });
    this.root.addEventListener('keydown',e=>this.key(e));
    document.addEventListener('keydown',e=>{if(!this.expanded||this.root.contains(e.target))return;if(e.key==='Escape'){e.preventDefault();this.setExpanded(false);}else if(e.key==='Tab'){e.preventDefault();this.el('preview-expand').focus();}});
    document.addEventListener('pointerdown',e=>{if(!this.menu.hidden&&!this.menu.contains(e.target)&&e.target!==this.el('page-actions'))this.closeMenu(false);});
    this.resizeObserver=typeof ResizeObserver!=='undefined'?new ResizeObserver(()=>{
      const width=this.scroll.clientWidth;if(width===this.lastWidth)return;this.lastWidth=width;
      if(this.doc&&(this.el('preview-zoom').value==='fit'||this.viewMode==='grid'))this.scheduleDraw();
    }):null;this.resizeObserver?.observe(this.scroll);this.controls();
  }
  controls(){
    super.controls();if(!this._enhanced)return;
    const ready=!!this.doc&&!this.actionBusy;
    for(const key of ['preview-file','preview-page','preview-zoom','preview-single','preview-grid','zoom-out','zoom-in','select-all','select-none','touch-select'])this.el(key).disabled=!ready;
    this.el('page-actions').disabled=!ready||!this.selectedPages.size;
    this.el('preview-prev').disabled=!ready||this.page<=1;this.el('preview-next').disabled=!ready||this.page>=this.doc.numPages;
    this.el('preview-single').setAttribute('aria-pressed',String(this.viewMode==='single'));
    this.el('preview-grid').setAttribute('aria-pressed',String(this.viewMode==='grid'));
    this.el('preview-page').value=this.page;
  }
  cancelGrid(){
    this.gridEpoch=(this.gridEpoch||0)+1;this.gridObserver?.disconnect();this.gridObserver=null;
    for(const task of this.gridTasks?.values()||[])task.cancel();this.gridTasks?.clear();this.gridQueue=[];
    for(const {canvas}of this.liveCanvases?.values()||[])canvas.width=canvas.height=1;this.liveCanvases?.clear();
  }
  cancelDraw(){super.cancelDraw();this.cancelGrid();}
  dispose(){clearTimeout(this.drawTimer);this.closeMenu?.(false);super.dispose();}
  clear(){
    if(this._enhanced){this.setExpanded(false);this.result.hidden=true;this.result.replaceChildren();this.selectedPages.clear();this.gallery.replaceChildren();this.windowBar.hidden=true;}
    super.clear();if(this._enhanced)this.updateSelection();
  }
  async load(){
    if(this._enhanced){this.selectedPages=new Set([this.page||1]);this.anchor=this.page||1;this.galleryStart=1;this.result.hidden=true;this.result.replaceChildren();this.closeMenu(false);}
    await super.load();if(this._enhanced&&this.doc){this.selectedPages=new Set([this.page]);this.anchor=this.page;this.updateSelection();}
  }
  setSelectable(value){super.setSelectable(value);if(this._enhanced&&this.viewMode==='grid'){this.overlay.hidden=true;this.el('preview-help').hidden=true;}}
  setViewMode(mode){
    if(!this.doc||!['single','grid'].includes(mode)||this.actionBusy)return;this.viewMode=mode;this.root.dataset.previewMode=mode;
    if(mode==='grid')this.galleryStart=Math.floor((this.page-1)/WINDOW_SIZE)*WINDOW_SIZE+1;
    this.controls();this.renderPage();
  }
  showPage(value){
    if(!this.doc||this.actionBusy)return;this.page=Math.max(1,Math.min(this.doc.numPages,Math.trunc(Number(value))||1));
    this.selectedPages=new Set([this.page]);this.anchor=this.page;
    if(this.viewMode==='grid'){
      const start=Math.floor((this.page-1)/WINDOW_SIZE)*WINDOW_SIZE+1;
      if(start!==this.galleryStart){this.galleryStart=start;this.renderGallery().then(()=>this.gallery.querySelector(`[data-page="${this.page}"]`)?.scrollIntoView({block:'nearest'}));}else{this.controls();this.updateSelection();this.gallery.querySelector(`[data-page="${this.page}"]`)?.scrollIntoView({block:'nearest'});}
      return;
    }
    return this.renderPage();
  }
  async renderPage(){
    if(!this._enhanced)return super.renderPage();
    this.el('preview-stage').hidden=this.viewMode==='grid';this.gallery.hidden=this.viewMode!=='grid';this.el('preview-thumbs').hidden=this.viewMode==='grid';
    if(this.viewMode==='grid')return this.renderGallery();
    this.windowBar.hidden=true;this.gallery.replaceChildren();await super.renderPage();this.updateSelection();
  }
  currentZoom(){
    const value=this.el('preview-zoom').value;if(value!=='fit')return clampZoom(Number(value));
    if(this.viewMode==='grid')return this.tileWidth()/200;
    const css=parseFloat(this.canvas.style.width),pt=this.lastPageWidth;
    return css&&pt?clampZoom(css/(pt*96/72)):1;
  }
  setZoom(value,anchor=null){
    if(!this.doc||this.actionBusy)return;value=Math.round(clampZoom(value)*1000)/1000;
    const zoom=this.el('preview-zoom');let option=Array.from(zoom.options).find(o=>Math.abs(Number(o.value)-value)<.0001);
    if(!option){option=Array.from(zoom.options).find(o=>o.dataset.custom==='true');if(!option){option=new Option();option.dataset.custom='true';zoom.add(option);}option.value=String(value);option.textContent=Math.round(value*100)+'%';}
    zoom.value=option.value;this.zoomAnchor=anchor;this.scheduleDraw();
  }
  scheduleDraw(){clearTimeout(this.drawTimer);this.drawTimer=setTimeout(()=>this.redrawWithAnchor(),90);}
  async redrawWithAnchor(){
    if(!this.doc)return;const anchor=this.zoomAnchor;this.zoomAnchor=null;await this.renderPage();
    if(!anchor)return;
    if(anchor.page&&this.viewMode==='grid'){
      const tile=this.gallery.querySelector(`[data-page="${anchor.page}"]`);if(tile){const r=tile.getBoundingClientRect();this.scroll.scrollTop+=r.top-anchor.top;}
    }else if(this.viewMode==='single'){
      this.scroll.scrollLeft=anchor.x*this.scroll.scrollWidth-anchor.offsetX;this.scroll.scrollTop=anchor.y*this.scroll.scrollHeight-anchor.offsetY;
    }
  }
  wheel(e){
    if(!(e.ctrlKey||e.metaKey)||!this.doc||this.actionBusy)return;e.preventDefault();
    const r=this.scroll.getBoundingClientRect(),tile=e.target.closest('.pdf-page-tile');
    const anchor=tile?{page:Number(tile.dataset.page),top:tile.getBoundingClientRect().top}:{x:(this.scroll.scrollLeft+e.clientX-r.left)/Math.max(1,this.scroll.scrollWidth),y:(this.scroll.scrollTop+e.clientY-r.top)/Math.max(1,this.scroll.scrollHeight),offsetX:e.clientX-r.left,offsetY:e.clientY-r.top};
    this.setZoom(zoomFromWheel(this.currentZoom(),e.deltaY,e.deltaMode),anchor);
  }
  tileWidth(){const available=Math.max(120,this.scroll.clientWidth-34),choice=this.el('preview-zoom').value;return choice==='fit'?Math.min(210,Math.max(120,(available-14)/2)):200*clampZoom(Number(choice));}
  async renderGallery(){
    if(!this.doc)return;this.cancelDraw();const epoch=this.gridEpoch,revision=this.revision,doc=this.doc;
    this.onPage(null);this.setSelectable(this.selectable);this.controls();
    this.canvas.width=this.canvas.height=this.overlay.width=this.overlay.height=1;this.el('preview-thumbs').replaceChildren();
    this.el('preview-stage').hidden=true;this.gallery.hidden=false;this.el('preview-thumbs').hidden=true;
    this.gallery.replaceChildren();this.gallery.style.setProperty('--pdf-tile-width',this.tileWidth()+'px');
    const end=Math.min(doc.numPages,this.galleryStart+WINDOW_SIZE-1);this.windowBar.hidden=doc.numPages<=WINDOW_SIZE;
    this.el('gallery-range').textContent=this.galleryStart+'–'+end+' / '+doc.numPages+'페이지';
    this.el('gallery-prev').disabled=this.galleryStart<=1;this.el('gallery-next').disabled=end>=doc.numPages;
    const fragment=document.createDocumentFragment();
    for(let n=this.galleryStart;n<=end;n++){
      const b=document.createElement('button');b.type='button';b.className='pdf-page-tile';b.dataset.page=String(n);b.id=this.prefix+'-page-'+n;b.tabIndex=n===this.page?0:-1;
      const paper=document.createElement('span');paper.className='pdf-tile-paper';const placeholder=document.createElement('span');placeholder.className='pdf-tile-placeholder';placeholder.textContent=String(n);paper.append(placeholder);
      const caption=document.createElement('span');caption.className='pdf-tile-caption';const number=document.createElement('strong');number.textContent=n+'페이지';const check=document.createElement('span');check.className='pdf-tile-check';check.setAttribute('aria-hidden','true');caption.append(number,check);b.append(paper,caption);fragment.append(b);
    }
    this.gallery.append(fragment);this.updateSelection();
    this.el('geometry').textContent=doc.numPages+'페이지 · 여러 페이지 보기 · 화면에 보이는 페이지만 렌더링';
    this.status((this.current.role==='output'?'작업 결과':'원본')+' · '+this.current.file.name+' · 클릭 / Ctrl+클릭 / 드래그로 페이지 선택');
    const queue=tile=>{const n=Number(tile.dataset.page);if(!this.liveCanvases.has(n)&&!this.gridQueue.includes(tile)){this.gridQueue.push(tile);this.pumpGallery(epoch,revision);}};
    if(typeof IntersectionObserver!=='undefined'){
      this.gridObserver=new IntersectionObserver(entries=>{
        if(epoch!==this.gridEpoch)return;
        for(const entry of entries){entry.target.dataset.visible=entry.isIntersecting?'true':'false';if(entry.isIntersecting)queue(entry.target);else this.releaseTile(entry.target);}
      },{root:this.scroll,rootMargin:'140px 0px'});
      for(const tile of this.gallery.children)this.gridObserver.observe(tile);
    }else for(const tile of Array.from(this.gallery.children).slice(0,LIVE_CANVASES)){tile.dataset.visible='true';queue(tile);}
  }
  releaseTile(tile){
    const n=Number(tile.dataset.page),record=this.liveCanvases.get(n);if(!record)return;
    const task=this.gridTasks.get(n);if(task){task.cancel();return;}
    record.canvas.width=record.canvas.height=1;record.canvas.remove();tile.querySelector('.pdf-tile-placeholder').hidden=false;tile.classList.remove('is-rendered');this.liveCanvases.delete(n);
  }
  async pumpGallery(epoch,revision){
    if(this.pumpingEpoch===epoch)return;this.pumpingEpoch=epoch;
    try{
      while(this.gridQueue.length&&epoch===this.gridEpoch&&revision===this.revision){
        const tile=this.gridQueue.shift(),n=Number(tile.dataset.page);
        if(!tile.isConnected||tile.dataset.visible!=='true'||this.liveCanvases.has(n))continue;
        if(this.liveCanvases.size>=LIVE_CANVASES){
          const candidate=Array.from(this.liveCanvases.values()).find(r=>r.tile.dataset.visible!=='true');
          if(candidate)this.releaseTile(candidate.tile);else continue;
        }
        let canvas;
        try{
          const page=await this.doc.getPage(n);if(epoch!==this.gridEpoch||revision!==this.revision)return;
          const raw=page.getViewport({scale:1}),cssWidth=Math.max(35,this.tileWidth()-14),cssScale=cssWidth/raw.width;
          const visible=Array.from(this.gallery.querySelectorAll('[data-visible="true"]'));
          const waiting=Math.max(1,visible.filter(t=>!this.liveCanvases.has(Number(t.dataset.page))).length);
          const used=Array.from(this.liveCanvases.values()).reduce((sum,r)=>sum+r.canvas.width*r.canvas.height,0);
          const budget=Math.max(1,Math.min(TILE_PIXELS,Math.floor((7500000-used)/waiting)));
          const ratio=Math.min(globalThis.devicePixelRatio||1,2,Math.sqrt(budget/(cssWidth*cssWidth*raw.height/raw.width)),2048/Math.max(cssWidth,cssWidth*raw.height/raw.width));
          const vp=page.getViewport({scale:cssScale*ratio});canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.ceil(vp.width));canvas.height=Math.max(1,Math.ceil(vp.height));canvas.setAttribute('aria-hidden','true');
          tile.querySelector('.pdf-tile-paper').append(canvas);this.liveCanvases.set(n,{tile,canvas});
          const task=page.render({canvasContext:canvas.getContext('2d'),viewport:vp,background:'#fff'});this.gridTasks.set(n,task);
          try{await task.promise;}finally{if(this.gridTasks.get(n)===task)this.gridTasks.delete(n);}
          if(epoch!==this.gridEpoch||revision!==this.revision)return;
          tile.querySelector('.pdf-tile-placeholder').hidden=true;tile.classList.add('is-rendered');
          if(tile.dataset.visible!=='true')this.releaseTile(tile);
        }catch(error){
          if(canvas){canvas.width=canvas.height=1;canvas.remove();if(this.liveCanvases.get(n)?.canvas===canvas)this.liveCanvases.delete(n);}
          if(error.name!=='RenderingCancelledException'&&epoch===this.gridEpoch){tile.classList.add('is-page-error');tile.querySelector('.pdf-tile-placeholder').textContent=n+' · 미리보기 실패';}
        }
      }
    }finally{if(this.pumpingEpoch===epoch)this.pumpingEpoch=null;}
  }
  clickPage(e){
    if(this.suppressClick&&e.detail!==0){this.suppressClick=false;return;}this.suppressClick=false;const tile=e.target.closest('.pdf-page-tile');if(!tile||this.actionBusy)return;
    const n=Number(tile.dataset.page),additive=e.ctrlKey||e.metaKey||this.touchSelect;
    if(e.shiftKey)this.selectedPages=applyPageSelection(this.selectedPages,rangePages(this.anchor,n,this.doc.numPages),{additive});
    else{this.selectedPages=applyPageSelection(this.selectedPages,[n],{toggle:additive});this.anchor=n;}
    this.page=n;this.updateSelection();this.controls();
  }
  updateSelection(){
    if(!this._enhanced)return;const count=this.selectedPages.size;
    this.el('selected-count').textContent=count?count+'페이지 선택 · '+(count<=10?pageRanges(this.selectedPages):'선택 작업 메뉴 사용'):'클릭하거나 드래그해서 페이지를 선택하세요';
    for(const tile of this.gallery.children){const n=Number(tile.dataset.page),selected=this.selectedPages.has(n);tile.classList.toggle('is-selected',selected);tile.setAttribute('aria-pressed',String(selected));tile.setAttribute('aria-label',n+'페이지'+(selected?', 선택됨':''));tile.tabIndex=n===this.page?0:-1;}
    this.controls();
  }
  startDrag(e){
    this.suppressClick=false;
    if(this.viewMode!=='grid'||!this.doc||this.actionBusy||e.button!==0||(e.pointerType==='touch'&&!this.touchSelect))return;
    if(!(e.target.closest('.pdf-page-tile')||e.target===this.gallery||e.target===this.scroll))return;
    this.drag={x:e.clientX,y:e.clientY,lastX:e.clientX,lastY:e.clientY,scrollX:this.scroll.scrollLeft,scrollY:this.scroll.scrollTop,id:e.pointerId,initial:new Set(this.selectedPages),additive:e.ctrlKey||e.metaKey||this.touchSelect,active:false};
  }
  moveDrag(e){
    const d=this.drag;if(!d||d.id!==e.pointerId)return;d.lastX=e.clientX;d.lastY=e.clientY;
    if(!d.active&&Math.hypot(e.clientX-d.x,e.clientY-d.y)<6)return;
    if(!d.active){d.active=true;this.scroll.setPointerCapture(e.pointerId);this.root.classList.add('is-page-dragging');}
    e.preventDefault();this.paintDrag();
    if(!this.dragFrame)this.dragFrame=requestAnimationFrame(()=>this.autoScrollDrag());
  }
  paintDrag(){
    const d=this.drag;if(!d?.active)return;const rect={left:Math.min(d.x+d.scrollX-this.scroll.scrollLeft,d.lastX),top:Math.min(d.y+d.scrollY-this.scroll.scrollTop,d.lastY),right:Math.max(d.x+d.scrollX-this.scroll.scrollLeft,d.lastX),bottom:Math.max(d.y+d.scrollY-this.scroll.scrollTop,d.lastY)};
    Object.assign(this.marquee.style,{left:rect.left+'px',top:rect.top+'px',width:(rect.right-rect.left)+'px',height:(rect.bottom-rect.top)+'px'});this.marquee.hidden=false;
    const items=Array.from(this.gallery.children,tile=>{const r=tile.getBoundingClientRect();return{page:Number(tile.dataset.page),left:r.left,top:r.top,right:r.right,bottom:r.bottom};});
    const hits=pagesInRect(items,rect);this.selectedPages=applyPageSelection(d.initial,hits,{additive:d.additive});this.updateSelection();
  }
  autoScrollDrag(){
    this.dragFrame=null;const d=this.drag;if(!d?.active)return;const r=this.scroll.getBoundingClientRect();let delta=0;
    if(d.lastY>r.bottom-35)delta=14;else if(d.lastY<r.top+35)delta=-14;
    if(delta){const before=this.scroll.scrollTop;this.scroll.scrollTop+=delta;if(this.scroll.scrollTop!==before){this.paintDrag();this.dragFrame=requestAnimationFrame(()=>this.autoScrollDrag());}}
  }
  endDrag(e){
    const d=this.drag;if(!d||d.id!==e.pointerId)return;
    if(d.active){e.preventDefault();this.suppressClick=true;if(this.scroll.hasPointerCapture(e.pointerId))this.scroll.releasePointerCapture(e.pointerId);}
    this.drag=null;if(this.dragFrame)cancelAnimationFrame(this.dragFrame);this.dragFrame=null;this.marquee.hidden=true;this.root.classList.remove('is-page-dragging');
  }
  galleryKey(e){
    const tile=e.target.closest('.pdf-page-tile');if(!tile||!this.doc)return;
    const n=Number(tile.dataset.page),columns=Math.max(1,Math.floor((this.gallery.clientWidth+14)/(this.tileWidth()+14)));
    const delta={ArrowLeft:-1,ArrowRight:1,ArrowUp:-columns,ArrowDown:columns}[e.key];
    if(delta!==undefined){e.preventDefault();const next=Math.max(1,Math.min(this.doc.numPages,n+delta));
      if(e.shiftKey)this.selectedPages=applyPageSelection(this.selectedPages,rangePages(this.anchor,next,this.doc.numPages),{additive:e.ctrlKey||e.metaKey});else if(!(e.ctrlKey||e.metaKey)){this.selectedPages=new Set([next]);this.anchor=next;}
      this.page=next;const start=Math.floor((next-1)/WINDOW_SIZE)*WINDOW_SIZE+1;
      if(start!==this.galleryStart){this.galleryStart=start;this.renderGallery().then(()=>this.gallery.querySelector(`[data-page="${next}"]`)?.focus());}else{this.updateSelection();this.gallery.querySelector(`[data-page="${next}"]`)?.focus();}
    }
  }
  key(e){
    if(e.key==='Escape'){if(!this.menu.hidden){e.preventDefault();e.stopPropagation();this.closeMenu();}else if(this.expanded){e.preventDefault();this.setExpanded(false);}return;}
    if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='a'&&!['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName)){e.preventDefault();this.el('select-all').click();return;}
    if((e.key==='ContextMenu'||(e.shiftKey&&e.key==='F10'))&&this.doc){e.preventDefault();const tile=this.gallery.querySelector(`[data-page="${this.page}"]`),r=(tile||this.canvas).getBoundingClientRect();this.openMenu(r.left+15,r.top+15,tile||this.canvas);return;}
    if(!this.menu.hidden&&['ArrowDown','ArrowUp','Home','End'].includes(e.key)){
      e.preventDefault();const items=Array.from(this.menu.querySelectorAll('button:not(:disabled)')),i=items.indexOf(document.activeElement);let next=e.key==='Home'?0:e.key==='End'?items.length-1:(i+(e.key==='ArrowDown'?1:-1)+items.length)%items.length;items[next]?.focus();return;
    }
    if(e.key==='Tab'&&this.expanded){const items=Array.from(this.root.querySelectorAll('button,input,select,textarea,[tabindex="0"]')).filter(el=>!el.disabled&&el.tabIndex>=0&&el.getClientRects().length),first=items[0],last=items[items.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus();}}
  }
  openMenu(x,y,trigger){
    if(!this.doc||this.actionBusy)return;this.menuTrigger=trigger;this.menu.hidden=false;this.el('page-actions').setAttribute('aria-expanded','true');
    for(const b of this.menu.querySelectorAll('button'))b.disabled=!this.selectedPages.size||!this.onPageAction||this.doc.numPages>500||this.isAppBusy();
    const r=this.menu.getBoundingClientRect();this.menu.style.left=Math.max(8,Math.min(x,innerWidth-r.width-8))+'px';this.menu.style.top=Math.max(8,Math.min(y,innerHeight-r.height-8))+'px';
    this.menu.querySelector('button:not(:disabled)')?.focus();
    if(this.doc.numPages>500)this.status('미리보기는 가능하지만 페이지 분할·내보내기는 문서당 최대 500페이지입니다.',true);
  }
  closeMenu(restore=true){if(!this.menu)return;this.menu.hidden=true;this.el('page-actions')?.setAttribute('aria-expanded','false');if(restore)this.menuTrigger?.focus?.();}
  async performAction(action){
    this.closeMenu(false);if(this.actionBusy||!this.doc||!this.selectedPages.size||!this.onPageAction)return;
    if(this.isAppBusy()){this.status('진행 중인 작업을 마친 뒤 페이지 작업을 실행하세요.',true);return;}
    const file=this.current.file,revision=this.revision,pages=pageSelectionGroups(this.doc.numPages,this.selectedPages).selected;
    this.actionBusy=true;this.controls();this.status(pages.length+'개 선택 페이지를 처리하고 있습니다.');
    try{
      const result=await this.onPageAction({action,pages,total:this.doc.numPages,file,role:this.current.role});
      if(revision!==this.revision||this.current?.file!==file)return;
      this.showActionResults(result,pages);this.status('선택 페이지 처리가 완료되었습니다. 결과를 확인한 뒤 저장하세요.');
    }catch(error){if(revision===this.revision)this.status(error.message||'페이지 작업을 완료하지 못했습니다.',true);}
    finally{this.actionBusy=false;this.controls();if(this.expanded&&!this.root.contains(document.activeElement))this.el('page-actions').focus();}
  }
  showActionResults(result,pages=[]){
    this.result.replaceChildren();this.result.hidden=false;const title=document.createElement('strong');title.textContent='선택 페이지 작업 결과 · '+pageRanges(pages)+'페이지';const summary=document.createElement('p');summary.textContent=result.summary||'원본을 변경하지 않고 새 PDF를 만들었습니다.';this.result.append(title,summary);
    const files=result.files||[];
    if(files.length>1){const all=document.createElement('button');all.type='button';all.className='secondary';all.textContent='모두 ZIP으로 저장';all.onclick=async()=>{all.disabled=true;try{const archive=Object.create(null);files.forEach((f,i)=>archive[(i+1)+'_'+f.name.replace(/[\\/]/g,'_')]=f.bytes);await this.onDownload?.({name:'pdf-atelier-selected-pages.zip',mime:'application/zip',bytes:zipSync(archive,{level:1})});}catch(error){this.status(error.message,true);}finally{all.disabled=false;}};this.result.append(all);}
    for(const file of files){const row=document.createElement('div');row.className='pdf-page-result-row';const name=document.createElement('span');name.textContent=file.name+' · '+(file.bytes.length/1024).toFixed(1)+' KB';const save=document.createElement('button');save.type='button';save.className='secondary';save.textContent='저장';save.setAttribute('aria-label',file.name+' 저장');save.onclick=async()=>{save.disabled=true;try{await this.onDownload?.(file);}catch(error){this.status(error.message,true);}finally{save.disabled=false;}};row.append(name,save);this.result.append(row);}
    const note=document.createElement('small');note.textContent='원본은 유지됩니다. 페이지 추출은 전자서명·문서 수준 양식·책갈피를 보존하지 못할 수 있습니다.';this.result.append(note);
  }
  setExpanded(value){
    value=!!value;if(value===this.expanded)return;this.closeMenu(false);this.expanded=value;
    const button=this.el('preview-expand');button.setAttribute('aria-pressed',String(value));button.querySelector('span').textContent=value?'닫기 · Esc':'크게 보기';button.setAttribute('aria-label',value?'전체화면 미리보기 닫기':'PDF 미리보기 전체화면으로 크게 보기');
    if(value){
      this.previousFocus=document.activeElement;this.placeholder=document.createComment('PDF preview position');this.root.before(this.placeholder);document.body.append(this.root);
      this.background=Array.from(document.body.children).filter(el=>el!==this.root).map(el=>({el,inert:el.inert}));for(const {el}of this.background)el.inert=true;
      this.oldOverflow=document.body.style.overflow;document.body.style.overflow='hidden';this.oldRole=this.root.getAttribute('role');this.root.setAttribute('role','dialog');this.root.setAttribute('aria-modal','true');this.root.setAttribute('aria-label','PDF 전체화면 미리보기');this.root.classList.add('pdf-preview-expanded');button.focus();
    }else{
      this.root.classList.remove('pdf-preview-expanded');if(this.placeholder?.parentNode){this.placeholder.replaceWith(this.root);}this.placeholder=null;
      for(const {el,inert}of this.background||[])if(el.isConnected)el.inert=inert;this.background=[];document.body.style.overflow=this.oldOverflow||'';
      if(this.oldRole)this.root.setAttribute('role',this.oldRole);else this.root.removeAttribute('role');this.root.removeAttribute('aria-modal');this.root.removeAttribute('aria-label');if(this.previousFocus?.isConnected)this.previousFocus.focus();
    }
    if(this.doc)this.scheduleDraw();
  }
}
