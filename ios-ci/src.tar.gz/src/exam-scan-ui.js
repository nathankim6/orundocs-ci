// "시험지 필기 지우기" workspace: photo -> sheet corners -> handwriting removal -> review/brush -> save / share / print.
// Local Web Worker processing is default; GPT uploads require explicit batch consent.
import { buildPdf, buildDocx, jpegToPng, safeStem } from './exam-scan-export.mjs';
import { zipSync } from 'fflate';
import { createExamAIClient, prepareAIImage, requireConsent, EXAM_AI_BASE_URL } from './exam-ai-client.mjs';
import { getExamAIIdToken } from './auth/auth-gate.js';

import { MAX_PAGES, admission, exportPages, runBatch, workerRequest, CurrentBitmaps } from './exam-batch.mjs';
const SENSITIVITY = { low: 0.15, normal: 0.5, high: 0.9 };
const icon = d => `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${d}"/></svg>`;

export function mountExamScanner({ main, onBack, save, share = null, canPrint = false, platform = 'desktop', setBusy = () => {} }) {
  const view = document.createElement('section');
  view.id = 'exam-view'; view.hidden = true; view.className = 'exam-view';
  view.innerHTML = `
  <div class="suite-detail-heading exam-heading">
    <button type="button" class="text-button" id="exam-back">← 모든 도구</button>
    <div class="eyebrow">변환 / LOCAL WORKSPACE</div>
    <h1>사진 낙서 제거 → PDF</h1>
    <p>최대 20장의 시험지·숙제 사진을 순서대로 보정하고 한 PDF로 저장합니다. 자동 제거 결과는 페이지마다 확인하세요.</p>
    <div class="suite-tool-note" id="exam-privacy">기기 처리: 사진은 이 기기 안에서만 처리되며 서버로 보내지 않습니다.</div>
  </div>
  <section class="tool exam-tool" aria-label="시험지 필기 지우기 작업 공간">
    <ol class="exam-steps" aria-label="진행 단계"><li data-step="1">사진</li><li data-step="2">영역 맞추기</li><li data-step="3">필기 지우기</li><li data-step="4">저장·공유</li></ol>
    <div class="exam-add">
      <button type="button" class="primary" id="exam-camera-btn">${icon('M4 8h3l2-3h6l2 3h3v11H4zM12 17a4 4 0 1 0 0-8 4 4 0 0 0 0 8')}<span>카메라로 촬영</span></button>
      <button type="button" class="secondary" id="exam-pick-btn">${icon('M4 5h16v14H4zM4 15l5-5 4 4 3-3 4 4M15 9h.01')}<span>사진 선택</span></button>
      <input id="exam-camera" type="file" accept="image/*" capture="environment" hidden>
      <input id="exam-pick" type="file" accept="image/jpeg,image/png,image/webp,image/heic,image/heif" multiple hidden>
      <span class="exam-limit">최대 ${MAX_PAGES}장 · 장당 30 MiB · 전체 500 MiB</span>
    </div>
    <div class="exam-batch-controls"><button type="button" class="secondary" id="exam-cancel" hidden>처리 취소</button><button type="button" class="secondary" id="exam-retry" hidden>실패·미완료 재시도</button><span id="exam-progress" role="status" aria-live="polite"></span></div><ol id="exam-pages" class="exam-pages" aria-label="페이지 목록"></ol>
    <div id="exam-workspace" class="exam-workspace" hidden>
      <div class="exam-main">
        <div class="exam-tabs" role="tablist">
          <button type="button" role="tab" id="exam-tab-crop" aria-selected="true">영역 맞추기</button>
          <button type="button" role="tab" id="exam-tab-result" aria-selected="false">결과 보기</button>
        </div>
        <div id="exam-crop" class="exam-crop">
          <div class="exam-crop-stage" id="exam-crop-stage">
            <img id="exam-photo" alt="원본 사진">
            <svg class="exam-quad" viewBox="0 0 1 1" preserveAspectRatio="none" aria-hidden="true"><polygon id="exam-quad-poly" points=""/></svg>
          </div>
          <div class="exam-crop-tools">
            <button type="button" class="secondary" id="exam-auto">자동 감지</button>
            <button type="button" class="secondary" id="exam-full">전체 영역</button>
            <button type="button" class="secondary" id="exam-rot-l" aria-label="왼쪽으로 회전">↺ 회전</button>
            <button type="button" class="secondary" id="exam-rot-r" aria-label="오른쪽으로 회전">↻ 회전</button>
          </div>
          <p class="exam-hint">네 모서리 점을 끌어 시험지 가장자리에 맞추세요. <b id="exam-rotation"></b></p>
        </div>
        <div id="exam-result" class="exam-result" hidden>
          <div class="exam-result-stage"><canvas id="exam-canvas" aria-label="필기 지운 결과"></canvas></div>
          <div class="exam-brush" role="group" aria-label="수동 보정">
            <button type="button" class="secondary" id="exam-compare" aria-pressed="false">원본 보기</button>
            <span class="exam-sep"></span>
            <button type="button" class="exam-tool-btn" data-brush="none" aria-pressed="true">이동</button>
            <button type="button" class="exam-tool-btn" data-brush="erase" aria-pressed="false">지우개</button>
            <button type="button" class="exam-tool-btn" data-brush="restore" aria-pressed="false">복원</button>
            <label class="exam-size">굵기 <input type="range" id="exam-brush-size" min="4" max="60" value="12"></label>
            <button type="button" class="secondary" id="exam-undo" disabled>되돌리기</button>
          </div>
          <p class="exam-hint">남은 필기는 지우개로, 잘못 지워진 인쇄는 복원 브러시로 문질러 고칠 수 있습니다.</p>
        </div>
      </div>
      <aside class="exam-side">
        <fieldset class="exam-ai-options"><legend>처리 방법</legend>
          <label><input type="radio" name="exam-engine" id="exam-engine-local" value="local" checked> 기기에서 처리(무료·오프라인)</label>
          <label><input type="radio" name="exam-engine" id="exam-engine-ai" value="ai"> GPT AI(온라인·사용량 과금)</label>
          <p id="exam-ai-availability" role="status"></p>
          <div id="exam-ai-details" hidden>
            <p class="exam-ai-warning">인쇄된 글자·수식이 변형될 수 있으니 원본과 비교하세요</p>
            <p>선택한 사진을 기기에서 자르고 보정한 뒤 앱 서버를 통해 OpenAI에 전송합니다. 앱 서버는 사진을 저장하지 않습니다. OpenAI API 데이터는 기본적으로 학습에 사용되지 않지만 남용 모니터링을 위해 최대 30일 보관될 수 있습니다. 정확한 비용은 처리 후 사용량에 따라 달라집니다. 계정 예산 $20 · 안전 중단 $18.</p>
            <label class="check-field"><input type="checkbox" id="exam-ai-consent"> 이번 작업의 선택 사진을 OpenAI로 전송하고 사용량에 따라 과금되는 데 동의합니다.</label>
            <p>취소해도 이미 전송된 요청의 원격 처리나 과금을 중단·환불한다고 보장할 수 없습니다. 자동 유료 재시도는 하지 않습니다.</p>
          </div>
        </fieldset>
        <fieldset class="exam-options"><legend>필기 지우기</legend>
          <label class="check-field"><input type="checkbox" id="exam-erase" checked> 필기 지우기 사용</label>
          <label class="check-field"><input type="checkbox" id="exam-color" checked> 색 펜·형광펜·채점 표시</label>
          <label class="check-field"><input type="checkbox" id="exam-pencil" checked> 연필·샤프 필기</label>
          <label>연필 지우기 강도<select id="exam-strength"><option value="low">약하게 · 인쇄 최대 보호</option><option value="normal" selected>보통</option><option value="high">강하게 · 진한 연필까지</option></select></label>
          <label>결과 모양<select id="exam-mode"><option value="clean" selected>깨끗하게 (흰 바탕)</option><option value="bw">흑백 (인쇄용)</option><option value="gray">회색조</option><option value="color">컬러</option></select></label>
          <button type="button" class="primary" id="exam-run">전체 사진 낙서 제거 →</button>
          <small id="exam-dirty" hidden>설정이 바뀌었습니다. 다시 실행해 주세요.</small>
        </fieldset>
        <fieldset class="exam-export"><legend>저장·공유</legend>
          <label>형식<select id="exam-format"><option value="pdf" selected>PDF</option><option value="jpg">JPG 이미지</option><option value="png">PNG 이미지</option><option value="docx">Word (DOCX)</option></select></label>
          <label id="exam-paper-row">용지<select id="exam-paper"><option value="a4" selected>A4에 맞춤</option><option value="image">사진 비율 그대로</option></select></label>
          <label>파일 이름<input id="exam-name" value="시험지"></label>
          <label class="check-field"><input type="checkbox" id="exam-skip"> 미완료 페이지 제외에 동의 (<span id="exam-skip-count">0</span>장)</label><div class="exam-export-buttons">
            <button type="button" class="primary" id="exam-save">저장</button>
            <button type="button" class="secondary" id="exam-share" hidden>공유</button>
            <button type="button" class="secondary" id="exam-print" hidden>인쇄</button>
          </div>
        </fieldset>
      </aside>
    </div>
    <div id="exam-status" class="exam-status" role="status" aria-live="polite" hidden></div>
    <p class="suite-disclaimer">자동 필기 제거는 연필의 진하기, 펜 색, 사진 품질에 따라 일부가 남거나 가는 인쇄선이 옅어질 수 있습니다. 결과를 확인하고 브러시로 보정하세요. 검정 펜 필기는 인쇄와 구별이 어려워 지우개 브러시로 지워야 할 수 있습니다.</p>
  </section>`;
  main.prepend(view);
  const $ = id => view.querySelector('#' + id);
  const state = { pages: [], current: -1, busy: false, brush: 'none', dirty: false, seq: 0 };
  const aiClient = createExamAIClient({ getIdToken: getExamAIIdToken });
  const isAI = () => $('exam-engine-ai').checked;
  const bitmaps = new CurrentBitmaps(); let operation = null, renderVersion = 0;
  $('exam-share').hidden = !share; $('exam-print').hidden = !canPrint;
  if (platform !== 'android' && platform !== 'ios') $('exam-camera-btn').hidden = true;
  const call = (msg, signal = operation?.signal) => workerRequest(new Worker('/exam-scan-worker.js'), { ...msg, id: ++state.seq }, { signal, timeout: msg.cmd === 'detect' ? 30000 : 90000 });
  $('exam-cancel').onclick = () => { operation?.abort(); status(isAI() ? '취소 중입니다. 이미 전송된 요청은 원격 처리·과금될 수 있습니다. 완료된 페이지는 보존됩니다.' : '취소 중입니다. 완료된 페이지는 보존됩니다.'); };

  function status(text, error = false) { const s = $('exam-status'); s.hidden = !text; s.textContent = text || ''; s.classList.toggle('is-error', !!error); }
  function lock(v) {
    state.busy = v; setBusy(v);
    if (v) { drawing = null; clearTimeout(thumbTimer); }
    for (const el of view.querySelectorAll('button, input, select')) el.disabled = v;
    $('exam-cancel').hidden = !v || !operation; $('exam-cancel').disabled = !operation;
    $('exam-compare').disabled = !page()?.result || bitmaps.entry?.page !== page();
    if (!v) { operation = null; $('exam-cancel').hidden = true; refresh(); }
  }
  const page = () => state.pages[state.current];

  // ---------- pages ----------
  async function addFiles(list) {
    if (state.busy) return;
    const files = Array.from(list || []), errors = []; $('exam-ai-consent').checked = false;
    operation = new AbortController(); lock(true); $('exam-skip').checked = false;
    try {
      for (const file of files) {
        if (operation.signal.aborted) break;
        const reason = admission(state.pages, file);
        if (reason) { errors.push((file.name || '사진') + ': ' + reason); continue; }
        if (!/^image\//.test(file.type) && !/\.(jpe?g|png|webp|heic|heif)$/i.test(file.name)) { errors.push(file.name + ': 사진 파일만 추가할 수 있습니다.'); continue; }
        const p = { file, name: file.name || '사진', corners: [[0,0],[1,0],[1,1],[0,1]], rotate: 0, previewUrl: '', result: null, strokes: [], status: 'pending', warning: '' };
        try { p.previewUrl = await makePreview(file); p.thumbUrl = await makePreview(file, 180); }
        catch { revoke(p); errors.push(file.name + ': 사진을 열 수 없습니다. JPG·PNG를 사용해 주세요.'); continue; }
        state.pages.push(p);
        if (state.current < 0) state.current = 0;
        status(state.pages.length + '번 사진 가장자리 감지 중');
        try { const d = await call({ cmd: 'detect', file }); p.corners = d.corners; p.detected = d.detected; p.warning = d.detected ? '' : '자동 감지 불확실: 모서리를 확인하세요.'; }
        catch (e) { p.warning = '감지 미완료: 모서리를 직접 확인하세요. ' + e.message; }
        renderList();
      }
      if (state.pages.length && !$('exam-name').dataset.touched) $('exam-name').value = safeStem(state.pages[0].name) + '_필기제거';
      status(errors.length ? errors.join('\n') : operation.signal.aborted ? '취소했습니다. 추가된 사진은 보존됩니다.' : '사진 순서와 모서리를 확인한 뒤 전체 사진 낙서 제거를 실행하세요.', !!errors.length);
    } finally { lock(false); select(state.current); }
  }

  async function makePreview(file, maxSide = 1400) {
    const bmp = await createImageBitmap(file, { imageOrientation: 'from-image' });
    const s = Math.min(1, maxSide / Math.max(bmp.width, bmp.height));
    const c = document.createElement('canvas'); c.width = Math.round(bmp.width * s); c.height = Math.round(bmp.height * s);
    c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height); bmp.close?.();
    const blob = await new Promise(r => c.toBlob(r, 'image/jpeg', 0.85)); c.width = c.height = 1;
    if (!blob) throw new Error('미리보기를 만들지 못했습니다.');
    return URL.createObjectURL(blob);
  }

  function renderList() {
    const ol = $('exam-pages'); ol.replaceChildren();
    state.pages.forEach((p, i) => {
      const li = document.createElement('li'); li.className = 'exam-page' + (i === state.current ? ' active' : '');
      const b = document.createElement('button'); b.type = 'button'; b.className = 'exam-thumb'; b.setAttribute('aria-label', (i + 1) + '번 페이지 열기'); b.setAttribute('aria-current', i === state.current ? 'true' : 'false');
      const img = document.createElement('img'); img.alt = ''; img.src = p.thumbUrl || p.previewUrl;
      const n = document.createElement('span'); n.className = 'exam-page-num'; n.textContent = (i + 1) + ' · ' + ({pending:'대기',processing:'처리 중',done:'완료',failed:'실패',cancelled:'취소',dirty:'재처리 필요'}[p.status] || '대기'); b.disabled = state.busy;
      b.append(img, n); b.onclick = () => select(i);
      const tools = document.createElement('div'); tools.className = 'exam-page-tools';
      for (const [label, aria, fn] of [['↑', '앞으로', () => move(i, -1)], ['↓', '뒤로', () => move(i, 1)], ['×', '삭제', () => remove(i)]]) {
        const t = document.createElement('button'); t.type = 'button'; t.className = 'text-button'; t.textContent = label; t.setAttribute('aria-label', (i + 1) + '번 페이지 ' + aria);
        t.disabled = state.busy || (aria === '앞으로' && i === 0) || (aria === '뒤로' && i === state.pages.length - 1); t.onclick = fn; tools.append(t);
      }
      li.append(b, tools); if (p.error || p.warning) { const note = document.createElement('small'); note.className = 'exam-page-warning'; note.textContent = p.error || p.warning; li.append(note); } ol.append(li);
    });
  }
  function move(i, d) { const j = i + d; if (state.busy || j < 0 || j >= state.pages.length) return; [state.pages[i], state.pages[j]] = [state.pages[j], state.pages[i]]; if (state.current === i) state.current = j; else if (state.current === j) state.current = i; refresh(); }
  function remove(i) {
    if (state.busy) return; $('exam-ai-consent').checked = false; const [p] = state.pages.splice(i, 1); revoke(p); state.dirtyPages?.delete(p); state.dirty = !!state.dirtyPages?.size; $('exam-skip').checked = false; if (i < state.current) state.current--;
    if (state.current >= state.pages.length) state.current = state.pages.length - 1; refresh(); select(state.current);
  }
  function revoke(p) { if (!p) return; URL.revokeObjectURL(p.previewUrl); if (p.thumbUrl) URL.revokeObjectURL(p.thumbUrl); if (p.result) URL.revokeObjectURL(p.result.afterUrl); if (bitmaps.entry?.page === p) bitmaps.clear(); }

  function refresh() {
    renderList();
    const has = state.pages.length > 0, done = state.pages.some(p => p.result);
    $('exam-workspace').hidden = !has;
    for (const li of view.querySelectorAll('.exam-steps li')) { const s = +li.dataset.step; li.classList.toggle('done', (s === 1 && has) || (s === 2 && has) || (s === 3 && done)); }
    $('exam-tab-result').disabled = state.busy || !page()?.result;
    const missing = state.pages.filter(p => p.status !== 'done' || !p.result || state.dirtyPages?.has(p)).length;
    $('exam-skip-count').textContent = missing; $('exam-retry').hidden = !missing; $('exam-retry').disabled = state.busy;
    $('exam-progress').textContent = state.pages.filter(p => p.status === 'done').length + ' / ' + state.pages.length + '장 완료 · 미완료 ' + missing + '장';
    $('exam-undo').disabled = state.busy || !page()?.strokes.length;
    $('exam-color').disabled = $('exam-pencil').disabled = $('exam-strength').disabled = state.busy || !$('exam-erase').checked;
    $('exam-dirty').hidden = !state.dirty || !done;
    $('exam-paper-row').hidden = $('exam-format').value !== 'pdf';
    $('exam-save').disabled = state.busy || !has; $('exam-share').disabled = state.busy || !has; $('exam-print').disabled = state.busy || !has;
    const aiUnavailable = navigator.onLine === false || !EXAM_AI_BASE_URL;
    $('exam-engine-ai').disabled = state.busy || aiUnavailable;
    $('exam-ai-availability').textContent = navigator.onLine === false ? '오프라인: GPT AI를 사용할 수 없습니다. 기기 처리를 직접 선택하세요.' : !EXAM_AI_BASE_URL ? 'GPT AI 서버 연결 준비 중입니다. 기기 처리를 사용할 수 있습니다.' : '';
    $('exam-ai-details').hidden = !isAI();
    $('exam-privacy').textContent = isAI() ? 'GPT AI: 동의한 사진을 앱 서버를 통해 OpenAI에 전송합니다.' : '기기 처리: 사진은 서버로 보내지 않습니다.';
    $('exam-run').disabled = state.busy || !has || (isAI() && aiUnavailable);
    $('exam-retry').disabled = state.busy || (isAI() && aiUnavailable);
    $('exam-erase').disabled = $('exam-mode').disabled = state.busy || isAI();
    for (const id of ['exam-color','exam-pencil','exam-strength']) $(id).disabled = state.busy || isAI() || !$('exam-erase').checked;
  }

  function select(i) {
    if (state.busy) return; renderVersion++; bitmaps.clear(); drawing = null; clearTimeout(thumbTimer); canvas.width = canvas.height = 1;
    if (i < 0 || i >= state.pages.length) { $('exam-workspace').hidden = true; return; }
    state.current = i; refresh(); showTab(page().result && !state.dirtyPages?.has(page()) ? 'result' : 'crop');
  }

  // ---------- crop ----------
  const handles = [];
  for (let k = 0; k < 4; k++) {
    const h = document.createElement('button'); h.type = 'button'; h.className = 'exam-handle'; h.setAttribute('aria-label', ['왼쪽 위', '오른쪽 위', '오른쪽 아래', '왼쪽 아래'][k] + ' 모서리');
    h.onpointerdown = e => { if (state.busy) return; e.preventDefault(); h.setPointerCapture(e.pointerId); h.dataset.drag = '1'; };
    h.onpointermove = e => {
      if (state.busy || !h.dataset.drag) return; const r = $('exam-photo').getBoundingClientRect();
      const p = page(); p.corners[k] = [Math.min(1, Math.max(0, (e.clientX - r.left) / r.width)), Math.min(1, Math.max(0, (e.clientY - r.top) / r.height))];
      markDirty(p); drawCrop();
    };
    h.onpointerup = h.onpointercancel = () => { delete h.dataset.drag; };
    h.onkeydown = e => { if (state.busy) return; const step = e.shiftKey ? 0.02 : 0.004, d = { ArrowLeft: [-step, 0], ArrowRight: [step, 0], ArrowUp: [0, -step], ArrowDown: [0, step] }[e.key]; if (!d) return; e.preventDefault(); const c = page().corners[k]; c[0] = Math.min(1, Math.max(0, c[0] + d[0])); c[1] = Math.min(1, Math.max(0, c[1] + d[1])); markDirty(page()); drawCrop(); };
    handles.push(h); $('exam-crop-stage').append(h);
  }
  function drawCrop() {
    const p = page(); if (!p) return;
    const img = $('exam-photo'); if (img.getAttribute('src') !== p.previewUrl) img.src = p.previewUrl;
    $('exam-quad-poly').setAttribute('points', p.corners.map(c => c.join(',')).join(' '));
    handles.forEach((h, k) => { h.style.left = p.corners[k][0] * 100 + '%'; h.style.top = p.corners[k][1] * 100 + '%'; });
    $('exam-rotation').textContent = p.rotate ? `결과는 ${p.rotate}° 회전됩니다` : '';
  }
  function markDirty(p) { $('exam-ai-consent').checked = false; $('exam-skip').checked = false; if (!p.result) return; p.status = 'dirty'; (state.dirtyPages ||= new Set()).add(p); state.dirty = true; refresh(); }
  $('exam-auto').onclick = async () => { const p = page(); if (!p || state.busy) return; operation = new AbortController(); lock(true); try { const d = await call({ cmd: 'detect', file: p.file }); p.corners = d.corners; p.warning = d.detected ? '' : '자동 감지 불확실: 모서리를 확인하세요.'; markDirty(p); drawCrop(); status(d.detected ? '시험지 가장자리를 찾았습니다.' : '가장자리가 뚜렷하지 않아 전체 영역을 사용합니다. 점을 직접 맞춰 주세요.'); } catch (e) { status(e.message, true); } finally { bitmaps.clear(); lock(false); if (page()?.result && !$('exam-result').hidden) renderResult(); } };
  $('exam-full').onclick = () => { const p = page(); if (!p) return; p.corners = [[0, 0], [1, 0], [1, 1], [0, 1]]; markDirty(p); drawCrop(); };
  $('exam-rot-l').onclick = () => { const p = page(); if (!p) return; p.rotate = (p.rotate + 270) % 360; markDirty(p); drawCrop(); };
  $('exam-rot-r').onclick = () => { const p = page(); if (!p) return; p.rotate = (p.rotate + 90) % 360; markDirty(p); drawCrop(); };

  function showTab(tab) {
    const crop = tab === 'crop';
    $('exam-crop').hidden = !crop; $('exam-result').hidden = crop;
    $('exam-tab-crop').setAttribute('aria-selected', String(crop)); $('exam-tab-result').setAttribute('aria-selected', String(!crop));
    if (crop) drawCrop(); else renderResult();
  }
  $('exam-tab-crop').onclick = () => showTab('crop');
  $('exam-tab-result').onclick = () => { if (page()?.result) showTab('result'); };

  // ---------- processing ----------
  function options() {
    return { erase: $('exam-erase').checked, removeColor: $('exam-color').checked, removePencil: $('exam-pencil').checked, pencilSensitivity: SENSITIVITY[$('exam-strength').value], mode: $('exam-mode').value };
  }
  for (const id of ['exam-erase', 'exam-color', 'exam-pencil', 'exam-strength', 'exam-mode']) $(id).addEventListener('change', () => {
    $('exam-color').disabled = $('exam-pencil').disabled = $('exam-strength').disabled = !$('exam-erase').checked;
    if (state.pages.some(p => p.result)) { state.dirty = true; state.dirtyPages = new Set(state.pages.filter(p => p.result)); for (const p of state.dirtyPages) p.status = 'dirty'; $('exam-skip').checked = false; refresh(); }
  });
  for (const id of ['exam-engine-local', 'exam-engine-ai']) $(id).onchange = () => { $('exam-ai-consent').checked = false; for (const p of state.pages) markDirty(p); refresh(); };
  window.addEventListener('online', refresh); window.addEventListener('offline', refresh);
  $('exam-format').onchange = refresh;
  $('exam-name').oninput = () => { $('exam-name').dataset.touched = '1'; };

  async function processAll(onlyMissing = false) {
    const opts = options(), list = state.pages.filter(p => !onlyMissing || p.status !== 'done' || !p.result || state.dirtyPages?.has(p));
    bitmaps.clear(); renderVersion++; canvas.width = canvas.height = 1; $('exam-compare').disabled = true; $('exam-skip').checked = false;
    return runBatch(list, async (p, signal) => {
      let r;
      if (isAI()) {
        const flat = await call({ cmd: 'process', file: p.file, corners: p.corners, rotate: p.rotate, erase: false, mode: 'color', maxSide: 2048, maxInputSide: 3200 }, signal);
        const prepared = await prepareAIImage(flat.before, { signal });
        // One stable ID per explicitly confirmed attempt. No automatic paid retries.
        p.aiRequestId ||= crypto.randomUUID();
        const cleaned = await aiClient.cleanup({ ...prepared, requestId: p.aiRequestId, consent: state.aiConsent === true, signal });
        // Preserve a matching-size local original for compare/restore even when model dimensions differ.
        const beforeCanvas = document.createElement('canvas'); beforeCanvas.width = cleaned.width; beforeCanvas.height = cleaned.height;
        let original;
        try { original = await createImageBitmap(prepared.before); beforeCanvas.getContext('2d').drawImage(original, 0, 0, cleaned.width, cleaned.height);
          const before = await new Promise(resolve => beforeCanvas.toBlob(resolve, 'image/jpeg', 0.9));
          if (!before) throw new Error('원본 비교 이미지를 만들지 못했습니다.');
          r = { width: cleaned.width, height: cleaned.height, before, after: cleaned.blob, removedRatio: 0 };
          p.aiCostUSD = cleaned.costUSD; p.warning = '인쇄된 글자·수식이 변형될 수 있으니 원본과 비교하세요';
        } finally { original?.close?.(); beforeCanvas.width = beforeCanvas.height = 1; }
      } else r = await call({ cmd: 'process', file: p.file, corners: p.corners, rotate: p.rotate, ...opts }, signal);
      if (signal.aborted) return;
      if (p.result) URL.revokeObjectURL(p.result.afterUrl);
      p.result = { width: r.width, height: r.height, after: r.after, before: r.before, afterUrl: URL.createObjectURL(r.after), removedRatio: r.removedRatio };
      p.strokes = []; state.dirtyPages?.delete(p);
    }, { signal: operation.signal, onUpdate: (p, n, total) => {
      status(n + ' / ' + total + '장 처리 진행' + (p ? ' · ' + (state.pages.indexOf(p) + 1) + '번 ' + (p.error || '') : ''));
      renderList(); $('exam-progress').textContent = n + ' / ' + total + '장 처리 진행';
    }});
  }
  async function startBatch(retry = false) {
    if (state.busy || !state.pages.length) return;
    operation = new AbortController(); lock(true);
    try {
      if (isAI()) {
        requireConsent($('exam-ai-consent').checked);
        const quota = await aiClient.status(operation.signal);
        if (operation.signal.aborted) return;
        const targets = state.pages.filter(p => !retry || p.status !== 'done' || !p.result || state.dirtyPages?.has(p));
        const spent = Number.isFinite(quota.spentUSD) ? '$' + quota.spentUSD.toFixed(4) : '서버 확인값 없음';
        const estimate = Number.isFinite(quota.estimatedCostPerImageUSD) ? '예상 비용 약 $' + (quota.estimatedCostPerImageUSD * targets.length).toFixed(4) : '정확한 예상 비용을 확정할 수 없습니다.';
        if (quota.allowed !== true || !Number.isFinite(quota.remainingUSD) || quota.remainingUSD <= 0 || quota.spentUSD >= 18) throw new Error('AI 계정 사용 한도에 도달했습니다.');
        if (!window.confirm('GPT AI로 ' + targets.length + '장을 전송할까요?\n' + estimate + '\n현재 누적 사용량: ' + spent + '\n안전 중단 기준 잔여액(예약분 차감): ' + (Number.isFinite(quota.remainingUSD) ? quota.remainingUSD.toFixed(4) + ' USD' : '확인 불가') + '\n계정 예산 $20 · 안전 중단 $18. 실제 비용은 사용량에 따라 달라집니다.\n인쇄된 글자·수식이 변형될 수 있으니 원본과 비교하세요\n취소해도 이미 전송한 요청은 과금될 수 있습니다. 재시도는 추가 과금될 수 있습니다.')) { status('AI 전송을 취소했습니다.'); return; }
        state.aiConsent = true;
        for (const p of targets) p.aiRequestId = crypto.randomUUID();
      }
      const r = await processAll(retry); state.dirty = !!state.dirtyPages?.size;
      const failed = state.pages.filter(p => p.status !== 'done').length;
      status((r.cancelled ? '처리를 취소했습니다. ' : '처리가 끝났습니다. ') + (state.pages.length - failed) + '장 완료 · ' + failed + '장 미완료. 결과와 감지 경고를 확인하세요.' + (isAI() ? ' 확인된 완료 페이지 비용 합계: ' + state.pages.reduce((sum,p) => sum + (p.aiCostUSD || 0), 0).toFixed(4) + ' USD. 실패·취소된 요청의 과금은 포함되지 않을 수 있습니다.' : ''), !!failed);
    } catch (e) { status(e.message || '처리하지 못했습니다.', true); }
    finally { state.aiConsent = false; $('exam-ai-consent').checked = false; lock(false); if (page()?.result) showTab('result'); }
  }
  $('exam-run').onclick = () => startBatch(false);
  $('exam-retry').onclick = () => startBatch(true);

  // ---------- result + brush ----------
  const canvas = $('exam-canvas'); const ctx = canvas.getContext('2d');
  let comparing = false, drawing = null;
  async function renderResult() {
    const p = page(), version = ++renderVersion;
    if (!p?.result) return;
    try {
      const pair = await bitmaps.get(p);
      if (!pair || version !== renderVersion || p !== page()) return;
      paint(canvas, p, pair, comparing); $('exam-compare').disabled = false;
    } catch(e) { status('결과 표시 실패: ' + e.message, true); }
  }
  function paint(target, p, pair, compare = false) {
    const c = target.getContext('2d'); target.width = p.result.width; target.height = p.result.height;
    c.drawImage(compare ? pair.before : pair.after, 0, 0);
    if (!compare) for (const s of p.strokes) applyStroke(c, p, s, pair);
  }
  function applyStroke(c, p, s, pair = bitmaps.entry) {
    if (!pair || pair.page !== p) return;
    const pts = s.points; if (!pts.length) return;
    c.save(); c.beginPath();
    for (let i = 0; i < pts.length; i++) {
      const [x, y] = pts[i]; c.moveTo(x + s.r, y); c.arc(x, y, s.r, 0, Math.PI * 2);
      if (i) { const [px, py] = pts[i - 1], d = Math.hypot(x - px, y - py), n = Math.ceil(d / (s.r / 2)); for (let k = 1; k < n; k++) { const ix = px + (x - px) * k / n, iy = py + (y - py) * k / n; c.moveTo(ix + s.r, iy); c.arc(ix, iy, s.r, 0, Math.PI * 2); } }
    }
    if (s.mode === 'erase') { c.fillStyle = '#fff'; c.fill(); }
    else { c.clip(); c.drawImage(pair.before, 0, 0); }
    c.restore();
  }
  const toCanvas = e => { const r = canvas.getBoundingClientRect(); return [(e.clientX - r.left) * canvas.width / r.width, (e.clientY - r.top) * canvas.height / r.height]; };
  canvas.onpointerdown = e => {
    if (state.busy || bitmaps.entry?.page !== page() || state.brush === 'none' || comparing || !page()?.result) return;
    e.preventDefault(); canvas.setPointerCapture(e.pointerId);
    const r = +$('exam-brush-size').value * canvas.width / Math.max(1, canvas.getBoundingClientRect().width);
    drawing = { mode: state.brush, r, points: [toCanvas(e)] }; page().strokes.push(drawing); applyStroke(ctx, page(), { ...drawing, points: drawing.points.slice(-1) });
  };
  canvas.onpointermove = e => { if (state.busy || !drawing) return; drawing.points.push(toCanvas(e)); applyStroke(ctx, page(), { ...drawing, points: drawing.points.slice(-2) }); };
  canvas.onpointerup = canvas.onpointercancel = () => { if (!drawing) return; drawing = null; $('exam-undo').disabled = !page()?.strokes.length; updateThumb(); };
  $('exam-undo').onclick = () => { if (state.busy) return; const p = page(); if (!p?.strokes.length) return; p.strokes.pop(); renderResult(); $('exam-undo').disabled = !p.strokes.length; updateThumb(); };
  for (const b of view.querySelectorAll('.exam-tool-btn')) b.onclick = () => { state.brush = b.dataset.brush; for (const o of view.querySelectorAll('.exam-tool-btn')) o.setAttribute('aria-pressed', String(o === b)); canvas.classList.toggle('is-brush', state.brush !== 'none'); };
  $('exam-compare').onclick = () => { comparing = !comparing; $('exam-compare').setAttribute('aria-pressed', String(comparing)); $('exam-compare').textContent = comparing ? '결과 보기' : '원본 보기'; renderResult(); };
  let thumbTimer = 0;
  function updateThumb() {
    clearTimeout(thumbTimer); const p = page(), result = p?.result;
    thumbTimer = setTimeout(async () => {
      if (state.busy || p !== page() || p.result !== result) return;
      try {
        const blob = await pageBlob(p, 'image/jpeg', 0.6);
        if (state.busy || p !== page() || p.result !== result) return;
        const thumb = await makePreview(blob, 180); if (state.busy || p !== page() || p.result !== result) { URL.revokeObjectURL(thumb); return; } URL.revokeObjectURL(p.thumbUrl); p.thumbUrl = thumb; renderList();
      } catch(e) { status(e.message, true); }
    }, 400);
  }
  async function pageBlob(p, type = 'image/jpeg', quality = 0.9) {
    const pair = await bitmaps.get(p);
    if (!pair) throw new Error('페이지가 바뀌었습니다. 다시 시도해 주세요.');
    const c = document.createElement('canvas'); paint(c, p, pair, false);
    try { return await new Promise((res, rej) => c.toBlob(b => b ? res(b) : rej(new Error('이미지를 만들지 못했습니다.')), type, quality)); }
    finally { c.width = c.height = 1; }
  }

  // ---------- export ----------
  function intendedPages() { return exportPages(state.pages, $('exam-skip').checked, state.dirtyPages); }
  async function ensureProcessed() {
    intendedPages(); renderVersion++; bitmaps.clear(); canvas.width = canvas.height = 1;
  }
  async function outputs(forShare) {
    const fmt = $('exam-format').value, stem = safeStem($('exam-name').value || '시험지');
    const pages = [];
    for (const p of intendedPages()) pages.push({ jpeg: new Uint8Array(await (await pageBlob(p)).arrayBuffer()), width: p.result.width, height: p.result.height });
    if (fmt === 'pdf') return [{ name: stem + '.pdf', mime: 'application/pdf', bytes: await buildPdf(pages, { paper: $('exam-paper').value }) }];
    if (fmt === 'docx') return [{ name: stem + '.docx', mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', bytes: buildDocx(pages, { title: stem }) }];
    const imgs = [];
    for (let i = 0; i < pages.length; i++) {
      const suffix = pages.length > 1 ? '_' + String(i + 1).padStart(2, '0') : '';
      if (fmt === 'png') imgs.push({ name: stem + suffix + '.png', mime: 'image/png', bytes: await jpegToPng(pages[i].jpeg) });
      else imgs.push({ name: stem + suffix + '.jpg', mime: 'image/jpeg', bytes: pages[i].jpeg });
    }
    if (forShare || imgs.length === 1) return imgs;
    const zip = Object.create(null); for (const f of imgs) zip[f.name] = f.bytes;
    return [{ name: stem + '_이미지.zip', mime: 'application/zip', bytes: zipSync(zip, { level: 0 }) }];
  }
  $('exam-save').onclick = async () => {
    if (state.busy || !state.pages.length) return; lock(true);
    try {
      await ensureProcessed(); status('파일을 만드는 중입니다.');
      const [file] = await outputs(false); const r = await save(file);
      status(r?.cancelled ? '저장을 취소했습니다.' : file.name + ' 저장을 완료했습니다.');
    } catch (e) { status(e.message || '저장하지 못했습니다.', true); } finally { bitmaps.clear(); lock(false); if (page()?.result && !$('exam-result').hidden) renderResult(); }
  };
  $('exam-share').onclick = async () => {
    if (state.busy || !state.pages.length || !share) return; lock(true);
    try {
      await ensureProcessed(); status('공유할 파일을 만드는 중입니다.');
      const files = await outputs(true); const r = await share(files);
      status(r?.cancelled ? '공유를 취소했습니다.' : r?.savedInstead ? (r.message || '이 환경은 시스템 공유를 지원하지 않아 파일로 저장했습니다.') : '공유 창을 열었습니다.');
    } catch (e) { status(e.message || '공유하지 못했습니다.', true); } finally { bitmaps.clear(); lock(false); if (page()?.result && !$('exam-result').hidden) renderResult(); }
  };
  $('exam-print').onclick = async () => {
    if (state.busy || !state.pages.length) return; lock(true);
    let holder = null;
    try {
      await ensureProcessed(); holder = document.createElement('div'); holder.id = 'exam-print-sheet';
      const urls = [];
      for (const p of intendedPages()) { const url = URL.createObjectURL(await pageBlob(p)); urls.push(url); const img = document.createElement('img'); img.src = url; img.alt = ''; holder.append(img); }
      document.body.append(holder);
      await Promise.all(Array.from(holder.querySelectorAll('img'), i => i.decode().catch(() => {})));
      document.body.classList.add('exam-printing');
      window.print();
      document.body.classList.remove('exam-printing'); urls.forEach(u => URL.revokeObjectURL(u));
      status('인쇄 창을 열었습니다.');
    } catch (e) { status(e.message || '인쇄하지 못했습니다.', true); }
    finally { holder?.remove(); document.body.classList.remove('exam-printing'); bitmaps.clear(); lock(false); if (page()?.result) renderResult(); }
  };

  // ---------- wiring ----------
  $('exam-back').onclick = () => { if (!state.busy) onBack(); };
  $('exam-camera-btn').onclick = () => $('exam-camera').click();
  $('exam-pick-btn').onclick = () => $('exam-pick').click();
  for (const id of ['exam-camera', 'exam-pick']) $(id).onchange = e => { const files = Array.from(e.target.files || []); e.target.value = ''; addFiles(files); };
  view.addEventListener('dragover', e => { if (!view.hidden) e.preventDefault(); });
  view.addEventListener('drop', e => { if (view.hidden) return; e.preventDefault(); e.stopPropagation(); addFiles(e.dataTransfer.files); });

  refresh();
  return {
    view,
    isBusy: () => state.busy,
    open() { view.hidden = false; status(''); refresh(); if (state.current >= 0) select(state.current); },
    close() { view.hidden = true; renderVersion++; bitmaps.clear(); canvas.width = canvas.height = 1; }
  };
}
