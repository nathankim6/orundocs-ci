import UIKit
import Capacitor
import AuthenticationServices
import UniformTypeIdentifiers
import WebKit

/// Registers the OrunDocs native plugins (same JS names/methods as Android).
class MainViewController: CAPBridgeViewController {
    override open func capacitorDidLoad() {
        bridge?.registerPluginInstance(OrunAuthPlugin())
        bridge?.registerPluginInstance(AtelierSafPlugin())
        bridge?.registerPluginInstance(AtelierSharePlugin())
        #if DEBUG
        installTestSessionHook()
        #endif
    }

    #if DEBUG
    /// Debug-only UI-test hook: when OD_TEST_RT is set, seed the stored session (only if none exists)
    /// so the normal online verification (token refresh + allowlist) runs. Compiled out of Release.
    private func installTestSessionHook() {
        guard let rt = ProcessInfo.processInfo.environment["OD_TEST_RT"], !rt.isEmpty else { return }
        let session: [String: Any] = ["v": 1, "email": "", "refreshToken": rt, "lastVerifiedAt": 0, "maxSeenAt": 0]
        guard let sessionData = try? JSONSerialization.data(withJSONObject: session),
              let sessionJSON = String(data: sessionData, encoding: .utf8),
              let literalData = try? JSONSerialization.data(withJSONObject: [sessionJSON]),
              let literal = String(data: literalData, encoding: .utf8) else { return }
        let js = "(function(){try{var k='orundocs.session.v1';if(!localStorage.getItem(k))localStorage.setItem(k,\(literal)[0]);}catch(e){}})();"
        bridge?.webView?.configuration.userContentController.addUserScript(
            WKUserScript(source: js, injectionTime: .atDocumentStart, forMainFrameOnly: true))
    }
    #endif
}

private func safeFileName(_ raw: String?, fallback: String) -> String {
    var name = (raw ?? "").precomposedStringWithCanonicalMapping
    let bad = CharacterSet(charactersIn: "/\\:*?\"<>|").union(.controlCharacters)
    name = String(name.unicodeScalars.map { bad.contains($0) ? "_" : Character($0) })
    while name.hasPrefix(".") { name.removeFirst() }
    name = name.trimmingCharacters(in: .whitespaces)
    if name.count > 180 { name = String(name.prefix(180)) }
    return name.isEmpty ? fallback : name
}

private final class ChunkFile {
    let url: URL
    let handle: FileHandle
    let expected: Int
    var written = 0
    var nextIndex = 0
    init(url: URL, expected: Int) throws {
        self.url = url
        self.expected = expected
        FileManager.default.createFile(atPath: url.path, contents: nil, attributes: [.protectionKey: FileProtectionType.complete])
        handle = try FileHandle(forWritingTo: url)
    }
    func append(_ call: CAPPluginCall, limit: Int) -> Bool {
        guard let b64 = call.getString("base64"), let data = Data(base64Encoded: b64) else { call.reject("Invalid chunk"); return false }
        let index = call.getInt("index") ?? -1
        guard index == nextIndex else { call.reject("Chunk out of order"); return false }
        guard data.count <= 512 * 1024, written + data.count <= limit, expected < 0 || written + data.count <= expected else { call.reject("Chunk exceeds the declared size"); return false }
        handle.write(data)
        written += data.count
        nextIndex += 1
        return true
    }
    func close() { try? handle.close() }
}

private func workDir(_ name: String) -> URL {
    let dir = FileManager.default.temporaryDirectory.appendingPathComponent(name, isDirectory: true)
    try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
    return dir
}

private func topPresenter(_ bridge: CAPBridgeProtocol?) -> UIViewController? {
    var vc = bridge?.viewController
    while let p = vc?.presentedViewController { vc = p }
    return vc
}

// MARK: - Sign-in hand-off (ASWebAuthenticationSession)
@objc(OrunAuthPlugin)
public class OrunAuthPlugin: CAPPlugin, CAPBridgedPlugin, ASWebAuthenticationPresentationContextProviding {
    public let identifier = "OrunAuthPlugin"
    public let jsName = "OrunAuth"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "signIn", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "openExternal", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "consumeColdStartUrl", returnType: CAPPluginReturnPromise),
    ]
    private let allowedPrefix = "https://orundocs.web.app/"
    private var session: ASWebAuthenticationSession?

    public func presentationAnchor(for session: ASWebAuthenticationSession) -> ASPresentationAnchor {
        return bridge?.webView?.window ?? ASPresentationAnchor()
    }

    @objc func signIn(_ call: CAPPluginCall) {
        guard let s = call.getString("url"), s.hasPrefix(allowedPrefix + "signin?"), let url = URL(string: s) else {
            call.reject("허용되지 않은 로그인 주소입니다."); return
        }
        DispatchQueue.main.async {
            self.session?.cancel()
            let auth = ASWebAuthenticationSession(url: url, callbackURLScheme: "com.orundocs.app") { [weak self] callback, error in
                self?.session = nil
                if let callback = callback, callback.scheme == "com.orundocs.app", callback.host == "auth" {
                    call.resolve(["url": callback.absoluteString])
                } else if let e = error as? ASWebAuthenticationSessionError, e.code == .canceledLogin {
                    call.reject("로그인을 취소했습니다.", "cancelled")
                } else {
                    call.reject("로그인하지 못했습니다: " + (error?.localizedDescription ?? "unknown"))
                }
            }
            auth.presentationContextProvider = self
            auth.prefersEphemeralWebBrowserSession = false
            self.session = auth
            if !auth.start() { self.session = nil; call.reject("로그인 화면을 열 수 없습니다.") }
        }
    }

    @objc func openExternal(_ call: CAPPluginCall) {
        guard let s = call.getString("url"), s.hasPrefix(allowedPrefix), let url = URL(string: s) else { call.reject("허용되지 않은 주소입니다."); return }
        DispatchQueue.main.async { UIApplication.shared.open(url) { ok in ok ? call.resolve() : call.reject("주소를 열 수 없습니다.") } }
    }

    @objc func consumeColdStartUrl(_ call: CAPPluginCall) { call.resolve(["url": NSNull()]) }
}

// MARK: - Save (Files app export, same contract as Android SAF)
@objc(AtelierSafPlugin)
public class AtelierSafPlugin: CAPPlugin, CAPBridgedPlugin, UIDocumentPickerDelegate {
    public let identifier = "AtelierSafPlugin"
    public let jsName = "AtelierSaf"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "beginSave", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "writeChunk", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "finishSave", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "abortSave", returnType: CAPPluginReturnPromise),
    ]
    private let limit = 500 * 1024 * 1024
    private var files: [String: ChunkFile] = [:]
    private var exporting: (id: String, call: CAPPluginCall)?
    private let queue = DispatchQueue(label: "orundocs.save")

    @objc func beginSave(_ call: CAPPluginCall) {
        let expected = call.getInt("expectedBytes") ?? -1
        guard expected <= limit else { call.reject("File too large"); return }
        queue.async {
            if self.files.count >= 4 { call.reject("Too many open saves", "E_BUSY"); return }
            let id = UUID().uuidString
            let dir = workDir("orundocs-save").appendingPathComponent(id, isDirectory: true)
            do {
                try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
                let name = safeFileName(call.getString("suggestedName"), fallback: "OrunDocs.pdf")
                self.files[id] = try ChunkFile(url: dir.appendingPathComponent(name), expected: expected)
                call.resolve(["id": id])
            } catch { call.reject("Could not prepare the file", "E_IO", error) }
        }
    }

    @objc func writeChunk(_ call: CAPPluginCall) {
        queue.async {
            guard let id = call.getString("id"), let f = self.files[id] else { call.reject("Unknown save"); return }
            if f.append(call, limit: self.limit) { call.resolve() }
        }
    }

    @objc func finishSave(_ call: CAPPluginCall) {
        queue.async {
            guard let id = call.getString("id"), let f = self.files[id] else { call.reject("Unknown save"); return }
            f.close()
            if f.expected >= 0 && f.written != f.expected { self.cleanup(id); call.reject("Written size differs from expectedBytes", "E_FINISH"); return }
            DispatchQueue.main.async {
                guard self.exporting == nil, let presenter = topPresenter(self.bridge) else { self.cleanup(id); call.reject("Save is busy", "E_BUSY"); return }
                let picker = UIDocumentPickerViewController(forExporting: [f.url], asCopy: true)
                picker.delegate = self
                picker.shouldShowFileExtensions = true
                self.exporting = (id, call)
                presenter.present(picker, animated: true)
            }
        }
    }

    @objc func abortSave(_ call: CAPPluginCall) {
        queue.async { if let id = call.getString("id") { self.cleanup(id) }; call.resolve() }
    }

    public func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let pending = exporting else { return }
        exporting = nil
        queue.async { self.cleanup(pending.id) }
        pending.call.resolve(["uri": urls.first?.absoluteString ?? "", "cancelled": false])
    }

    public func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        guard let pending = exporting else { return }
        exporting = nil
        queue.async { self.cleanup(pending.id) }
        pending.call.resolve(["cancelled": true])
    }

    private func cleanup(_ id: String) {
        if let f = files.removeValue(forKey: id) { f.close(); try? FileManager.default.removeItem(at: f.url.deletingLastPathComponent()) }
    }
}

// MARK: - Share sheet
@objc(AtelierSharePlugin)
public class AtelierSharePlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "AtelierSharePlugin"
    public let jsName = "AtelierShare"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "reset", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "beginFile", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "writeChunk", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "finishFile", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "share", returnType: CAPPluginReturnPromise),
    ]
    private let limit = 500 * 1024 * 1024
    private var files: [String: ChunkFile] = [:]
    private var total = 0
    private let queue = DispatchQueue(label: "orundocs.share")

    @objc func reset(_ call: CAPPluginCall) {
        queue.async {
            for f in self.files.values { f.close() }
            self.files.removeAll(); self.total = 0
            try? FileManager.default.removeItem(at: workDir("orundocs-share"))
            call.resolve()
        }
    }

    @objc func beginFile(_ call: CAPPluginCall) {
        queue.async {
            guard self.files.count < 20 else { call.reject("Too many files"); return }
            let id = UUID().uuidString
            let dir = workDir("orundocs-share").appendingPathComponent(id, isDirectory: true)
            do {
                try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
                self.files[id] = try ChunkFile(url: dir.appendingPathComponent(safeFileName(call.getString("name"), fallback: "file")), expected: call.getInt("expectedBytes") ?? -1)
                call.resolve(["id": id])
            } catch { call.reject("Could not prepare the file", "E_IO", error) }
        }
    }

    @objc func writeChunk(_ call: CAPPluginCall) {
        queue.async {
            guard let id = call.getString("id"), let f = self.files[id] else { call.reject("Unknown file"); return }
            let before = f.written
            if f.append(call, limit: self.limit - (self.total - before)) { self.total += f.written - before; call.resolve() }
        }
    }

    @objc func finishFile(_ call: CAPPluginCall) {
        queue.async {
            guard let id = call.getString("id"), let f = self.files[id] else { call.reject("Unknown file"); return }
            f.close()
            if f.expected >= 0 && f.written != f.expected { call.reject("Size mismatch"); return }
            call.resolve()
        }
    }

    @objc func share(_ call: CAPPluginCall) {
        let ids = (call.getArray("ids") as? [String]) ?? []
        queue.async {
            let urls = ids.compactMap { self.files[$0]?.url }
            guard !urls.isEmpty, urls.count == ids.count else { call.reject("Nothing to share"); return }
            DispatchQueue.main.async {
                guard let presenter = topPresenter(self.bridge) else { call.reject("No window"); return }
                let vc = UIActivityViewController(activityItems: urls, applicationActivities: nil)
                if let pop = vc.popoverPresentationController, let view = self.bridge?.viewController?.view {
                    pop.sourceView = view
                    pop.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.maxY - 80, width: 1, height: 1)
                    pop.permittedArrowDirections = [.down]
                }
                vc.completionWithItemsHandler = { _, completed, _, error in
                    if let error = error { call.reject("공유하지 못했습니다.", nil, error) } else { call.resolve(["completed": completed, "cancelled": !completed]) }
                }
                presenter.present(vc, animated: true)
            }
        }
    }
}
