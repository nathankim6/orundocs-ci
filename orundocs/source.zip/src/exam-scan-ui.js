// "시험지 필기 지우기" workspace: photo -> sheet corners -> handwriting removal -> review/brush -> save / share / print.
// Independent implementation for OrunDocs. Photos are processed only on this device (Web Worker).
import { buildPdf, buildDocx, jpegToPng, safeStem } from './exam-scan-export.mjs';
import { zipSync } from 'fflate';

const MAX_PAGES = 20, MAX_PHOTO_BYTES = 30 * 1024 * 1024;
const SENSITIVITY = { low: 0.15, normal: 0.5, high: 0.9 };
const icon = d => `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${d}"/></svg>`;

export function mountExamScanner({ main, onBack, save, share = null, canPrint = false, platform = 'desktop', setBusy = () => {} }) {
  const view = document.createElement('section');
  view.id = 'exam-view'; view.hidden = true; view.className = 'exam-view';
  view.innerHTML = `
  <div class="suite-detail-heading exam-heading">
    <button type="button" class="text-button" id="exam-back">← 모든 도구</button>
    <div class="eyebrow">변환 / LOCAL WORKSPACE</div>
    <h1>시험지 필기 지우기</h1>
    <p>시험지·숙제 사진에서 종이를 반듯하게 펴고, 연필·펜·형광펜 필기를 지워 깨끗한 학습지로 만듭니다.</p>
    <div class="suite-tool-note">사진은 이 기기 안에서만 처리되며 서버로 보내지 않습니다</div>
  </div>
  <section class="tool exam-tool" aria-label="시험지 필기 지우기 작업 공간">
    <ol class="exam-steps" aria-label="진행 단계"><li data-step="1">사진</li><li data-step="2">영역 맞추기</li><li data-step="3">필기 지우기</li><li data-step="4">저장·공유</li></ol>
    <div class="exam-add">
      <button type="button" class="primary" id="exam-camera-btn">${icon('M4 8h3l2-3h6l2 3h3v11H4zM12 17a4 4 0 1 0 0-8 4 4 0 0 0 0 8')}<span>카메라로 촬영</span></button>
      <button type="button" class="secondary" id="exam-pick-btn">${icon('M4 5h16v14H4zM4 15l5-5 4 4 3-3 4 4M15 9h.01')}<span>사진 선택</span></button>
      <input id="exam-camera" type="file" accept="image/*" capture="environment" hidden>
      <input id="exam-pick" type="file" accept="image/jpeg,image/png,image/webp,image/heic,image/heif" multiple hidden>
      <span class="exam-limit">최대 ${MAX_PAGES}장 · 장당 30 MB</span>
    </div>
    <ol id="exam-pages" class="exam-pages" aria-label="페이지 목록"></ol>
    <div id="exam-workspace" class="exam-workspace" hidden>
      <div class="exam-main">
        <div class="exam-tabs" role="tablist">
          <button type="button" role="tab" id="exam-tab-crop" aria-selected="true">영역 맞추기</button>
          <button type="button" role="tab" id="exam-tab-result" aria-selected="false">결과 보기</button>
        </div>
        <div id="exam-crop" class="exam-crop">
          <div class="exam-crop-stage" id="exam-crop-stage">
            <img id="exam-photo" alt="원본 사진">
            <svg class="exam-quad" viewBox="0 0 1 1" preserveAspectRatio="none" aria-hidden="true"><polygon id="exam-quad-poly" points=""/></svg>
          </div>
          <div class="exam-crop-tools">
            <button type="button" class="secondary" id="exam-auto">자동 감지</button>
            <button type="button" class="secondary" id="exam-full">전체 영역</button>
            <button type="button" class="secondary" id="exam-rot-l" aria-label="왼쪽으로 회전">↺ 회전</button>
            <button type="button" class="secondary" id="exam-rot-r" aria-label="오른쪽으로 회전">↻ 회전</button>
          </div>
          <p class="exam-hint">네 모서리 점을 끌어 시험지 가장자리에 맞추세요. <b id="exam-rotation"></b></p>
        </div>
        <div id="exam-result" class="exam-result" hidden>
          <div class="exam-result-stage"><canvas id="exam-canvas" aria-label="필기 지운 결과"></canvas></div>
          <div class="exam-brush" role="group" aria-label="수동 보정">
            <button type="button" class="secondary" id="exam-compare" aria-pressed="false">원본 보기</button>
            <span class="exam-sep"></span>
            <button type="button" class="exam-tool-btn" data-brush="none" aria-pressed="true">이동</button>
            <button type="button" class="exam-tool-btn" data-brush="erase" aria-pressed="false">지우개</button>
            <button type="button" class="exam-tool-btn" data-brush="restore" aria-pressed="false">복원</button>
            <label class="exam-size">굵기 <input type="range" id="exam-brush-size" min="4" max="60" value="12"></label>
            <button type="button" class="secondary" id="exam-undo" disabled>되돌리기</button>
          </div>
          <p class="exam-hint">남은 필기는 지우개로, 잘못 지워진 인쇄는 복원 브러시로 문질러 고칠 수 있습니다.</p>
        </div>
      </div>
      <aside class="exam-side">
        <fieldset class="exam-options"><legend>필기 지우기</legend>
          <label class="check-field"><input type="checkbox" id="exam-erase" checked> 필기 지우기 사용</label>
          <label class="check-field"><input type="checkbox" id="exam-color" checked> 색 펜·형광펜·채점 표시</label>
          <label class="check-field"><input type="checkbox" id="exam-pencil" checked> 연필·샤프 필기</label>
          <label>연필 지우기 강도<select id="exam-strength"><option value="low">약하게 · 인쇄 최대 보호</option><option value="normal" selected>보통</option><option value="high">강하게 · 진한 연필까지</option></select></label>
          <label>결과 모양<select id="exam-mode"><option value="clean" selected>깨끗하게 (흰 바탕)</option><option value="bw">흑백 (인쇄용)</option><option value="gray">회색조</option><option value="color">컬러</option></select></label>
          <button type="button" class="primary" id="exam-run">필기 지우기 실행 →</button>
          <small id="exam-dirty" hidden>설정이 바뀌었습니다. 다시 실행해 주세요.</small>
        </fieldset>
        <fieldset class="exam-export"><legend>저장·공유</legend>
          <label>형식<select id="exam-format"><option value="pdf" selected>PDF</option><option value="jpg">JPG 이미지</option><option value="png">PNG 이미지</option><option value="docx">Word (DOCX)</option></select></label>
          <label id="exam-paper-row">용지<select id="exam-paper"><option value="a4" selected>A4에 맞춤</option><option value="image">사진 비율 그대로</option></select></label>
          <label>파일 이름<input id="exam-name" value="시험지"></label>
          <div class="exam-export-buttons">
            <button type="button" class="primary" id="exam-save">저장</button>
            <button type="button" class="secondary" id="exam-share" hidden>공유</button>
            <button type="button" class="secondary" id="exam-print" hidden>인쇄</button>
          </div>
        </fieldset>
      </aside>
    </div>
    <div id="exam-status" class="exam-status" role="status" aria-live="polite" hidden></div>
    <p class="suite-disclaimer">자동 필기 제거는 연필의 진하기, 펜 색, 사진 품질에 따라 일부가 남거나 가는 인쇄선이 옅어질 수 있습니다. 결과를 확인하고 브러시로 보정하세요. 검정 펜 필기는 인쇄와 구별이 어려워 지우개 브러시로 지워야 할 수 있습니다.</p>
  </section>`;
  main.prepend(view);
  const $ = id => view.querySelector('#' + id);
  const state = { pages: [], current: -1, busy: false, brush: 'none', dirty: false, seq: 0 };
  let worker = null; const pending = new Map();

  $('exam-share').hidden = !share; $('exam-print').hidden = !canPrint;
  if (platform !== 'android') $('exam-camera-btn').hidden = true;

  function getWorker() {
    if (worker) return worker;
    worker = new Worker('/exam-scan-worker.js');
    worker.onmessage = ({ data }) => { const p = pending.get(data.id); if (!p) return; pending.delete(data.id); data.ok ? p.resolve(data) : p.reject(new Error(data.error || '처리 실패')); };
    worker.onerror = () => { for (const p of pending.values()) p.reject(new Error('이미지 처리 엔진을 시작하지 못했습니다.')); pending.clear(); worker?.terminate(); worker = null; };
    return worker;
  }
  const call = msg => new Promise((resolve, reject) => { const id = ++state.seq; pending.set(id, { resolve, reject }); getWorker().postMessage({ ...msg, id }); });

  function status(text, error = false) { const s = $('exam-status'); s.hidden = !text; s.textContent = text || ''; s.classList.toggle('is-error', !!error); }
  function lock(v) {
    state.busy = v; setBusy(v);
    for (const el of view.querySelectorAll('button, input, select')) if (el.id !== 'exam-compare' && !el.closest('.exam-brush')) el.disabled = v;
    if (!v) refresh();
  }
  const page = () => state.pages[state.current];

  // ---------- pages ----------
  async function addFiles(list) {
    if (state.busy) return;
    const files = Array.from(list || []);
    for (const file of files) {
      if (state.pages.length >= MAX_PAGES) { status(`최대 ${MAX_PAGES}장까지 추가할 수 있습니다.`, true); break; }
      if (!/^image\//.test(file.type) && !/\.(jpe?g|png|webp|heic|heif)$/i.test(file.name)) { status(file.name + ': 사진 파일만 추가할 수 있습니다.', true); continue; }
      if (file.size > MAX_PHOTO_BYTES) { status(file.name + ': 30 MB 이하 사진을 선택해 주세요.', true); continue; }
      const p = { file, name: file.name || '사진', corners: [[0, 0], [1, 0], [1, 1], [0, 1]], rotate: 0, previewUrl: '', result: null, strokes: [], detected: false };
      try { p.previewUrl = await makePreview(file); }
      catch { status(file.name + ': 사진을 열 수 없습니다. JPG·PNG 사진을 사용해 주세요.', true); continue; }
      state.pages.push(p);
      if (state.current < 0) state.current = 0;
    }
    if (state.pages.length && !$('exam-name').dataset.touched) $('exam-name').value = safeStem(state.pages[0].name) + '_필기제거';
    refresh(); select(state.current);
    lock(true);
    try {
      for (const p of state.pages) if (!p.detectedOnce) {
        status(`${state.pages.indexOf(p) + 1}번 사진에서 시험지 가장자리를 찾는 중입니다.`);
        try { const d = await call({ cmd: 'detect', file: p.file }); p.corners = d.corners; p.detected = d.detected; }
        catch (e) { status(e.message, true); }
        p.detectedOnce = true; if (p === page()) drawCrop();
      }
      status(state.pages.length ? '모서리를 확인한 뒤 "필기 지우기 실행"을 누르세요.' : '');
    } finally { lock(false); }
  }

  async function makePreview(file) {
    const bmp = await createImageBitmap(file, { imageOrientation: 'from-image' });
    const s = Math.min(1, 1400 / Math.max(bmp.width, bmp.height));
    const c = document.createElement('canvas'); c.width = Math.round(bmp.width * s); c.height = Math.round(bmp.height * s);
    c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height); bmp.close?.();
    const blob = await new Promise(r => c.toBlob(r, 'image/jpeg', 0.85));
    return URL.createObjectURL(blob);
  }

  function renderList() {
    const ol = $('exam-pages'); ol.replaceChildren();
    state.pages.forEach((p, i) => {
      const li = document.createElement('li'); li.className = 'exam-page' + (i === state.current ? ' active' : '');
      const b = document.createElement('button'); b.type = 'button'; b.className = 'exam-thumb'; b.setAttribute('aria-label', (i + 1) + '번 페이지 열기'); b.setAttribute('aria-current', i === state.current ? 'true' : 'false');
      const img = document.createElement('img'); img.alt = ''; img.src = p.result?.afterUrl || p.previewUrl;
      const n = document.createElement('span'); n.className = 'exam-page-num'; n.textContent = (i + 1) + (p.result ? ' · 완료' : '');
      b.append(img, n); b.onclick = () => select(i);
      const tools = document.createElement('div'); tools.className = 'exam-page-tools';
      for (const [label, aria, fn] of [['↑', '앞으로', () => move(i, -1)], ['↓', '뒤로', () => move(i, 1)], ['×', '삭제', () => remove(i)]]) {
        const t = document.createElement('button'); t.type = 'button'; t.className = 'text-button'; t.textContent = label; t.setAttribute('aria-label', (i + 1) + '번 페이지 ' + aria);
        t.disabled = state.busy || (aria === '앞으로' && i === 0) || (aria === '뒤로' && i === state.pages.length - 1); t.onclick = fn; tools.append(t);
      }
      li.append(b, tools); ol.append(li);
    });
  }
  function move(i, d) { const j = i + d; if (state.busy || j < 0 || j >= state.pages.length) return; [state.pages[i], state.pages[j]] = [state.pages[j], state.pages[i]]; if (state.current === i) state.current = j; else if (state.current === j) state.current = i; refresh(); }
  function remove(i) {
    if (state.busy) return; const [p] = state.pages.splice(i, 1); revoke(p);
    if (state.current >= state.pages.length) state.current = state.pages.length - 1; refresh(); select(state.current);
  }
  function revoke(p) { if (!p) return; URL.revokeObjectURL(p.previewUrl); if (p.result) { URL.revokeObjectURL(p.result.afterUrl); p.result.afterBmp?.close?.(); p.result.beforeBmp?.close?.(); } }

  function refresh() {
    renderList();
    const has = state.pages.length > 0, done = state.pages.some(p => p.result);
    $('exam-workspace').hidden = !has;
    for (const li of view.querySelectorAll('.exam-steps li')) { const s = +li.dataset.step; li.classList.toggle('done', (s === 1 && has) || (s === 2 && has) || (s === 3 && done)); }
    $('exam-tab-result').disabled = !page()?.result;
    $('exam-dirty').hidden = !state.dirty || !done;
    $('exam-paper-row').hidden = $('exam-format').value !== 'pdf';
    $('exam-save').disabled = state.busy || !has; $('exam-share').disabled = state.busy || !has; $('exam-print').disabled = state.busy || !has;
    $('exam-run').disabled = state.busy || !has;
  }

  function select(i) {
    if (i < 0 || i >= state.pages.length) { $('exam-workspace').hidden = true; return; }
    state.current = i; refresh(); showTab(page().result && !state.dirtyPages?.has(page()) ? 'result' : 'crop');
  }

  // ---------- crop ----------
  const handles = [];
  for (let k = 0; k < 4; k++) {
    const h = document.createElement('button'); h.type = 'button'; h.className = 'exam-handle'; h.setAttribute('aria-label', ['왼쪽 위', '오른쪽 위', '오른쪽 아래', '왼쪽 아래'][k] + ' 모서리');
    h.onpointerdown = e => { if (state.busy) return; e.preventDefault(); h.setPointerCapture(e.pointerId); h.dataset.drag = '1'; };
    h.onpointermove = e => {
      if (!h.dataset.drag) return; const r = $('exam-photo').getBoundingClientRect();
      const p = page(); p.corners[k] = [Math.min(1, Math.max(0, (e.clientX - r.left) / r.width)), Math.min(1, Math.max(0, (e.clientY - r.top) / r.height))];
      markDirty(p); drawCrop();
    };
    h.onpointerup = h.onpointercancel = () => { delete h.dataset.drag; };
    h.onkeydown = e => { const step = e.shiftKey ? 0.02 : 0.004, d = { ArrowLeft: [-step, 0], ArrowRight: [step, 0], ArrowUp: [0, -step], ArrowDown: [0, step] }[e.key]; if (!d) return; e.preventDefault(); const c = page().corners[k]; c[0] = Math.min(1, Math.max(0, c[0] + d[0])); c[1] = Math.min(1, Math.max(0, c[1] + d[1])); markDirty(page()); drawCrop(); };
    handles.push(h); $('exam-crop-stage').append(h);
  }
  function drawCrop() {
    const p = page(); if (!p) return;
    const img = $('exam-photo'); if (img.getAttribute('src') !== p.previewUrl) img.src = p.previewUrl;
    $('exam-quad-poly').setAttribute('points', p.corners.map(c => c.join(',')).join(' '));
    handles.forEach((h, k) => { h.style.left = p.corners[k][0] * 100 + '%'; h.style.top = p.corners[k][1] * 100 + '%'; });
    $('exam-rotation').textContent = p.rotate ? `결과는 ${p.rotate}° 회전됩니다` : '';
  }
  function markDirty(p) { if (!p.result) return; (state.dirtyPages ||= new Set()).add(p); state.dirty = true; refresh(); }
  $('exam-auto').onclick = async () => { const p = page(); if (!p || state.busy) return; lock(true); try { const d = await call({ cmd: 'detect', file: p.file }); p.corners = d.corners; markDirty(p); drawCrop(); status(d.detected ? '시험지 가장자리를 찾았습니다.' : '가장자리가 뚜렷하지 않아 전체 영역을 사용합니다. 점을 직접 맞춰 주세요.'); } catch (e) { status(e.message, true); } finally { lock(false); } };
  $('exam-full').onclick = () => { const p = page(); if (!p) return; p.corners = [[0, 0], [1, 0], [1, 1], [0, 1]]; markDirty(p); drawCrop(); };
  $('exam-rot-l').onclick = () => { const p = page(); if (!p) return; p.rotate = (p.rotate + 270) % 360; markDirty(p); drawCrop(); };
  $('exam-rot-r').onclick = () => { const p = page(); if (!p) return; p.rotate = (p.rotate + 90) % 360; markDirty(p); drawCrop(); };

  function showTab(tab) {
    const crop = tab === 'crop';
    $('exam-crop').hidden = !crop; $('exam-result').hidden = crop;
    $('exam-tab-crop').setAttribute('aria-selected', String(crop)); $('exam-tab-result').setAttribute('aria-selected', String(!crop));
    if (crop) drawCrop(); else renderResult();
  }
  $('exam-tab-crop').onclick = () => showTab('crop');
  $('exam-tab-result').onclick = () => { if (page()?.result) showTab('result'); };

  // ---------- processing ----------
  function options() {
    return { erase: $('exam-erase').checked, removeColor: $('exam-color').checked, removePencil: $('exam-pencil').checked, pencilSensitivity: SENSITIVITY[$('exam-strength').value], mode: $('exam-mode').value };
  }
  for (const id of ['exam-erase', 'exam-color', 'exam-pencil', 'exam-strength', 'exam-mode']) $(id).addEventListener('change', () => {
    $('exam-color').disabled = $('exam-pencil').disabled = $('exam-strength').disabled = !$('exam-erase').checked;
    if (state.pages.some(p => p.result)) { state.dirty = true; state.dirtyPages = new Set(state.pages.filter(p => p.result)); refresh(); }
  });
  $('exam-format').onchange = refresh;
  $('exam-name').oninput = () => { $('exam-name').dataset.touched = '1'; };

  async function processAll(onlyMissing = false) {
    const opts = options(); const list = state.pages.filter(p => !onlyMissing || !p.result || state.dirtyPages?.has(p));
    let i = 0;
    for (const p of list) {
      i++; status(`${i} / ${list.length} 페이지 처리 중… 종이를 펴고 필기를 지우고 있습니다.`);
      const r = await call({ cmd: 'process', file: p.file, corners: p.corners, rotate: p.rotate, ...opts });
      revoke({ previewUrl: '', result: p.result });
      const [afterBmp, beforeBmp] = await Promise.all([createImageBitmap(r.after), createImageBitmap(r.before)]);
      p.result = { width: r.width, height: r.height, afterBmp, beforeBmp, afterUrl: URL.createObjectURL(r.after), removedRatio: r.removedRatio };
      p.strokes = []; state.dirtyPages?.delete(p);
    }
    state.dirty = !!state.dirtyPages?.size;
  }
  $('exam-run').onclick = async () => {
    if (state.busy || !state.pages.length) return;
    lock(true);
    try {
      await processAll(false);
      state.dirty = false; state.dirtyPages = new Set();
      status(`${state.pages.length}장 처리 완료. 결과를 확인하고 필요하면 브러시로 보정한 뒤 저장하거나 공유하세요.`);
    } catch (e) { status(e.message || '처리하지 못했습니다.', true); }
    finally { lock(false); if (page()?.result) showTab('result'); }
  };

  // ---------- result + brush ----------
  const canvas = $('exam-canvas'); const ctx = canvas.getContext('2d');
  let comparing = false, drawing = null;
  function renderResult(target = canvas, p = page(), compare = comparing) {
    if (!p?.result) return;
    const c = target.getContext('2d');
    target.width = p.result.width; target.height = p.result.height;
    if (compare) { c.drawImage(p.result.beforeBmp, 0, 0); return; }
    c.drawImage(p.result.afterBmp, 0, 0);
    for (const s of p.strokes) applyStroke(c, p, s);
  }
  function applyStroke(c, p, s) {
    const pts = s.points; if (!pts.length) return;
    c.save(); c.beginPath();
    for (let i = 0; i < pts.length; i++) {
      const [x, y] = pts[i]; c.moveTo(x + s.r, y); c.arc(x, y, s.r, 0, Math.PI * 2);
      if (i) { const [px, py] = pts[i - 1], d = Math.hypot(x - px, y - py), n = Math.ceil(d / (s.r / 2)); for (let k = 1; k < n; k++) { const ix = px + (x - px) * k / n, iy = py + (y - py) * k / n; c.moveTo(ix + s.r, iy); c.arc(ix, iy, s.r, 0, Math.PI * 2); } }
    }
    if (s.mode === 'erase') { c.fillStyle = '#fff'; c.fill(); }
    else { c.clip(); c.drawImage(p.result.beforeBmp, 0, 0); }
    c.restore();
  }
  const toCanvas = e => { const r = canvas.getBoundingClientRect(); return [(e.clientX - r.left) * canvas.width / r.width, (e.clientY - r.top) * canvas.height / r.height]; };
  canvas.onpointerdown = e => {
    if (state.brush === 'none' || comparing || !page()?.result) return;
    e.preventDefault(); canvas.setPointerCapture(e.pointerId);
    const r = +$('exam-brush-size').value * canvas.width / Math.max(1, canvas.getBoundingClientRect().width);
    drawing = { mode: state.brush, r, points: [toCanvas(e)] }; page().strokes.push(drawing); applyStroke(ctx, page(), { ...drawing, points: drawing.points.slice(-1) });
  };
  canvas.onpointermove = e => { if (!drawing) return; drawing.points.push(toCanvas(e)); applyStroke(ctx, page(), { ...drawing, points: drawing.points.slice(-2) }); };
  canvas.onpointerup = canvas.onpointercancel = () => { if (!drawing) return; drawing = null; $('exam-undo').disabled = !page()?.strokes.length; updateThumb(); };
  $('exam-undo').onclick = () => { const p = page(); if (!p?.strokes.length) return; p.strokes.pop(); renderResult(); $('exam-undo').disabled = !p.strokes.length; updateThumb(); };
  for (const b of view.querySelectorAll('.exam-tool-btn')) b.onclick = () => { state.brush = b.dataset.brush; for (const o of view.querySelectorAll('.exam-tool-btn')) o.setAttribute('aria-pressed', String(o === b)); canvas.classList.toggle('is-brush', state.brush !== 'none'); };
  $('exam-compare').onclick = () => { comparing = !comparing; $('exam-compare').setAttribute('aria-pressed', String(comparing)); $('exam-compare').textContent = comparing ? '결과 보기' : '원본 보기'; renderResult(); };
  let thumbTimer = 0;
  function updateThumb() { clearTimeout(thumbTimer); thumbTimer = setTimeout(async () => { const p = page(); if (!p?.result) return; const blob = await pageBlob(p, 'image/jpeg', 0.6); URL.revokeObjectURL(p.result.afterUrl); p.result.afterUrl = URL.createObjectURL(blob); renderList(); }, 400); }

  async function pageBlob(p, type = 'image/jpeg', quality = 0.9) {
    const c = document.createElement('canvas'); renderResult(c, p, false);
    return new Promise((res, rej) => c.toBlob(b => b ? res(b) : rej(new Error('이미지를 만들지 못했습니다.')), type, quality));
  }

  // ---------- export ----------
  async function ensureProcessed() {
    if (state.pages.every(p => p.result) && !state.dirty) return;
    await processAll(true); state.dirty = false; state.dirtyPages = new Set();
  }
  async function outputs(forShare) {
    const fmt = $('exam-format').value, stem = safeStem($('exam-name').value || '시험지');
    const pages = [];
    for (const p of state.pages) pages.push({ jpeg: new Uint8Array(await (await pageBlob(p)).arrayBuffer()), width: p.result.width, height: p.result.height });
    if (fmt === 'pdf') return [{ name: stem + '.pdf', mime: 'application/pdf', bytes: await buildPdf(pages, { paper: $('exam-paper').value }) }];
    if (fmt === 'docx') return [{ name: stem + '.docx', mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', bytes: buildDocx(pages, { title: stem }) }];
    const imgs = [];
    for (let i = 0; i < pages.length; i++) {
      const suffix = pages.length > 1 ? '_' + String(i + 1).padStart(2, '0') : '';
      if (fmt === 'png') imgs.push({ name: stem + suffix + '.png', mime: 'image/png', bytes: await jpegToPng(pages[i].jpeg) });
      else imgs.push({ name: stem + suffix + '.jpg', mime: 'image/jpeg', bytes: pages[i].jpeg });
    }
    if (forShare || imgs.length === 1) return imgs;
    const zip = Object.create(null); for (const f of imgs) zip[f.name] = f.bytes;
    return [{ name: stem + '_이미지.zip', mime: 'application/zip', bytes: zipSync(zip, { level: 0 }) }];
  }
  $('exam-save').onclick = async () => {
    if (state.busy || !state.pages.length) return; lock(true);
    try {
      await ensureProcessed(); status('파일을 만드는 중입니다.');
      const [file] = await outputs(false); const r = await save(file);
      status(r?.cancelled ? '저장을 취소했습니다.' : file.name + ' 저장을 완료했습니다.');
    } catch (e) { status(e.message || '저장하지 못했습니다.', true); } finally { lock(false); }
  };
  $('exam-share').onclick = async () => {
    if (state.busy || !state.pages.length || !share) return; lock(true);
    try {
      await ensureProcessed(); status('공유할 파일을 만드는 중입니다.');
      const files = await outputs(true); const r = await share(files);
      status(r?.cancelled ? '공유를 취소했습니다.' : r?.savedInstead ? (r.message || '이 환경은 시스템 공유를 지원하지 않아 파일로 저장했습니다.') : '공유 창을 열었습니다.');
    } catch (e) { status(e.message || '공유하지 못했습니다.', true); } finally { lock(false); }
  };
  $('exam-print').onclick = async () => {
    if (state.busy || !state.pages.length) return; lock(true);
    let holder = null;
    try {
      await ensureProcessed(); holder = document.createElement('div'); holder.id = 'exam-print-sheet';
      const urls = [];
      for (const p of state.pages) { const url = URL.createObjectURL(await pageBlob(p)); urls.push(url); const img = document.createElement('img'); img.src = url; img.alt = ''; holder.append(img); }
      document.body.append(holder);
      await Promise.all(Array.from(holder.querySelectorAll('img'), i => i.decode().catch(() => {})));
      document.body.classList.add('exam-printing');
      window.print();
      document.body.classList.remove('exam-printing'); urls.forEach(u => URL.revokeObjectURL(u));
      status('인쇄 창을 열었습니다.');
    } catch (e) { status(e.message || '인쇄하지 못했습니다.', true); }
    finally { holder?.remove(); document.body.classList.remove('exam-printing'); lock(false); }
  };

  // ---------- wiring ----------
  $('exam-back').onclick = () => { if (!state.busy) onBack(); };
  $('exam-camera-btn').onclick = () => $('exam-camera').click();
  $('exam-pick-btn').onclick = () => $('exam-pick').click();
  for (const id of ['exam-camera', 'exam-pick']) $(id).onchange = e => { const files = Array.from(e.target.files || []); e.target.value = ''; addFiles(files); };
  view.addEventListener('dragover', e => { if (!view.hidden) e.preventDefault(); });
  view.addEventListener('drop', e => { if (view.hidden) return; e.preventDefault(); e.stopPropagation(); addFiles(e.dataTransfer.files); });

  refresh();
  return {
    view,
    isBusy: () => state.busy,
    open() { view.hidden = false; status(''); refresh(); if (state.current >= 0) select(state.current); },
    close() { view.hidden = true; }
  };
}
