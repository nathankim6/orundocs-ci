import { Capacitor, registerPlugin } from '@capacitor/core';
import { saveResultWithPlugin } from './saf-save-core.mjs';

// The native implementation is registered as @CapacitorPlugin(name = "AtelierSaf").
export const AtelierSaf = registerPlugin('AtelierSaf');

/**
 * Browser-side save adapter for an existing 옳은PDF result.
 * It deliberately does not implement a filesystem fallback: Android SAF is user-mediated.
 */
export async function saveResultFile(result, options = {}) {
  if (!Capacitor.isNativePlatform()) {
    throw new Error('AtelierSaf is available only in a native Capacitor runtime');
  }
  return saveResultWithPlugin(AtelierSaf, result, options);
}

export { MAX_CHUNK_BYTES, MAX_SAVE_BYTES, MAX_SOURCE_BYTES, saveResultWithPlugin } from './saf-save-core.mjs';
