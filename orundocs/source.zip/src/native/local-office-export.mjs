/*
 * Browser-only OOXML adapter for 옳은PDF extraction payloads.
 * Dependencies are intentionally bare imports so the Android web bundle can pin them:
 * docx@9.5.1, pptxgenjs@4.0.1, exceljs@4.4.0.
 */
import { Document, Packer, Paragraph, TextRun, PageBreak } from 'docx';
import PptxGenJS from 'pptxgenjs';
import ExcelJS from 'exceljs';

export const OFFICE_MIME = Object.freeze({
  docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
});

const MAX_REQUEST_BYTES = 160 * 1024 * 1024;
const MAX_OUTPUT_BYTES = 150 * 1024 * 1024;
const MAX_IMAGE_BYTES = 10 * 1024 * 1024;
const MAX_PAGES = 100;
const CONTROL_CHARS = /[\x00-\x08\x0b\x0c\x0e-\x1f]/g;
const encoder = new TextEncoder();

function clean(value) {
  return String(value ?? '').replace(CONTROL_CHARS, '');
}

function normalizedKind(kind) {
  const aliases = { 'pdf-to-word': 'docx', 'pdf-to-ppt': 'pptx', 'pdf-to-excel': 'xlsx' };
  const value = aliases[kind] || kind;
  if (!Object.hasOwn(OFFICE_MIME, value)) {
    throw new Error('kind must be pdf-to-word, pdf-to-ppt, pdf-to-excel, docx, pptx, or xlsx');
  }
  return value;
}

function outputName(name, kind) {
  // The calling conversion code already uses its safeName(); this also keeps the adapter safe standalone.
  const base = clean(name).split(/[\\/]/).pop() || 'export';
  const stem = (base.replace(/\.[^.]*$/, '') || 'export')
    .replace(/[\\/\x00-\x1f<>:"|?*]/g, '_').slice(0, 120) || 'export';
  return `${stem}.${kind}`;
}

function dimensions(page) {
  const width = Number(page?.width), height = Number(page?.height);
  if (!Number.isFinite(width) || !Number.isFinite(height) || width <= 0 || height <= 0 || width > 100000 || height > 100000) {
    throw new Error('each page requires positive numeric width and height');
  }
  return { width, height };
}

function strictBase64(value) {
  if (typeof value !== 'string' || !value) throw new Error('page image must be valid base64 PNG');
  const source = value.startsWith('data:') ? value.split(',', 2)[1] : value;
  if (!source || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(source)) {
    throw new Error('page image must be valid base64 PNG');
  }
  let binary;
  try { binary = atob(source); } catch { throw new Error('page image must be valid base64 PNG'); }
  const bytes = Uint8Array.from(binary, character => character.charCodeAt(0));
  if (bytes.byteLength > MAX_IMAGE_BYTES) throw new Error('page image exceeds 10MB');
  if (bytes.length < 8 || ![137, 80, 78, 71, 13, 10, 26, 10].every((byte, index) => bytes[index] === byte)) {
    throw new Error('page image must be a PNG');
  }
  return { bytes, dataUri: `data:image/png;base64,${source}` };
}

function validate(kind, name, pages, options) {
  if (!Array.isArray(pages) || !pages.length) throw new Error('pages must be a non-empty array');
  if (pages.length > MAX_PAGES) throw new Error('page count exceeds 100');
  for (const page of pages) {
    if (!page || typeof page !== 'object' || Array.isArray(page)) throw new Error('each page must be an object');
    dimensions(page);
    if (page.image) strictBase64(page.image);
  }
  // Match the former JSON request ceiling before a library sees a large payload. Options are accepted
  // for drop-in compatibility; the former document exporter did not apply pageSize/orientation/margin.
  let bytes;
  try { bytes = encoder.encode(JSON.stringify({ kind, name, pages, options })).byteLength; }
  catch { throw new Error('Office export payload must be JSON-serializable'); }
  if (bytes > MAX_REQUEST_BYTES) throw new Error('Office export payload exceeds 160 MB. Select fewer pages.');
}

function pageLines(page) {
  const lines = Array.isArray(page.lines) ? page.lines : [];
  const result = [];
  for (const item of lines) {
    if (typeof item === 'string') result.push(clean(item));
    else if (item && typeof item === 'object' && !Array.isArray(item)) {
      if (Array.isArray(item.spans)) {
        const spans = item.spans.map((span, index) => ({ span, index })).sort((a, b) => {
          const ax = a.span && typeof a.span === 'object' ? Number(a.span.x) : a.index;
          const bx = b.span && typeof b.span === 'object' ? Number(b.span.x) : b.index;
          return (Number.isFinite(ax) ? ax : a.index) - (Number.isFinite(bx) ? bx : b.index);
        });
        result.push(spans.map(({ span }) => clean(span && typeof span === 'object' ? span.text : span)).join(''));
      } else result.push(clean(item.text));
    } else if (Array.isArray(item)) {
      result.push(item.map(part => clean(part && typeof part === 'object' ? part.text : part)).join(''));
    }
  }
  if (!result.length && page.text) return clean(page.text).split(/\r?\n/);
  return result;
}

function extractionRows(page) {
  const rawLines = Array.isArray(page.lines) ? page.lines : [];
  const rows = [];
  for (const item of rawLines) {
    if (item && typeof item === 'object' && !Array.isArray(item) && Array.isArray(item.cells)) rows.push(item.cells.map(clean));
    else if (Array.isArray(item)) rows.push(item.map(value => clean(value && typeof value === 'object' ? value.text : value)));
  }
  if (rows.length) return rows;
  const fallback = pageLines(page).map(line => {
    const pieces = line.split(/\t+| {2,}/);
    return pieces.length > 1 ? pieces.map(clean) : [line];
  });
  return fallback.length ? fallback : [[clean(page.text)]];
}

async function makeDocx(pages) {
  const children = [];
  pages.forEach((page, index) => {
    for (const text of pageLines(page)) children.push(new Paragraph({ children: [new TextRun({ text })] }));
    if (index !== pages.length - 1) children.push(new Paragraph({ children: [new PageBreak()] }));
  });
  const document = new Document({
    sections: [{
      properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1134, bottom: 1134, left: 1020, right: 1020 } } },
      children
    }]
  });
  return new Uint8Array(await (await Packer.toBlob(document)).arrayBuffer());
}

async function makePptx(pages) {
  const first = dimensions(pages[0]);
  const presentation = new PptxGenJS();
  // PDF points / 72 are inches, preserving the first page's aspect ratio like the prior exporter.
  presentation.defineLayout({ name: 'PDF_ATELIER_PDF', width: first.width / 72, height: first.height / 72 });
  presentation.layout = 'PDF_ATELIER_PDF';
  presentation.author = '옳은PDF';
  presentation.subject = 'Raster PDF page export';
  for (const page of pages) {
    const { width, height } = dimensions(page);
    const image = strictBase64(page.image); // PPTX intentionally requires the raster payload.
    const slide = presentation.addSlide();
    const scale = Math.min(first.width / width, first.height / height);
    const imageWidth = (width * scale) / 72, imageHeight = (height * scale) / 72;
    slide.addImage({ data: image.dataUri, x: ((first.width / 72) - imageWidth) / 2, y: ((first.height / 72) - imageHeight) / 2, w: imageWidth, h: imageHeight });
  }
  const output = await presentation.write({ outputType: 'arraybuffer' });
  return new Uint8Array(output);
}

function textCell(cell, value) {
  // ExcelJS treats a primitive string as a string cell, never as {formula: ...}.
  cell.value = clean(value);
  cell.numFmt = '@';
  cell.alignment = { wrapText: true, vertical: 'top' };
}

async function makeXlsx(pages) {
  const workbook = new ExcelJS.Workbook();
  for (let index = 0; index < pages.length; index += 1) {
    const sheet = workbook.addWorksheet(`Page ${index + 1}`);
    const rows = extractionRows(pages[index]);
    const columns = Math.max(1, ...rows.map(row => row.length));
    for (let column = 1; column <= columns; column += 1) {
      const header = sheet.getCell(1, column);
      textCell(header, `Column ${column}`);
      header.font = { name: 'Malgun Gothic', bold: true, color: { argb: 'FFFFFFFF' } };
      header.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1F4E78' } };
    }
    rows.forEach((values, rowIndex) => values.forEach((value, columnIndex) => {
      const cell = sheet.getCell(rowIndex + 2, columnIndex + 1);
      textCell(cell, value);
      cell.font = { name: 'Malgun Gothic' };
    }));
    for (let column = 1; column <= columns; column += 1) {
      const longest = Math.max(0, ...rows.filter(row => row.length >= column).map(row => clean(row[column - 1]).length));
      sheet.getColumn(column).width = Math.min(60, Math.max(12, longest + 2));
    }
    sheet.views = [{ state: 'frozen', ySplit: 1 }];
    sheet.autoFilter = { from: { row: 1, column: 1 }, to: { row: rows.length + 1, column: columns } };
  }
  return new Uint8Array(await workbook.xlsx.writeBuffer());
}

/**
 * Drop-in browser replacement for exportOffice(kind, name, pages, options).
 * Returns the old caller's file object: {name, bytes: Uint8Array, mime}.
 */
export async function exportOffice(kind, name, pages, options = {}) {
  const normalized = normalizedKind(kind);
  validate(normalized, name, pages, options);
  const makers = { docx: makeDocx, pptx: makePptx, xlsx: makeXlsx };
  const bytes = await makers[normalized](pages);
  if (bytes.byteLength > MAX_OUTPUT_BYTES || bytes[0] !== 80 || bytes[1] !== 75) {
    throw new Error('Invalid or oversized Office export output.');
  }
  return { name: outputName(name, normalized), bytes, mime: OFFICE_MIME[normalized] };
}

export default exportOffice;
