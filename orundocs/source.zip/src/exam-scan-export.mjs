// Export cleaned exam pages as PDF, Word (DOCX) or images. Pure JS, local only.
import { PDFDocument } from 'pdf-lib';
import { zipSync, strToU8 } from 'fflate';

const A4_WIDTH_PT = 595.28, A4_HEIGHT_PT = 841.89;

function pageSize(width, height, paper) {
  if (paper === 'image') { const s = A4_WIDTH_PT / width; return [A4_WIDTH_PT, height * s]; }
  return width > height ? [A4_HEIGHT_PT, A4_WIDTH_PT] : [A4_WIDTH_PT, A4_HEIGHT_PT];
}

/** pages: [{jpeg: Uint8Array, width, height}] -> PDF bytes. Images are centred and fitted on A4 (or image-sized pages). */
export async function buildPdf(pages, { paper = 'a4', margin = 0 } = {}) {
  if (!pages.length) throw new Error('저장할 페이지가 없습니다.');
  const doc = await PDFDocument.create();
  doc.setProducer('옳은PDF'); doc.setCreator('옳은PDF · 옳은영어 김성진T');
  for (const p of pages) {
    const img = await doc.embedJpg(p.jpeg);
    const [pw, ph] = pageSize(p.width, p.height, paper);
    const page = doc.addPage([pw, ph]);
    const s = Math.min((pw - margin * 2) / p.width, (ph - margin * 2) / p.height);
    const w = p.width * s, h = p.height * s;
    page.drawImage(img, { x: (pw - w) / 2, y: (ph - h) / 2, width: w, height: h });
  }
  return doc.save();
}

const esc = s => String(s).replace(/[<>&"']/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' }[c]));

/** Minimal valid DOCX: one full-width picture per page, page break between pages. */
export function buildDocx(pages, { title = '옳은PDF 스캔' } = {}) {
  if (!pages.length) throw new Error('저장할 페이지가 없습니다.');
  const EMU_PER_INCH = 914400, maxW = 6.27 * EMU_PER_INCH, maxH = 9.69 * EMU_PER_INCH; // A4 minus 1" margins
  const rels = [], body = [], media = {};
  pages.forEach((p, i) => {
    const rid = 'rIdImg' + (i + 1), name = 'image' + (i + 1) + '.jpeg';
    media['word/media/' + name] = p.jpeg;
    rels.push(`<Relationship Id="${rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/${name}"/>`);
    const s = Math.min(maxW / p.width, maxH / p.height), cx = Math.round(p.width * s), cy = Math.round(p.height * s);
    body.push(`<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="${cx}" cy="${cy}"/><wp:docPr id="${i + 1}" name="Page ${i + 1}"/><a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:nvPicPr><pic:cNvPr id="${i + 1}" name="${name}"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="${rid}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>`);
    if (i < pages.length - 1) body.push('<w:p><w:r><w:br w:type="page"/></w:r></w:p>');
  });
  const files = {
    '[Content_Types].xml': strToU8('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="jpeg" ContentType="image/jpeg"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/></Types>'),
    '_rels/.rels': strToU8('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>'),
    'docProps/core.xml': strToU8(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:title>${esc(title)}</dc:title><dc:creator>옳은PDF</dc:creator></cp:coreProperties>`),
    'word/_rels/document.xml.rels': strToU8(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${rels.join('')}</Relationships>`),
    'word/document.xml': strToU8(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"><w:body>${body.join('')}<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr></w:body></w:document>`),
    ...media
  };
  return zipSync(files, { level: 6 });
}

/** Re-encode a JPEG page as PNG bytes using a canvas (browser only). */
export async function jpegToPng(jpeg) {
  const bmp = await createImageBitmap(new Blob([jpeg], { type: 'image/jpeg' }));
  const c = document.createElement('canvas'); c.width = bmp.width; c.height = bmp.height;
  c.getContext('2d').drawImage(bmp, 0, 0); bmp.close?.();
  const blob = await new Promise(r => c.toBlob(r, 'image/png'));
  return new Uint8Array(await blob.arrayBuffer());
}

export function safeStem(name) {
  return (String(name || 'scan').replace(/\.[^.]+$/, '').replace(/[\\/\x00-\x1f<>:"|?*]/g, '_').trim().slice(0, 80)) || 'scan';
}
