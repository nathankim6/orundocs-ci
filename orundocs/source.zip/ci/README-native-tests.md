# Private CI Android runtime smoke test

**Source-only, PRIVATE GitHub CI only, included/free runner usage only.** No signing
keys, private documents, external services, emulator downloads, Java, or Gradle
execution on the policy-blocked local Mac. The parent workflow owns repository,
billing, SDK/emulator setup, source build/sync, and CI artifact retention.

## Run on the CI runner only

Use SDK 36, Java 21, a clean API 36 emulator with a current compatible WebView,
English locale, and the stock DocumentsUI provider. Build the frontend and sync
Capacitor before testing, as managed by the parent workflow. Then from `android/`:

```sh
./gradlew :app:connectedDebugAndroidTest \
  -Pandroid.testInstrumentationRunnerArguments.class=com.pdfatelier.android.NativeWebViewSmokeTest \
  -Pandroid.testInstrumentationRunnerArguments.smokeArtifactDir=/sdcard/Android/data/com.pdfatelier.android/files/native-smoke
```

Without the class filter, the corrected ExampleInstrumentedTest also runs.
Only new dependency: `androidx.test.uiautomator:uiautomator:2.3.0`, an
`androidTestImplementation`. Existing AndroidX JUnit/Espresso supply test core.
No release signing or production manifest changes are required.

Collect on success **and failure**, before destroying the emulator:

```sh
adb pull /sdcard/Android/data/com.pdfatelier.android/files/native-smoke CI_OUTPUT/native-smoke
adb logcat -d -s AtelierNativeSmoke:I '*:S' > CI_OUTPUT/native-smoke-logcat.txt
```

Also collect `android/app/build/reports/androidTests/connected/` and
`android/app/build/outputs/androidTest-results/connected/` where available.
`CI_OUTPUT` is a parent-workflow-controlled runner directory, not a website or
user directory. The optional instrumentation directory must be inside the
app's external-files directory. Evidence includes screenshots, system UI XML,
small WebView state JSON, synthetic output copies, and PASS/FAIL markers.

## What the single bounded smoke scenario checks

- Launches the real `MainActivity` and its real Capacitor Android WebView on
  `https://localhost`, without production hooks or remote network fetches.
- Asserts 25 catalog cards, library heading, creator credit, and legacy `#picker`.
- Navigates actual catalog search/cards, injects a harmless two-page PDF with
  `File`/`DataTransfer` into the real `#suite-picker`, dispatches its change event,
  waits for PDF.js preview completion, page count, and nonwhite canvas pixels.
- Runs actual rotate UI processing; checks the output preview has 90-degree
  rotation. Saves the output via the real native plugin and real DocumentsUI.
  Reopens provider bytes with Android PdfRenderer and checks two pages.
- Runs all three real local conversions through their UI: DOCX, PPTX, XLSX.
  Saves each through the actual system Save control and reads actual provider
  bytes using ContentResolver. Checks OOXML ZIP structures, Word text elements,
  two PowerPoint slides and media, and a populated Excel sheet.
- Observes native promise forwarding, preserving original calls/results;
  validates ordered chunks no larger than 128 KiB and successful finish URI.
  Restores the original promise function when done. No JavascriptInterface,
  test hook, fake provider, stubbed converter, or intent interception is used.
- Has bounded waits and an overall eight-minute JUnit test timeout. Failure is
  not converted to a skip or treated as success. Logs clearly identify stage.

The test fixture in `androidTest/assets/smoke-two-pages.pdf` is copied from the
parent's 1,615-byte synthetic English PDF. It is bundled only in the test APK.
Only synthetic outputs are saved, with timestamp-based names in DocumentsUI's
clean-emulator default destination. The disposable emulator removes them;
the test does not delete documents from a provider.

## Limitations and verification status

Written and text-reviewed locally only. **NOT locally compiled or executed**:
macOS policy blocks the native toolchain. Java type resolution, Android runtime
behavior, DocumentsUI Save resource/text behavior, and CI pass status remain to
be established by the actual private CI job. No native success is claimed merely
because these source files exist.

This is smoke coverage, not verification of all 25 cards or output fidelity.
The catalog count is inventory only. It does not test native input picking,
passwords, cancellation, lifecycle recovery, multi-chunk output (>128 KiB),
negative bridge cases, or every document format variation. Small generated
outputs may exercise only one chunk. File injection deliberately bypasses input
picker UI, while **output saving must use real system picker UI** four times.
It expects an English, clean emulator and a writable default DocumentsUI folder;
it fails if a Save control is absent/disabled rather than silently replacing
SAF with a mock. Assertions are structural, not independent Microsoft Office
rendering/round-trip validation. CSP is unchanged; instrumentation directly
uses WebView.evaluateJavascript, without JavaScript eval or injected script tags.
