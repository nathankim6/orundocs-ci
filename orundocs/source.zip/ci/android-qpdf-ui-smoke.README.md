# Additional native input + qpdf UI smoke

**Actual emulator execution: PENDING.** Locally validated only with `node --check android-qpdf-ui-smoke.cjs`. No local adb/native Android commands were run. No app, APK, source archive, Gradle, Java test, key, or workflow was changed.

## Exact invocation in approved PRIVATE Ubuntu GitHub CI

Run after the existing `NativeWebViewSmokeTest`, against the already-installed exact signed release APK, in the same freshly provisioned private emulator. No npm dependencies, network requests, installation, or accounts are used by this script. Node 18+ and an existing adb are required.

Parent must extract the known 1615-byte, two-page fixture from the source archive and push it to the exact path below before execution. These shell commands are **CI-only**, not local instructions:

```sh
# Substitute existing CI paths; do not rebuild, re-sign, or install a different APK.
SERIAL=emulator-5554
APK="$GITHUB_WORKSPACE/path/to/exact-signed-release.apk"
FIXTURE="$GITHUB_WORKSPACE/path/to/extracted-two-page-fixture.pdf"
SCRIPT="$GITHUB_WORKSPACE/android-qpdf-ui-smoke.cjs"

adb -s "$SERIAL" push "$FIXTURE" /sdcard/Download/ci-qpdf-input.pdf
node "$SCRIPT" \
  --serial "$SERIAL" \
  --apk "$APK" \
  --fixture "$FIXTURE" \
  --output "$GITHUB_WORKSPACE/ci-output/qpdf-ui-smoke" \
  --fresh-private-emulator
```

`ci-output/qpdf-ui-smoke` must not exist before running. The script refuses stale output directories and an existing `Download/ci-qpdf-input-compress.pdf`; do not delete unrelated files to make it pass. Provision a fresh own emulator instead. It refuses execution unless Linux, `CI=true`, `GITHUB_ACTIONS=true`, an explicit `emulator-N` serial, `ro.kernel.qemu=1`, and English emulator locale are present. The explicit ownership flag asserts parent-verified fresh/private/authorized CI; the script cannot independently verify repository visibility or human approval.

## What a PASS means

1. Installed single APK bytes have the same SHA-256 and length as the caller-supplied exact signed release APK. This establishes byte identity, not independent signer trust. Split APK installs are unsupported.
2. The already-pushed exact named fixture has identical bytes to the supplied 1615-byte `%PDF-` source fixture. The parent is responsible for extracting the known two-page fixture, not another 1615-byte PDF.
3. UIAutomator XML supplies actual text/content-desc, classes, state, and bounds. Every tap uses a matched node's bounds center. Swipes derive from actual accessible scrollable containers, with bounded retries. Missing/ambiguous accessibility, inaccessible controls, unavailable fixture, and timeouts fail, without guessed screenshot coordinates.
4. The app's toolbar `도구 검색 열기` only opens/focuses the separate `PDF 도구 검색` / `도구 이름이나 기능 검색` EditText. ASCII `compress` filters the catalog by tool ID. The script opens `PDF 압축`, verifies the image-compression checkbox is unchecked, and uses the real `파일 선택 ＋` button.
5. Native English DocumentsUI is detected by its package, navigated to Downloads, and only the exact `ci-qpdf-input.pdf` is selected. The app must display the returned file in its input list.
6. Real execution must yield `처리가 완료되었습니다. 결과를 검토한 뒤 다운로드하세요.`, the source-specific `무손실 qpdf 재작성 완료 (1615 → N바이트)` success summary, and `ci-qpdf-input-compress.pdf` with its real download control. This source path awaits the qpdf Worker; raster output is not accepted. Transient processing status is recorded when observable, but a fast successful task need not expose it between XML dumps.
7. By default, the real output download button opens native SAF, selects Downloads, preserves the expected filename, and clicks Save. The app must report `저장 요청을 완료했습니다.`. Only the exact new own output path is then read through adb. Its size must equal N and its bytes must have a PDF header and EOF. The output PDF and its SHA-256 are evidence. No size decrease is required.

The compact stdout `PASS native-input-picker qpdf-STRUCTURE ... saved-pdf=true` is emitted only after all checks and evidence writing succeed. Nonzero exit and `FAIL` mean failure; inspect `summary.json` and the latest XML. Upload the evidence directory on CI failure as well. Do not mark workflow success based on script existence or syntax checking.

## Optional UI-only mode

Add `--no-save` only if intentionally limiting this additional smoke to native input and qpdf UI results. This skips SAF save/readback, sets `savedPdf:false`, and prints `saved-pdf=false`. It is not saved-output verification. Default invocation above is stronger and recommended.

## Limits and safety

- Evidence is capped at **18 MiB**, below 20 MB: stage XML/PNG, latest XML, summary JSON, and (default mode) saved PDF. No logcat, document enumeration, or APK copies are stored as evidence.
- Global eight-minute budget; qpdf completion polling is bounded to 155 seconds (the app's worker timeout is 120 seconds). Individual adb calls are bounded. Hard CI cancellation may prevent final summary writing; never infer PASS from partial evidence.
- No JS injection, WebView debugging, root, policy changes, webserver APIs, installs, source edits, app-data clearing, device file deletion, external npm, or network use. Runtime actions are standard adb on the explicit own emulator: inspect package/device, launch app, accessibility dump, input events, screenshots, and read exact input/output paths. XML dumps write only `/sdcard/ci-qpdf-uiautomator.xml`.
- Downloads is intentionally the only DocumentsUI provider used. Unusual picker variants, filename editing requirements, missing accessibility labels, or hidden containers can fail truthfully. No picker intent shortcut or direct injected document replaces the app's native INPUT interaction.
- A PDF header/EOF and byte count are not a full parser/conformance or two-page visual-preservation test. This supplements, not replaces, the existing preview/rotate/Office/SAF instrumentation. No claim of real-device coverage or smaller output is made.
- Source mappings inspected: `src/toolkit.js`, `src/pdf-ops.js`, `src/tool-catalog.js`, `public/index.html`, plus toolbar wiring in `public/pro-shell.js`. No runtime dependence on the source tree.
