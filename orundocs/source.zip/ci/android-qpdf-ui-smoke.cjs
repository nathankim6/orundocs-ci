#!/usr/bin/env node
'use strict';
// CI-only, dependency-free black-box smoke. Never import this file to run locally.
// APK is already installed; this script neither installs nor changes app code/data.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {spawn, spawnSync} = require('node:child_process');
const assert = (ok, message) => { if (!ok) throw Error(message); };
const PKG = 'com.pdfatelier.android';
const INPUT = 'ci-qpdf-input.pdf';
const OUTPUT = 'ci-qpdf-input-compress.pdf';
const DEVICE_INPUT = '/sdcard/Download/' + INPUT;
const DEVICE_OUTPUT = '/sdcard/Download/' + OUTPUT;
const XML_PATH = '/sdcard/ci-qpdf-uiautomator.xml';
const LIMIT = 18 * 1024 * 1024; // Strictly below 20 MB including summary.
const started = Date.now();
const summary = {schema:1, status:'PENDING', package:PKG, mode:'STRUCTURE (lossy=false)',
  nativeInputPicker:false, qpdfResult:false, savedPdf:false, stages:[],
  processingObserved:false, limitations:[
    'Black-box UI evidence plus source-mapped qpdf-only success summary; no JS/worker instrumentation.',
    'Not a PDF conformance, visual equivalence, signature trust, or size-reduction assertion.',
    'Requires a fresh, private, English DocumentsUI emulator; app UI is Korean.'
  ]};
let outDir, serial, latest, stage = 'preflight';
const args = Object.create(null);
for (let i=2;i<process.argv.length;i++) {
  const k=process.argv[i];
  assert(['--serial','--apk','--fixture','--output','--fresh-private-emulator','--no-save'].includes(k), 'Unknown option: '+k);
  assert(!(k in args), 'Duplicate option: '+k);
  if (k==='--fresh-private-emulator'||k==='--no-save') args[k]=true;
  else { assert(process.argv[i+1]&&!process.argv[i+1].startsWith('--'), 'Missing value: '+k); args[k]=process.argv[++i]; }
}
function deadline() { assert(Date.now()-started < 8*60*1000, 'Global eight-minute timeout'); }
function adb(argv, opts={}) {
  deadline();
  const r=spawnSync('adb',['-s',serial,...argv],{encoding:opts.binary?null:'utf8',timeout:opts.timeout||25000,
    maxBuffer:opts.maxBuffer||3*1024*1024,windowsHide:true});
  assert(!r.error, 'adb '+argv.slice(0,3).join(' ')+': '+(r.error?.message||''));
  assert(r.status===0, 'adb failed: '+argv.slice(0,3).join(' ')+' '+String(r.stderr||'').slice(0,500));
  return r.stdout;
}
const shell = (...argv) => adb(['shell',...argv]);
const pause = ms => new Promise(resolve=>setTimeout(resolve,ms));
const hash = b => crypto.createHash('sha256').update(b).digest('hex');
function evidence(name, data) {
  assert(outDir && /^[a-z0-9.-]+$/.test(name), 'Invalid evidence name');
  const bytes=Buffer.isBuffer(data)?data:Buffer.from(data);
  let used=0;
  for (const f of fs.readdirSync(outDir)) if(f!==name) used+=fs.statSync(path.join(outDir,f)).size;
  assert(used+bytes.length <= LIMIT, 'Evidence budget exceeded (18 MiB); failing rather than silently dropping proof');
  fs.writeFileSync(path.join(outDir,name), bytes);
}
function decode(v) {
  return v.replace(/&(#x[\da-f]+|#\d+|amp|quot|apos|lt|gt);/gi,(_,e)=> {
    if(e[0]==='#') return String.fromCodePoint(e[1].toLowerCase()==='x'?parseInt(e.slice(2),16):parseInt(e.slice(1),10));
    return {amp:'&',quot:'"',apos:"'",lt:'<',gt:'>'}[e];
  });
}
function parseXml(xml) {
  assert(xml.includes('<hierarchy') && xml.includes('</hierarchy>'), 'Missing/truncated UIAutomator XML');
  const nodes=[],stack=[];
  for(const m of xml.matchAll(/<node\b[^>]*>|<\/node>/g)) {
    if(m[0]==='</node>') { assert(stack.length,'Malformed UI XML');stack.pop();continue; }
    const n={parent:stack.at(-1)||null};
    for(const a of m[0].matchAll(/([\w:-]+)="([^"]*)"/g)) n[a[1]]=decode(a[2]);
    const b=/^\[(\d+),(\d+)\]\[(\d+),(\d+)\]$/.exec(n.bounds||'');
    n.rect=b?b.slice(1).map(Number):null;
    nodes.push(n); if(!m[0].endsWith('/>')) stack.push(n);
  }
  assert(nodes.length&&stack.length===0,'Malformed/empty accessibility tree');
  return nodes;
}
function visible(n) {return n.rect && n.rect[2]>n.rect[0] && n.rect[3]>n.rect[1] && n['visible-to-user']!=='false';}
function labels(n) {return [n.text||'',n['content-desc']||''];}
function exact(...values) {return n=>labels(n).some(x=>values.includes(x));}
function includes(text) {return n=>labels(n).some(x=>x.includes(text));}
function app(n) {return n.package===PKG;}
function docs(n) {return /^(com\.android|com\.google\.android)\.documentsui$/.test(n.package||'');}
function candidates(pred, scope=()=>true) {return latest.nodes.filter(n=>visible(n)&&scope(n)&&pred(n));}
function one(pred,scope=()=>true,optional=false) {
  let a=candidates(pred,scope);
  const enabled=a.filter(n=>n.enabled!=='false'); if(enabled.length)a=enabled;
  // WebView sometimes exposes identical nested text and clickable button labels.
  const click=a.filter(n=>n.clickable==='true');if(click.length===1)a=click;
  if(!a.length&&optional)return null;
  assert(a.length===1, 'Expected one unambiguous accessible target; found '+a.length);
  assert(a[0].enabled!=='false','Target is disabled');return a[0];
}
function detectErrors() {
  const bad=latest.nodes.filter(visible).flatMap(labels).find(t=>
    /실패했습니다|시작하지 못했습니다|처리 제한 시간|PDF를 읽을 수 없습니다|먼저 파일을 선택해 주세요|지원하지 않는 도구|Error:|RuntimeError|WebAssembly.*(?:failed|error)|keeps stopping|isn't responding/i.test(t));
  assert(!bad,'Visible error: '+bad);
}
function dump() {
  // uiautomator dump can transiently fail while WebView content is busy; bounded retries, never guessed state.
  let xml='';
  for(let attempt=0;attempt<6;attempt++){
    try{shell('uiautomator','dump',XML_PATH);xml=adb(['exec-out','cat',XML_PATH],{maxBuffer:2*1024*1024});}catch{xml='';}
    if(/<\/hierarchy>\s*$/.test(String(xml)))break;
    require('node:child_process').spawnSync('sleep',['1']);
  }
  latest={xml,nodes:parseXml(xml)};
  evidence('latest.xml',xml);detectErrors();return latest;
}
function capture(name) {
  evidence(name+'.xml',latest.xml);
  evidence(name+'.png',adb(['exec-out','screencap','-p'],{binary:true,maxBuffer:4*1024*1024}));
  summary.stages.push({name,elapsedMs:Date.now()-started});
}
function tap(n) {
  assert(visible(n)&&n.enabled!=='false','Cannot tap inaccessible/disabled node');
  const [l,t,r,b]=n.rect;
  shell('input','tap',String(Math.floor((l+r)/2)),String(Math.floor((t+b)/2)));
  dump();
}
function scroll(scope,direction='down') {
  const a=candidates(n=>n.scrollable==='true',scope).sort((x,y)=>
    (y.rect[2]-y.rect[0])*(y.rect[3]-y.rect[1])-(x.rect[2]-x.rect[0])*(x.rect[3]-x.rect[1]));
  assert(a.length,'No accessible scrollable container; refusing guessed swipe coordinates');
  const [l,t,r,b]=a[0].rect, x=Math.floor((l+r)/2), hi=Math.floor(t+(b-t)*0.23),lo=Math.floor(t+(b-t)*0.77);
  assert(lo-hi>40,'Scrollable bounds too small');
  shell('input','swipe',String(x),String(direction==='down'?lo:hi),String(x),String(direction==='down'?hi:lo),'450');
  dump();
}
function seek(pred,scope=app,maxScrolls=6,direction='down') {
  for(let i=0;i<=maxScrolls;i++) {
    const found=one(pred,scope,true);if(found)return found;
    if(i<maxScrolls)scroll(scope,direction);
  }
  throw Error('Target absent after bounded accessibility-driven scrolls');
}
async function until(predicate,ms,description) {
  const end=Date.now()+ms;
  do {dump();if(predicate())return;await pause(650);} while(Date.now()<end);
  throw Error('Timeout: '+description);
}
async function deviceApkHash(devicePath) {
  deadline();
  return new Promise((resolve,reject)=> {
    const c=spawn('adb',['-s',serial,'exec-out','cat',devicePath],{stdio:['ignore','pipe','pipe']});
    const h=crypto.createHash('sha256');let err='',size=0,settled=false;
    const finish=(error,value)=>{if(settled)return;settled=true;clearTimeout(timer);error?reject(error):resolve(value);};
    const timer=setTimeout(()=>{c.kill('SIGKILL');finish(Error('Installed APK read timeout'));},60000);
    c.stdout.on('data',b=>{size+=b.length;if(size>512*1024*1024){c.kill('SIGKILL');finish(Error('Installed APK exceeds 512 MiB'));}else h.update(b);});
    c.stderr.on('data',b=>{if(err.length<500)err+=b.toString();});
    c.on('error',e=>finish(e));c.on('close',code=>code===0?finish(null,{sha256:h.digest('hex'),bytes:size}):finish(Error('Cannot read installed APK: '+err)));
  });
}
function navigateDownloads() {
  assert(candidates(()=>true,docs).length,'Expected native DocumentsUI, not a web file chooser');
  const root=one(exact('Show roots','Open navigation drawer','Show navigation drawer'),docs,true);
  if(root)tap(root);
  // Only the named Downloads location is allowed; no arbitrary provider/doc iteration.
  tap(one(exact('Downloads'),docs));
  assert(candidates(exact('Downloads'),docs).length,'Downloads location not confirmed');
}
async function main() {
  assert(process.platform==='linux'&&process.env.CI==='true'&&process.env.GITHUB_ACTIONS==='true',
    'Execution allowed only in Linux GitHub CI (CI=true, GITHUB_ACTIONS=true); local syntax-check only');
  assert(args['--fresh-private-emulator'],'Require explicit --fresh-private-emulator ownership acknowledgement');
  for(const k of ['--serial','--apk','--fixture','--output'])assert(args[k],'Required: '+k);
  serial=args['--serial'];assert(/^emulator-\d+$/.test(serial),'Only an explicit emulator-N serial is allowed');
  const wantedOut=path.resolve(args['--output']);
  assert(wantedOut.split(path.sep).slice(0,-1).includes('ci-output'),'--output must be a dedicated child directory under ci-output');
  assert(!fs.existsSync(wantedOut),'Evidence directory must not already exist (prevents stale PASS/results)');
  fs.mkdirSync(wantedOut,{recursive:true});outDir=wantedOut;
  const fixture=fs.readFileSync(args['--fixture']);
  assert(fixture.length===1615&&fixture.subarray(0,5).toString()==='%PDF-','Expected exact 1615-byte PDF source fixture');
  summary.fixture={bytes:fixture.length,sha256:hash(fixture),devicePath:DEVICE_INPUT};
  assert(shell('getprop','ro.kernel.qemu').trim()==='1','Device is not an Android emulator');
  const persistedLocale=shell('getprop','persist.sys.locale').trim();
  const locale=persistedLocale||shell('getprop','ro.product.locale').trim();
  summary.localeSource=persistedLocale?'persist.sys.locale':'ro.product.locale';
  assert(/^en(?:[-_]|$)/i.test(locale),'English emulator locale required, found '+locale);
  summary.serial=serial;summary.locale=locale;
  const apk=fs.readFileSync(args['--apk']);assert(apk.subarray(0,2).toString()==='PK','--apk is not an APK/ZIP');
  const paths=shell('pm','path',PKG).trim().split(/\r?\n/);
  assert(paths.length===1&&/^package:\/data\/app\/[A-Za-z0-9_./=+~-]+\.apk$/.test(paths[0]),'Expected one installed base APK, no splits');
  const installed=await deviceApkHash(paths[0].slice(8));
  assert(installed.sha256===hash(apk)&&installed.bytes===apk.length,'Installed APK differs from supplied exact signed release APK');
  summary.apk={sha256:installed.sha256,bytes:installed.bytes,installedByteIdentity:true};
  const deviceFixture=adb(['exec-out','cat',DEVICE_INPUT],{binary:true,maxBuffer:16384});
  assert(deviceFixture.equals(fixture),'Pushed Download/ci-qpdf-input.pdf differs from source fixture');
  if(!args['--no-save']) assert(shell('sh','-c',"'if [ -e "+DEVICE_OUTPUT+" ]; then echo EXISTS; else echo ABSENT; fi'").trim()==='ABSENT',
    'Output already exists; use a fresh emulator, never overwrite another result');
  shell('am','force-stop',PKG);
  const resolve=shell('cmd','package','resolve-activity','--brief',PKG).trim().split(/\r?\n/).at(-1);
  assert(new RegExp('^'+PKG.replace(/\./g,'\\.')+'/[A-Za-z0-9_.$]+$').test(resolve),'Cannot resolve package launch activity');
  shell('am','start','-W','-n',resolve);
  stage='launch';
  // Chromium exposes WebView content to accessibility lazily; wait for a real app control, not just the WebView container.
  await until(()=>candidates(exact('도구 검색 열기','PDF 도구 검색','도구 이름이나 기능 검색','모든 도구','PDF Atelier 홈'),app).length,45000,'app web content accessibility');capture('01-launch');
  // pro-shell's toolbar button resets Home then focuses tool-search; it is NOT the input.
  // Fallback uses the real library input after bounded scrolling, never a guessed toolbar tap.
  const toolbar=one(exact('도구 검색 열기'),app,true);
  if(toolbar)tap(toolbar);
  else {
    let home=one(exact('← 모든 도구'),app,true)||one(exact('모든 도구'),app,true)||one(exact('PDF Atelier 홈'),app,true);
    if(!home && !candidates(exact('PDF 도구 검색','도구 이름이나 기능 검색'),app).length)
      home=seek(exact('← 모든 도구','모든 도구','PDF Atelier 홈'),app,8,'up');
    if(home)tap(home);
  }
  stage='tool-search';
  // Some WebView versions (e.g. 124) do not expose an input's aria-label. The app focuses the real
  // tool-search input when the toolbar search button is used, so accept that focused app EditText.
  const focusedSearch=toolbar?latest.nodes.find(n=>app(n)&&/EditText/.test(n.class||'')&&n.focused==='true'):null;
  if(focusedSearch){summary.toolSearch='focused-by-app-toolbar';}
  else{
    const search=seek(exact('PDF 도구 검색','도구 이름이나 기능 검색'),app,9);
    assert(/EditText/.test(search.class||''),'Tool search is not an accessible EditText');tap(search);summary.toolSearch='labelled-input';
  }
  shell('input','text','compress');dump();
  // Dismiss IME, then re-read; never use toolbar/library guessed coordinates.
  shell('input','keyevent','111');dump();capture('02-search');
  tap(seek(exact('PDF 압축 도구 열기','PDF 압축'),app,4));
  stage='compress-options';
  // WebView 124 reports the labelled checkbox as class CheckBox with checkable=false and stale off-screen bounds;
  // read its exposed checked state structurally (no coordinates are used for this assertion).
  const isLossy=n=>app(n)&&(n.checkable==='true'||/CheckBox/.test(n.class||''))&&includes('이미지 압축 사용')(n);
  const lossyBoxes=latest.nodes.filter(isLossy);
  assert(lossyBoxes.length===1,'Expected one lossy-compression checkbox; found '+lossyBoxes.length);
  const checkbox=lossyBoxes[0];
  assert(checkbox.checked==='false','Lossy checkbox is not demonstrably unchecked; refuse raster compression');
  summary.lossyChecked=false;capture('03-structure-options');
  let choose=one(exact('파일 선택 ＋','파일 선택'),app,true);
  if(!choose)choose=seek(exact('파일 선택 ＋','파일 선택'),app,6,'up');
  tap(choose);
  stage='native-input';await until(()=>candidates(()=>true,docs).length,20000,'native DocumentsUI input picker');capture('04-native-input');
  navigateDownloads();
  const file=seek(exact(INPUT),docs,4);capture('05-fixture-visible');tap(file);
  // Some DocumentsUI versions require explicit Open after single selection.
  if(candidates(()=>true,docs).length){const open=one(exact('Open','OPEN'),docs,true);if(open)tap(open);}
  await until(()=>candidates(includes('1. '+INPUT+' ·'),app).length,30000,'chosen fixture returned to app');
  summary.nativeInputPicker=true;capture('06-input-returned');
  stage='run-qpdf';tap(seek(exact('실행하기 →','실행하기'),app,9));
  const done=()=>candidates(exact('처리가 완료되었습니다. 결과를 검토한 뒤 다운로드하세요.'),app).length>0;
  const resultEnd=Date.now()+155000;let found=false;
  while(Date.now()<resultEnd){
    dump();
    if(candidates(n=>labels(n).some(t=>/로컬 qpdf 처리 중|파일을 처리하고 있습니다|처리 중…/.test(t)),app).length&&!summary.processingObserved){summary.processingObserved=true;capture('07-processing');}
    if(done()){found=true;break;}
    // Result/status may sit below the fold. Bounded scroll only in app containers.
    if(candidates(exact('실행하기 →'),app).length && !candidates(exact('처리 중…'),app).length){
      if(!summary.resultScrolls)summary.resultScrolls=0;
      if(summary.resultScrolls<5){scroll(app);summary.resultScrolls++;if(done()){found=true;break;}}
    }
    await pause(750);
  }
  assert(found,'No real completion status within qpdf processing timeout');
  const qpdf=seek(includes('무손실 qpdf 재작성 완료 (1615 →'),app,4);
  const text=labels(qpdf).find(t=>t.includes('무손실 qpdf 재작성 완료'));
  const count=/무손실 qpdf 재작성 완료 \(1615 → (\d+)바이트\)/.exec(text);
  assert(count&&Number(count[1])>0,'Missing positive qpdf result byte count');
  summary.result={name:OUTPUT,bytes:Number(count[1]),summary:text};
  assert(!candidates(includes('-compressed-image.pdf'),app).length,'Unexpected raster result');
  const download=seek(exact(OUTPUT+' 다운로드'),app,5);
  assert(candidates(includes(OUTPUT+' ·'),app).length,'Missing PDF result row');
  summary.qpdfResult=true;capture('08-qpdf-result');
  if(!args['--no-save']) {
    stage='save-result';tap(download);
    await until(()=>candidates(()=>true,docs).length,20000,'native SAF output picker');capture('09-save-picker');
    navigateDownloads();
    const name=one(n=>/EditText/.test(n.class||'')&&n.text===OUTPUT,docs);
    assert(name.text===OUTPUT,'SAF output name must match qpdf result; no renaming/overwrite');
    tap(one(exact('Save','SAVE'),docs));
    await until(()=>candidates(exact('저장 요청을 완료했습니다.'),app).length,30000,'successful SAF save status');capture('10-saved');
    const saved=adb(['exec-out','cat',DEVICE_OUTPUT],{binary:true,maxBuffer:2*1024*1024});
    assert(saved.length===summary.result.bytes,'Saved output byte count differs from real qpdf result');
    assert(saved.subarray(0,5).toString()==='%PDF-'&&/%%EOF\s*$/.test(saved.toString('latin1')),'Saved output lacks PDF header/EOF');
    summary.result.byteIdenticalToInput=saved.equals(fixture); // qpdf promises neither changed bytes nor smaller size.
    evidence(OUTPUT,saved);summary.savedPdf=true;summary.result.sha256=hash(saved);summary.result.devicePath=DEVICE_OUTPUT;
  } else summary.limitations.push('Explicit --no-save: UI qpdf result only; no saved PDF bytes verified.');
  stage='finished';summary.status='PASS';summary.elapsedMs=Date.now()-started;
  evidence('summary.json',JSON.stringify(summary,null,2)+'\n');
  console.log('PASS native-input-picker qpdf-STRUCTURE apk-sha256='+summary.apk.sha256+' saved-pdf='+summary.savedPdf+' evidence='+outDir);
}
main().catch(error=>{
  summary.status='FAIL';summary.failedStage=stage;summary.error=String(error.message||error);summary.elapsedMs=Date.now()-started;
  if(outDir){try{if(latest)evidence('failure.xml',latest.xml);evidence('summary.json',JSON.stringify(summary,null,2)+'\n');}catch(e){console.error('Evidence write failed: '+e.message);}}
  console.error('FAIL '+stage+': '+summary.error);process.exitCode=1;
});
