package com.pdfatelier.android;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * OrunDocs sign-in hand-off. Opens https://orundocs.web.app/signin in the user's browser and resolves
 * with the com.orundocs.app://auth callback URL. The URL is validated (state) and used by the web layer.
 * Only https://orundocs.web.app/ URLs can be opened; no other data leaves the device.
 */
@CapacitorPlugin(name = "OrunAuth")
public class OrunAuthPlugin extends Plugin {
    static final String SCHEME = "com.orundocs.app";
    private static final String ALLOWED_PREFIX = "https://orundocs.web.app/";
    private PluginCall pending;
    private static String coldStartUrl; // callback delivered while no call was pending (e.g. process restart)

    static boolean isAuthCallback(Uri uri) {
        return uri != null && SCHEME.equals(uri.getScheme()) && "auth".equals(uri.getHost());
    }

    @Override
    public void load() {
        Intent i = getActivity() == null ? null : getActivity().getIntent();
        if (i != null && Intent.ACTION_VIEW.equals(i.getAction()) && isAuthCallback(i.getData())) {
            coldStartUrl = i.getData().toString();
        }
    }

    private boolean openUrl(String url) {
        if (url == null || !url.startsWith(ALLOWED_PREFIX)) return false;
        Intent view = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        view.addCategory(Intent.CATEGORY_BROWSABLE);
        view.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getActivity().startActivity(view);
        return true;
    }

    @PluginMethod
    public void signIn(PluginCall call) {
        String url = call.getString("url");
        if (url == null || !url.startsWith(ALLOWED_PREFIX + "signin?")) { call.reject("허용되지 않은 로그인 주소입니다."); return; }
        if (pending != null) { pending.reject("새 로그인 요청으로 이전 요청을 취소했습니다.", "cancelled"); bridge.releaseCall(pending); }
        call.setKeepAlive(true);
        bridge.saveCall(call);
        pending = call;
        try {
            openUrl(url);
        } catch (ActivityNotFoundException e) {
            pending = null; call.setKeepAlive(false); bridge.releaseCall(call);
            call.reject("브라우저 앱이 없어 로그인 화면을 열 수 없습니다.");
        }
    }

    @PluginMethod
    public void openExternal(PluginCall call) {
        try {
            if (openUrl(call.getString("url"))) call.resolve(); else call.reject("허용되지 않은 주소입니다.");
        } catch (ActivityNotFoundException e) { call.reject("브라우저 앱이 없습니다."); }
    }

    @PluginMethod
    public void consumeColdStartUrl(PluginCall call) {
        JSObject r = new JSObject();
        r.put("url", coldStartUrl);
        coldStartUrl = null;
        call.resolve(r);
    }

    @Override
    protected void handleOnNewIntent(Intent intent) {
        super.handleOnNewIntent(intent);
        if (intent == null || !Intent.ACTION_VIEW.equals(intent.getAction()) || !isAuthCallback(intent.getData())) return;
        String url = intent.getData().toString();
        if (pending == null) { coldStartUrl = url; return; }
        PluginCall call = pending; pending = null;
        JSObject r = new JSObject();
        r.put("url", url);
        call.setKeepAlive(false);
        call.resolve(r);
        bridge.releaseCall(call);
    }
}
