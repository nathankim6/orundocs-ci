package com.pdfatelier.android;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle state) {
        registerPlugin(AtelierSafPlugin.class);
        registerPlugin(AtelierSharePlugin.class);
        registerPlugin(OrunAuthPlugin.class);
        super.onCreate(state);
    }
}
