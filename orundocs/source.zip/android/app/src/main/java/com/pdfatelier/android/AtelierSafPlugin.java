package com.pdfatelier.android;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;

import androidx.activity.result.ActivityResult;

import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.IOException;
import java.io.OutputStream;
import java.text.Normalizer;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;

/**
 * A deliberately narrow bridge for a user-mediated Android Storage Access Framework save.
 * It never accepts filesystem paths and never deletes the selected provider document.
 */
@CapacitorPlugin(name = "AtelierSaf")
public class AtelierSafPlugin extends Plugin {
    private static final long MAX_CHUNK_BYTES = 128L * 1024L;
    private static final long MAX_TOTAL_BYTES = 500L * 1024L * 1024L;
    private static final int MAX_ENCODED_CHARS = 4 * ((int) MAX_CHUNK_BYTES + 2) / 3 + 16;
    private static final Pattern MIME = Pattern.compile("^[A-Za-z0-9!#$&^_.+-]+/[A-Za-z0-9!#$&^_.+-]+$");

    private final Object lock = new Object();
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private SaveSession active;
    private boolean pickerPending;

    private static final class SaveSession {
        final String id;
        final Uri uri;
        final long expectedBytes;
        OutputStream stream;
        long nextIndex;
        long written;
        boolean busy;
        boolean abortQueued;
        boolean closed;

        SaveSession(String id, Uri uri, long expectedBytes) {
            this.id = id;
            this.uri = uri;
            this.expectedBytes = expectedBytes;
        }
    }

    @PluginMethod
    public void beginSave(PluginCall call) {
        final String suggestedName = safeBasename(call.getString("suggestedName"));
        final String mime = call.getString("mime");
        final long expectedBytes = call.getData().optLong("expectedBytes", -1L);
        if (suggestedName == null) {
            call.reject("A safe non-empty suggestedName is required", "E_NAME");
            return;
        }
        if (mime == null || !MIME.matcher(mime).matches() || mime.indexOf('*') >= 0) {
            call.reject("A concrete MIME type is required", "E_MIME");
            return;
        }
        if (expectedBytes < -1L || expectedBytes > MAX_TOTAL_BYTES) {
            call.reject("expectedBytes exceeds the 500 MiB save cap", "E_SIZE");
            return;
        }
        synchronized (lock) {
            if (pickerPending || active != null) {
                call.reject("Only one save may be pending or active", "E_BUSY");
                return;
            }
            pickerPending = true;
        }
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mime);
        intent.putExtra(Intent.EXTRA_TITLE, suggestedName);
        try {
            startActivityForResult(call, intent, "createDocumentResult");
        } catch (RuntimeException error) {
            synchronized (lock) { pickerPending = false; }
            call.reject("No document provider could open the save picker", "E_PICKER", error);
        }
    }

    @ActivityCallback
    private void createDocumentResult(PluginCall call, ActivityResult result) {
        if (call == null) { synchronized (lock) { pickerPending = false; } return; }
        Uri uri = result.getData() == null ? null : result.getData().getData();
        if (result.getResultCode() != Activity.RESULT_OK || uri == null) {
            synchronized (lock) { pickerPending = false; }
            JSObject cancelled = new JSObject();
            cancelled.put("cancelled", true);
            call.resolve(cancelled);
            return;
        }
        if (!"content".equalsIgnoreCase(uri.getScheme())) {
            synchronized (lock) { pickerPending = false; }
            call.reject("The provider did not return a content URI", "E_URI");
            return;
        }
        final long expected = call.getData().optLong("expectedBytes", -1L);
        final SaveSession session = new SaveSession(UUID.randomUUID().toString(), uri, expected);
        synchronized (lock) {
            // A lifecycle event may have cleared the pending picker while the callback was queued.
            if (!pickerPending || active != null) {
                pickerPending = false;
                call.reject("Save request is no longer active", "E_CANCELLED");
                return;
            }
            active = session;
            pickerPending = false;
        }
        io.execute(() -> {
            try {
                OutputStream stream = getContext().getContentResolver().openOutputStream(uri, "w");
                if (stream == null) throw new IOException("Provider returned no output stream");
                synchronized (lock) {
                    if (active != session || session.closed || session.abortQueued) {
                        closeQuietly(stream);
                        clearIfActive(session);
                        call.reject("Save was cancelled", "E_CANCELLED");
                        return;
                    }
                    session.stream = stream;
                }
                JSObject out = new JSObject();
                out.put("id", session.id);
                call.resolve(out);
            } catch (Exception e) {
                synchronized (lock) { clearIfActive(session); }
                call.reject("Could not open the selected document for writing", "E_OPEN", e);
            }
        });
    }

    @PluginMethod
    public void writeChunk(PluginCall call) {
        final String id = call.getString("id");
        final String encoded = call.getString("base64");
        final long index = call.getData().optLong("index", -1L);
        if (id == null || encoded == null || index < 0L || encoded.length() > MAX_ENCODED_CHARS) {
            call.reject("Invalid chunk request", "E_CHUNK");
            return;
        }
        final SaveSession session;
        synchronized (lock) {
            session = active;
            if (session == null || !session.id.equals(id) || session.closed || session.abortQueued) {
                call.reject("No matching active save", "E_STATE");
                return;
            }
            if (session.busy) {
                call.reject("A write is already in progress", "E_BUSY");
                return;
            }
            session.busy = true;
        }
        io.execute(() -> writeOnIo(call, session, encoded, index));
    }

    private void writeOnIo(PluginCall call, SaveSession session, String encoded, long index) {
        try {
            if (index != session.nextIndex) throw new IllegalArgumentException("Chunks must be ordered");
            byte[] bytes = Base64.decode(encoded, Base64.DEFAULT);
            if (bytes.length > MAX_CHUNK_BYTES) throw new IllegalArgumentException("Chunk is too large");
            if (session.written > MAX_TOTAL_BYTES - bytes.length) throw new IllegalArgumentException("Save exceeds 500 MiB cap");
            if (session.expectedBytes >= 0 && session.written > session.expectedBytes - bytes.length) {
                throw new IllegalArgumentException("Save exceeds declared size");
            }
            session.stream.write(bytes);
            session.written += bytes.length;
            session.nextIndex++;
            synchronized (lock) { session.busy = false; }
            call.resolve();
        } catch (Exception e) {
            synchronized (lock) {
                session.busy = false;
                closeSessionLocked(session);
            }
            // Do not delete the provider document: it may contain a partial user-selected result.
            call.reject("Chunk was not written; any partial document was left untouched", "E_WRITE", e);
        }
    }

    @PluginMethod
    public void finishSave(PluginCall call) {
        final SaveSession session = matchingSession(call);
        if (session == null) return;
        synchronized (lock) {
            if (session.busy || session.abortQueued) { call.reject("Save is busy or cancelling", "E_BUSY"); return; }
            session.busy = true;
        }
        io.execute(() -> {
            try {
                if (session.expectedBytes >= 0 && session.written != session.expectedBytes) {
                    throw new IOException("Written size differs from expectedBytes");
                }
                session.stream.flush();
                synchronized (lock) { closeSessionLocked(session); }
                JSObject out = new JSObject();
                out.put("uri", session.uri.toString());
                call.resolve(out);
            } catch (Exception e) {
                synchronized (lock) { closeSessionLocked(session); }
                call.reject("Save could not be finalized; partial document was left untouched", "E_FINISH", e);
            }
        });
    }

    @PluginMethod
    public void abortSave(PluginCall call) {
        final SaveSession session = matchingSession(call);
        if (session == null) return;
        synchronized (lock) {
            if (session.abortQueued) { call.resolve(); return; }
            session.abortQueued = true;
        }
        io.execute(() -> {
            synchronized (lock) { closeSessionLocked(session); }
            // Closing is the only cleanup. Never delete a provider document selected by the user.
            call.resolve();
        });
    }

    private SaveSession matchingSession(PluginCall call) {
        String id = call.getString("id");
        synchronized (lock) {
            if (id == null || active == null || !active.id.equals(id) || active.closed) {
                call.reject("No matching active save", "E_STATE");
                return null;
            }
            return active;
        }
    }

    @Override
    protected void handleOnDestroy() {
        synchronized (lock) {
            pickerPending = false;
            if (active != null) closeSessionLocked(active);
        }
        io.shutdown();
        super.handleOnDestroy();
    }

    private void closeSessionLocked(SaveSession session) {
        if (session.closed) return;
        session.closed = true;
        closeQuietly(session.stream);
        session.stream = null;
        clearIfActive(session);
    }

    private void clearIfActive(SaveSession session) {
        if (active == session) active = null;
    }

    private static void closeQuietly(OutputStream stream) {
        if (stream != null) try { stream.close(); } catch (IOException ignored) { }
    }

    private static String safeBasename(String input) {
        if (input == null) return null;
        String s = Normalizer.normalize(input, Normalizer.Form.NFC).trim();
        if (s.isEmpty() || s.length() > 240 || ".".equals(s) || "..".equals(s)) return null;
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < s.length();) {
            int cp = s.codePointAt(i);
            if (!Character.isISOControl(cp) && cp != '/' && cp != '\\' && cp != 0) out.appendCodePoint(cp);
            i += Character.charCount(cp);
        }
        String clean = out.toString().trim();
        return clean.isEmpty() || clean.length() > 240 || ".".equals(clean) || "..".equals(clean) ? null : clean;
    }
}
