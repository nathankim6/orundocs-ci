package com.pdfatelier.android;

import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.util.Base64;

import androidx.activity.result.ActivityResult;
import androidx.core.content.FileProvider;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;

/**
 * Narrow bridge for the Android system share sheet. Result bytes are written only to an app-private
 * cache folder and exposed to the chosen target through FileProvider with a temporary read grant.
 */
@CapacitorPlugin(name = "AtelierShare")
public class AtelierSharePlugin extends Plugin {
    private static final long MAX_CHUNK_BYTES = 128L * 1024L;
    private static final long MAX_TOTAL_BYTES = 500L * 1024L * 1024L;
    private static final int MAX_FILES = 20;
    private static final int MAX_ENCODED_CHARS = 4 * ((int) MAX_CHUNK_BYTES + 2) / 3 + 16;
    private static final Pattern MIME = Pattern.compile("^[A-Za-z0-9!#$&^_.+-]+/[A-Za-z0-9!#$&^_.+-]+$");

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Object lock = new Object();
    private final Map<String, Pending> files = new HashMap<>();
    private long totalBytes;
    private boolean sharing;

    private static final class Pending {
        final File file; final String mime; final long expected;
        FileOutputStream out; long next; long written; boolean done;
        Pending(File file, String mime, long expected) { this.file = file; this.mime = mime; this.expected = expected; }
    }

    private File shareRoot() { return new File(getContext().getCacheDir(), "atelier-share"); }

    private static void deleteTree(File f) {
        if (f == null || !f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteTree(k);
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }

    /** Starts a new share batch: removes any earlier shared copies from the private cache. */
    @PluginMethod
    public void reset(PluginCall call) {
        io.execute(() -> {
            synchronized (lock) {
                if (sharing) { call.reject("A share sheet is already open", "E_BUSY"); return; }
                for (Pending p : files.values()) closeQuietly(p);
                files.clear(); totalBytes = 0;
            }
            deleteTree(shareRoot());
            call.resolve();
        });
    }

    @PluginMethod
    public void beginFile(PluginCall call) {
        final String name = safeBasename(call.getString("name"));
        final String mime = call.getString("mime");
        final long expected = call.getData().optLong("expectedBytes", -1L);
        if (name == null) { call.reject("A safe file name is required", "E_NAME"); return; }
        if (mime == null || !MIME.matcher(mime).matches() || mime.indexOf('*') >= 0) { call.reject("A concrete MIME type is required", "E_MIME"); return; }
        if (expected < 0 || expected > MAX_TOTAL_BYTES) { call.reject("Invalid size", "E_SIZE"); return; }
        io.execute(() -> {
            try {
                synchronized (lock) {
                    if (files.size() >= MAX_FILES) throw new IOException("Too many files");
                    if (totalBytes + expected > MAX_TOTAL_BYTES) throw new IOException("Share exceeds 500 MiB");
                }
                File dir = new File(shareRoot(), UUID.randomUUID().toString());
                if (!dir.mkdirs()) throw new IOException("Could not create share folder");
                File file = new File(dir, name);
                if (!file.getCanonicalPath().startsWith(dir.getCanonicalPath() + File.separator)) throw new IOException("Unsafe name");
                Pending p = new Pending(file, mime, expected);
                p.out = new FileOutputStream(file);
                String id = UUID.randomUUID().toString();
                synchronized (lock) { files.put(id, p); totalBytes += expected; }
                JSObject r = new JSObject(); r.put("id", id); call.resolve(r);
            } catch (Exception e) { call.reject("Could not prepare the file for sharing", "E_OPEN", e); }
        });
    }

    @PluginMethod
    public void writeChunk(PluginCall call) {
        final String id = call.getString("id"), encoded = call.getString("base64");
        final long index = call.getData().optLong("index", -1L);
        if (id == null || encoded == null || index < 0 || encoded.length() > MAX_ENCODED_CHARS) { call.reject("Invalid chunk", "E_CHUNK"); return; }
        io.execute(() -> {
            Pending p; synchronized (lock) { p = files.get(id); }
            try {
                if (p == null || p.done || p.out == null) throw new IOException("No matching file");
                if (index != p.next) throw new IOException("Chunks must be ordered");
                byte[] bytes = Base64.decode(encoded, Base64.DEFAULT);
                if (bytes.length > MAX_CHUNK_BYTES || p.written + bytes.length > p.expected) throw new IOException("Chunk exceeds declared size");
                p.out.write(bytes); p.written += bytes.length; p.next++;
                call.resolve();
            } catch (Exception e) { if (p != null) closeQuietly(p); call.reject("Chunk was not written", "E_WRITE", e); }
        });
    }

    @PluginMethod
    public void finishFile(PluginCall call) {
        final String id = call.getString("id");
        io.execute(() -> {
            Pending p; synchronized (lock) { p = id == null ? null : files.get(id); }
            try {
                if (p == null || p.out == null) throw new IOException("No matching file");
                p.out.flush(); closeQuietly(p);
                if (p.written != p.expected) throw new IOException("Written size differs from declared size");
                p.done = true; call.resolve();
            } catch (Exception e) { call.reject("File could not be finalised", "E_FINISH", e); }
        });
    }

    @PluginMethod
    public void share(PluginCall call) {
        final JSArray ids = call.getArray("ids");
        final String title = call.getString("title", "공유");
        final ArrayList<Uri> uris = new ArrayList<>();
        final ArrayList<String> mimes = new ArrayList<>();
        try {
            if (ids == null || ids.length() == 0 || ids.length() > MAX_FILES) throw new IOException("Nothing to share");
            synchronized (lock) {
                if (sharing) throw new IOException("A share sheet is already open");
                for (int i = 0; i < ids.length(); i++) {
                    Pending p = files.get(ids.getString(i));
                    if (p == null || !p.done) throw new IOException("File is not ready");
                    uris.add(FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".fileprovider", p.file));
                    mimes.add(p.mime);
                }
                sharing = true;
            }
        } catch (Exception e) { call.reject("Could not prepare sharing", "E_SHARE", e); return; }
        String type = mimes.get(0);
        String major = type.substring(0, type.indexOf('/'));
        boolean sameType = true, sameMajor = true;
        for (String m : mimes) { if (!m.equals(type)) sameType = false; if (!m.startsWith(major + "/")) sameMajor = false; }
        if (!sameType) type = sameMajor ? major + "/*" : "*/*";
        Intent send;
        if (uris.size() == 1) {
            send = new Intent(Intent.ACTION_SEND);
            send.putExtra(Intent.EXTRA_STREAM, uris.get(0));
        } else {
            send = new Intent(Intent.ACTION_SEND_MULTIPLE);
            send.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        }
        send.setType(type);
        ClipData clip = ClipData.newRawUri(title, uris.get(0));
        for (int i = 1; i < uris.size(); i++) clip.addItem(new ClipData.Item(uris.get(i)));
        send.setClipData(clip);
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        Intent chooser = Intent.createChooser(send, title);
        chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivityForResult(call, chooser, "shareResult");
        } catch (RuntimeException e) {
            synchronized (lock) { sharing = false; }
            call.reject("No app can receive this file", "E_NO_TARGET", e);
        }
    }

    @ActivityCallback
    private void shareResult(PluginCall call, ActivityResult result) {
        synchronized (lock) { sharing = false; }
        if (call == null) return;
        JSObject r = new JSObject();
        r.put("shared", true); // Android does not report whether the target app completed the transfer.
        call.resolve(r);
    }

    @Override
    protected void handleOnDestroy() {
        synchronized (lock) { for (Pending p : files.values()) closeQuietly(p); files.clear(); }
        io.shutdown();
        super.handleOnDestroy();
    }

    private static void closeQuietly(Pending p) {
        if (p.out != null) try { p.out.close(); } catch (IOException ignored) { }
        p.out = null;
    }

    private static String safeBasename(String input) {
        if (input == null) return null;
        String s = Normalizer.normalize(input, Normalizer.Form.NFC).trim();
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < s.length();) {
            int cp = s.codePointAt(i);
            if (!Character.isISOControl(cp) && cp != '/' && cp != '\\' && cp != ':' && cp != 0) out.appendCodePoint(cp);
            i += Character.charCount(cp);
        }
        String clean = out.toString().trim();
        return clean.isEmpty() || clean.length() > 200 || ".".equals(clean) || "..".equals(clean) || clean.startsWith(".") ? null : clean;
    }
}
