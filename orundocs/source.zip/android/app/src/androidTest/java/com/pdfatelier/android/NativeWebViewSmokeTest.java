package com.pdfatelier.android;

import static org.junit.Assert.*;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.util.Base64;
import android.util.Log;
import android.webkit.WebView;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject2;
import androidx.test.uiautomator.Until;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Private CI only. All inputs are synthetic; no production test hooks or external services. */
@RunWith(AndroidJUnit4.class)
public class NativeWebViewSmokeTest {
    private static final String TAG = "AtelierNativeSmoke";
    private static final Pattern DOCUMENTS_UI = Pattern.compile("com\\.(android|google\\.android)\\.documentsui");
    private WebView web;
    private UiDevice device;
    private Context target;
    private File evidence;
    private String fixture;
    private String examPhoto;
    private String stage = "launch";

    /** Captures the browser hand-off inside this instrumentation process only (no browser is launched). */
    private static final class SigninMonitor extends Instrumentation.ActivityMonitor {
        volatile Intent last; volatile int count;
        SigninMonitor() { super(); }
        @Override public Instrumentation.ActivityResult onStartActivity(Intent intent) {
            Uri d = intent.getData();
            if (Intent.ACTION_VIEW.equals(intent.getAction()) && d != null && d.toString().startsWith("https://orundocs.web.app/signin?")) {
                last = intent; count++;
                return new Instrumentation.ActivityResult(Activity.RESULT_CANCELED, null);
            }
            return null;
        }
    }

    private String requestSignin(SigninMonitor monitor) throws Exception {
        int before = monitor.count;
        js("(()=>{document.querySelector('#od-gate .od-google').click();return true;})()");
        long end = SystemClock.uptimeMillis() + 15000;
        while (monitor.count == before && SystemClock.uptimeMillis() < end) SystemClock.sleep(100);
        assertTrue("Sign-in opened the browser hand-off", monitor.count > before);
        Uri u = monitor.last.getData();
        assertEquals("app", u.getQueryParameter("target"));
        String state = u.getQueryParameter("state");
        assertTrue("Random state", state != null && state.matches("[A-Za-z0-9_-]{40,}"));
        return state;
    }

    private void deliverCallback(String fragment) {
        Intent cb = new Intent(Intent.ACTION_VIEW, Uri.parse("com.orundocs.app://auth#" + fragment));
        cb.setPackage(target.getPackageName());
        cb.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        target.startActivity(cb);
    }

    private void signInGate() throws Exception {
        stage = "00-login-gate";
        await("sign-in gate shown", "document.documentElement.classList.contains('od-locked') && !document.getElementById('od-gate').hidden && document.querySelector('#od-gate .od-msg').textContent.includes('로그인해 주세요')", 60000);
        assertEquals("Workspace hidden while locked", Boolean.TRUE, js("getComputedStyle(document.querySelector('.app-sidebar')).visibility==='hidden' && getComputedStyle(document.getElementById('od-gate')).visibility==='visible'"));
        capture("00a-login-gate");
        SigninMonitor monitor = new SigninMonitor();
        InstrumentationRegistry.getInstrumentation().addMonitor(monitor);
        try {
            String state = requestSignin(monitor);
            deliverCallback("rt=ci-forged-refresh-token-0000000000000000&state=FORGED_" + state.substring(0, 20));
            await("forged state rejected", "document.querySelector('#od-gate .od-msg').textContent.includes('일치하지 않습니다') && document.documentElement.classList.contains('od-locked')", 20000);
            capture("00b-forged-state-rejected");
            state = requestSignin(monitor);
            deliverCallback("rt=ci-invalid-refresh-token-0000000000000000&state=" + state);
            await("invalid token blocked by Google/allowlist check", "document.querySelector('#od-gate .od-msg').textContent.includes('허용되지 않은') && document.documentElement.classList.contains('od-locked')", 45000);
            capture("00c-not-allowed-blocked");
            String rt = InstrumentationRegistry.getArguments().getString("odRefreshToken");
            if (rt != null && rt.length() > 20) {
                state = requestSignin(monitor);
                deliverCallback("rt=" + Uri.encode(rt) + "&state=" + state);
                await("allowed account unlocked", "!document.documentElement.classList.contains('od-locked') && document.getElementById('od-gate').hidden && document.getElementById('od-account').textContent.includes('@')", 45000);
                capture("00d-allowed-unlocked");
                Log.i(TAG, "LOGIN_ALLOWED_PATH=verified");
            } else {
                // Tool checks below need the workspace; hide the gate in this test session only.
                js("(()=>{document.documentElement.classList.remove('od-locked');document.getElementById('od-gate').hidden=true;return true;})()");
                Log.i(TAG, "LOGIN_ALLOWED_PATH=not-run(no token argument)");
            }
        } finally {
            InstrumentationRegistry.getInstrumentation().removeMonitor(monitor);
        }
    }

    @Test(timeout = 480000)
    public void catalogPreviewRotateOfficeAndRealSaf() throws Exception {
        target = InstrumentationRegistry.getInstrumentation().getTargetContext();
        assertEquals("com.orundocs.app", target.getPackageName());
        device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        File base = target.getExternalFilesDir(null);
        assertNotNull("App external files directory", base);
        String requested = InstrumentationRegistry.getArguments().getString("smokeArtifactDir");
        evidence = requested == null ? new File(base, "native-smoke") : new File(requested);
        assertTrue("Artifact directory must stay in app external files", evidence.getCanonicalPath().startsWith(base.getCanonicalPath() + File.separator));
        assertTrue("Create evidence directory", evidence.isDirectory() || evidence.mkdirs());
        try (InputStream in = InstrumentationRegistry.getInstrumentation().getContext().getAssets().open("smoke-two-pages.pdf")) {
            fixture = Base64.encodeToString(readBounded(in, 100000), Base64.NO_WRAP);
        }
        try (InputStream in = InstrumentationRegistry.getInstrumentation().getContext().getAssets().open("exam-photo.jpg")) {
            examPhoto = Base64.encodeToString(readBounded(in, 2000000), Base64.NO_WRAP);
        }
        try (ActivityScenario<MainActivity> scenario = ActivityScenario.launch(MainActivity.class)) {
            scenario.onActivity(activity -> web = activity.getBridge().getWebView());
            try {
                signInGate();
                await("app local catalog", "document.querySelectorAll('#tool-grid .tool-card').length===26 && !!document.querySelector('#suite-picker')", 60000);
                assertTrue("Only packaged local origin", js("location.origin").equals("https://localhost"));
                assertEquals(Boolean.TRUE, js("Capacitor.isNativePlatform() && Capacitor.getPlatform()==='android'"));
                assertEquals(Boolean.TRUE, js("document.querySelector('#tool-total').textContent==='26 TOOLS' && document.body.textContent.includes('TOOL LIBRARY') && document.querySelector('.sidebar-signature').textContent.includes('옳은영어 김성진T') && document.querySelector('#picker').type==='file'"));
                capture("01-catalog-25");
                // Passively observe the real native promises, forwarding every invocation unchanged.
                // This lives only in this instrumentation session, not in production assets.
                js("(()=>{window.__smokeOriginalPromise=Capacitor.nativePromise;window.__smokeSaves=[];window.__smokeChunks=[];Capacitor.nativePromise=function(p,m,o){if(p==='AtelierSaf'&&m==='writeChunk')window.__smokeChunks.push({index:o.index,length:atob(o.base64).length});return window.__smokeOriginalPromise.apply(this,arguments).then(r=>{if(p==='AtelierSaf'&&m==='finishSave')window.__smokeSaves.push(r);return r;});};return true;})()");
                runTool("rotate", "pdf", "02-rotate");
                js("(()=>{document.querySelectorAll('#suite-output-files .suite-output button')[1].click(); return true;})()");
                await("rotated result preview", "document.querySelector('#suite-preview-status').textContent.startsWith('작업 결과') && document.querySelector('#suite-geometry').textContent.includes('회전 90도')", 45000);
                capture("03-rotated-preview");
                saveAndVerify("pdf", "04-rotate-save");
                runTool("pdf-to-word", "docx", "05-docx");
                saveAndVerify("docx", "06-docx-save");
                runTool("pdf-to-ppt", "pptx", "07-pptx");
                saveAndVerify("pptx", "08-pptx-save");
                runTool("pdf-to-excel", "xlsx", "09-xlsx");
                saveAndVerify("xlsx", "10-xlsx-save");
                stage = "11-fullscreen-page-selection";
                js("(()=>{document.getElementById('suite-preview-expand').click();document.getElementById('suite-preview-grid').click();return true;})()");
                await("fullscreen lazy two-page gallery", "document.querySelector('#suite-preview').classList.contains('pdf-preview-expanded') && document.querySelectorAll('#suite-page-grid .pdf-page-tile').length===2 && document.querySelectorAll('#suite-page-grid canvas').length>0", 45000);
                assertEquals(Boolean.TRUE, js("document.getElementById('suite-preview').getBoundingClientRect().width>=innerWidth-2"));
                js("(()=>{document.getElementById('suite-select-none').click();document.getElementById('suite-touch-select').click();document.querySelectorAll('#suite-page-grid .pdf-page-tile')[0].click();document.querySelectorAll('#suite-page-grid .pdf-page-tile')[1].click();return true;})()");
                assertEquals(Boolean.TRUE, js("document.querySelectorAll('#suite-page-grid .pdf-page-tile[aria-pressed=true]').length===2"));
                capture("11-fullscreen-multiple-pages");
                js("(()=>{document.getElementById('suite-page-actions').click();return true;})()");
                assertEquals(Boolean.TRUE, js("!document.querySelector('#suite-preview .pdf-page-context-menu').hidden && document.querySelectorAll('#suite-preview .pdf-page-context-menu button').length===3"));
                capture("12-page-actions-menu");
                js("(()=>{document.querySelector('#suite-preview .pdf-page-context-menu button[data-action=extract]').click();return true;})()");
                await("selected PDF generated", "document.querySelectorAll('#suite-preview .pdf-page-result-row').length===1 && document.querySelector('#suite-preview .pdf-page-action-results').textContent.includes('selected-pages.pdf')", 90000);
                capture("13-preview-extracted-pdf");
                saveAndVerify("pdf", "14-preview-extract-save", true);
                js("(()=>{document.getElementById('suite-preview-expand').click();return true;})()");
                assertEquals(Boolean.FALSE, js("document.getElementById('suite-preview').classList.contains('pdf-preview-expanded')"));
                stage = "15-exam-scan";
                js("(()=>{document.querySelector('#home-nav').click();let s=document.querySelector('#tool-search');s.value='exam-scan';s.dispatchEvent(new Event('input',{bubbles:true}));return true;})()");
                assertEquals("Unique exam tool card", 1, ((Number) js("document.querySelectorAll('#tool-grid .tool-card').length")).intValue());
                js("(()=>{document.querySelector('#tool-grid .tool-card').click();return true;})()");
                await("exam workspace opened", "!document.getElementById('exam-view').hidden && location.hash==='#exam-scan'", 5000);
                js("(()=>{const b=Uint8Array.from(atob(" + JSONObject.quote(examPhoto) + "),c=>c.charCodeAt(0));const d=new DataTransfer();d.items.add(new File([b],'exam-photo.jpg',{type:'image/jpeg'}));const p=document.getElementById('exam-pick');p.files=d.files;p.dispatchEvent(new Event('change',{bubbles:true}));return true;})()");
                await("sheet detected", "document.getElementById('exam-status').textContent.includes('확인한 뒤') && document.querySelectorAll('#exam-pages li').length===1", 60000);
                capture("15-exam-crop");
                js("(()=>{document.getElementById('exam-run').click();return true;})()");
                await("handwriting removed", "document.getElementById('exam-status').textContent.includes('처리 완료') && document.getElementById('exam-canvas').width>300", 120000);
                assertEquals(Boolean.FALSE, js("document.getElementById('exam-status').classList.contains('is-error')"));
                capture("16-exam-result");
                js("(()=>{document.getElementById('exam-format').value='pdf';document.getElementById('exam-format').dispatchEvent(new Event('change'));return true;})()");
                saveAndVerify("pdf", "17-exam-pdf-save", "#exam-save", "window.__smokeSaves.length===1 && document.getElementById('exam-status').textContent.includes('저장을 완료')", 1);
                stage = "18-exam-share";
                js("(()=>{document.getElementById('exam-format').value='jpg';document.getElementById('exam-format').dispatchEvent(new Event('change'));document.getElementById('exam-share').click();return true;})()");
                assertTrue("Android share sheet must open", device.wait(Until.hasObject(By.pkg(Pattern.compile("android|com\\.android\\.intentresolver"))), 30000));
                SystemClock.sleep(1500);
                capture("18-exam-share-sheet");
                device.pressBack();
                await("share sheet closed", "document.getElementById('exam-status').textContent.includes('공유 창을 열었습니다')", 30000);
                Log.i(TAG, "PASS exam scan: erase, SAF PDF save, share sheet");
                write("PASS.txt", "PASS: native local WebView catalog=26; exam photo handwriting removal + real SAF PDF save + Android share sheet; creator; synthetic input; rendered 2-page preview; rotate=90; PDF/DOCX/PPTX/XLSX generated through real UI; five actual DocumentsUI SAF saves; fullscreen lazy gallery, multiple page selection, three page-action menu entries and extracted PDF verified; provider bytes structurally checked. Not full 25-tool verification.\n");
                Log.i(TAG, "PASS all smoke checkpoints; evidence=" + evidence);
            } catch (Throwable error) {
                Log.e(TAG, "FAIL stage=" + stage, error);
                try { capture("FAIL-" + stage); write("FAIL.txt", stage + "\n" + error); } catch (Throwable ignored) { Log.e(TAG, "Could not write failure evidence", ignored); }
                if (error instanceof Exception) throw (Exception) error;
                throw (Error) error;
            } finally {
                try { js("(()=>{if(window.__smokeOriginalPromise)Capacitor.nativePromise=window.__smokeOriginalPromise;delete window.__smokeOriginalPromise;delete window.__smokeSaves;delete window.__smokeChunks;return true;})()"); } catch (Throwable ignored) { Log.w(TAG, "Observer cleanup failed; ActivityScenario will close", ignored); }
            }
        }
    }

    private void runTool(String id, String extension, String checkpoint) throws Exception {
        stage = checkpoint;
        js("(()=>{document.querySelector('#home-nav').click();let s=document.querySelector('#tool-search');s.value=" + JSONObject.quote(id) + ";s.dispatchEvent(new Event('input',{bubbles:true}));return true;})()");
        assertEquals("Unique catalog search: " + id, 1, ((Number) js("document.querySelectorAll('#tool-grid .tool-card').length")).intValue());
        js("(()=>{document.querySelector('#tool-grid .tool-card').click(); return true;})()");
        await("tool opened", "location.hash===" + JSONObject.quote("#" + id) + " && !document.querySelector('#suite-view').hidden", 5000);
        js("(()=>{const b=Uint8Array.from(atob(" + JSONObject.quote(fixture) + "),c=>c.charCodeAt(0));const d=new DataTransfer();d.items.add(new File([b],'ci-smoke-'+Date.now()+'.pdf',{type:'application/pdf'}));const p=document.querySelector('#suite-picker');p.files=d.files;p.dispatchEvent(new Event('change',{bubbles:true}));return true;})()");
        await("real input PDF rendered", "document.querySelectorAll('#suite-files li').length===1 && document.querySelector('#suite-preview-count').textContent.trim()==='/ 2' && document.querySelector('#suite-geometry').textContent.includes('2페이지') && document.querySelector('#suite-canvas').width>1", 45000);
        assertEquals("Canvas contains rendered ink", Boolean.TRUE, js("(()=>{const c=document.querySelector('#suite-canvas');const a=c.getContext('2d').getImageData(0,0,c.width,c.height).data;for(let i=0;i<a.length;i+=4)if(a[i+3]>0&&a[i]<200&&a[i+1]<200&&a[i+2]<200)return true;return false;})()"));
        js("(()=>{document.querySelector('#suite-run').click(); return true;})()");
        await("processed output " + extension, "!document.querySelector('#suite-run').disabled && !document.querySelector('#suite-results').hidden && document.querySelectorAll('#suite-output-files .suite-output').length===1 && document.querySelector('#suite-output-files').textContent.includes('." + extension + "')", 90000);
        assertEquals(Boolean.FALSE, js("document.querySelector('#suite-status').classList.contains('is-error')"));
        capture(checkpoint);
        Log.i(TAG, "PASS generated " + extension + " via " + id);
    }

    private void saveAndVerify(String kind, String checkpoint) throws Exception {
        saveAndVerify(kind, checkpoint, false);
    }

    private void saveAndVerify(String kind, String checkpoint, boolean pageAction) throws Exception {
        saveAndVerify(kind, checkpoint, pageAction ? "#suite-preview .pdf-page-result-row button" : "#suite-output-files .suite-output button", pageAction ? "window.__smokeSaves.length===1" : "window.__smokeSaves.length===1 && document.querySelector('#suite-status').textContent==='저장 요청을 완료했습니다.'", 2);
    }

    private void saveAndVerify(String kind, String checkpoint, String saveSelector, String doneCheck, int expectedPages) throws Exception {
        stage = checkpoint;
        js("(()=>{window.__smokeSaves=[];window.__smokeChunks=[];document.querySelector(" + JSONObject.quote(saveSelector) + ").click();return true;})()");
        assertTrue("Real Android DocumentsUI must open", device.wait(Until.hasObject(By.pkg(DOCUMENTS_UI)), 20000));
        capture(checkpoint + "-picker");
        UiObject2 save = device.wait(Until.findObject(By.res(Pattern.compile(".*:id/action_menu_save"))), 5000);
        if (save == null) save = device.wait(Until.findObject(By.text(Pattern.compile("(?i)save"))), 5000);
        assertNotNull("English DocumentsUI Save control", save);
        assertTrue("DocumentsUI Save enabled (valid destination)", save.isEnabled());
        save.click();
        await("SAF finished writing " + kind, doneCheck, 45000);
        String uriText = (String) js("window.__smokeSaves[0].uri");
        assertTrue("Provider content URI", uriText.startsWith("content://"));
        assertEquals("Sequential bounded native chunks", Boolean.TRUE, js("window.__smokeChunks.length>0 && window.__smokeChunks.every((c,i)=>c.index===i&&c.length>0&&c.length<=131072)"));
        byte[] bytes;
        try (InputStream in = target.getContentResolver().openInputStream(Uri.parse(uriText))) {
            assertNotNull("Read provider result", in);
            bytes = readBounded(in, 20000000);
        }
        assertTrue("Nonempty real artifact", bytes.length > 100);
        if (kind.equals("pdf")) {
            assertTrue(new String(bytes, 0, 5, StandardCharsets.US_ASCII).equals("%PDF-"));
            try (ParcelFileDescriptor fd = target.getContentResolver().openFileDescriptor(Uri.parse(uriText), "r")) {
                assertNotNull(fd);
                try (PdfRenderer pdf = new PdfRenderer(fd)) {
                    assertEquals("PDF renderer page count", expectedPages, pdf.getPageCount());
                }
            }
        } else {
            Map<String, String> entries = zipXml(bytes);
            assertTrue("OOXML content types", entries.containsKey("[Content_Types].xml"));
            if (kind.equals("docx")) {
                assertTrue("Word document XML", entries.containsKey("word/document.xml"));
                assertTrue("Word contains text paragraphs", entries.get("word/document.xml").contains("<w:t"));
            } else if (kind.equals("pptx")) {
                assertTrue("PowerPoint two real slides", entries.containsKey("ppt/slides/slide1.xml") && entries.containsKey("ppt/slides/slide2.xml"));
                assertTrue("PowerPoint contains page images", entries.keySet().stream().anyMatch(n -> n.startsWith("ppt/media/")));
            } else {
                assertTrue("Excel workbook", entries.containsKey("xl/workbook.xml"));
                assertTrue("Excel first sheet", entries.containsKey("xl/worksheets/sheet1.xml"));
                assertTrue("Excel populated rows", entries.get("xl/worksheets/sheet1.xml").contains("<row"));
            }
        }
        try (FileOutputStream out = new FileOutputStream(new File(evidence, "synthetic-result." + kind))) { out.write(bytes); }
        write(checkpoint + "-saved.json", "{\"kind\":" + JSONObject.quote(kind) + ",\"bytes\":" + bytes.length + ",\"uri\":" + JSONObject.quote(uriText) + ",\"actualSystemPicker\":true}");
        capture(checkpoint);
        Log.i(TAG, "PASS real SAF " + kind + " bytes=" + bytes.length);
    }

    private Map<String, String> zipXml(byte[] bytes) throws Exception {
        Map<String, String> result = new HashMap<>();
        int total = 0;
        try (ZipInputStream zip = new ZipInputStream(new ByteArrayInputStream(bytes))) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                byte[] content = readBounded(zip, 20000000);
                total += content.length;
                assertTrue("Bounded extracted synthetic archive", total < 40000000);
                result.put(entry.getName(), entry.getName().endsWith(".xml") ? new String(content, StandardCharsets.UTF_8) : "");
                zip.closeEntry();
            }
        }
        return result;
    }

    private static byte[] readBounded(InputStream in, int limit) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int n;
        while ((n = in.read(buffer)) != -1) {
            if (out.size() + n > limit) throw new IllegalStateException("Synthetic fixture/output exceeds test bound");
            out.write(buffer, 0, n);
        }
        return out.toByteArray();
    }

    private Object js(String expression) throws Exception {
        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<String> value = new AtomicReference<>();
        InstrumentationRegistry.getInstrumentation().runOnMainSync(() -> web.evaluateJavascript("(()=>{try{return {ok:true,value:(" + expression + ")};}catch(e){return {ok:false,error:String(e)};}})()", result -> { value.set(result); done.countDown(); }));
        assertTrue("WebView evaluateJavascript callback", done.await(10, TimeUnit.SECONDS));
        Object parsed = new JSONTokener(value.get()).nextValue();
        assertTrue("JavaScript returned structured result: " + value.get(), parsed instanceof JSONObject);
        JSONObject result = (JSONObject) parsed;
        assertTrue("JavaScript error: " + result.optString("error"), result.getBoolean("ok"));
        return result.opt("value");
    }

    private void await(String label, String predicate, long timeout) throws Exception {
        long deadline = SystemClock.elapsedRealtime() + timeout;
        do {
            if (Boolean.TRUE.equals(js(predicate))) return;
            if (Boolean.TRUE.equals(js("!!document.querySelector('#suite-status.is-error')")))
                fail(label + ": " + js("document.querySelector('#suite-status').textContent"));
            SystemClock.sleep(200);
        } while (SystemClock.elapsedRealtime() < deadline);
        fail("Timed out: " + label + " state=" + js("JSON.stringify({url:location.href,status:document.querySelector('#suite-status')?.textContent,preview:document.querySelector('#suite-preview-status')?.textContent})"));
    }

    private void capture(String name) throws Exception {
        assertTrue("Screenshot " + name, device.takeScreenshot(new File(evidence, name + ".png")));
        device.dumpWindowHierarchy(new File(evidence, name + ".xml"));
        long total = 0;
        File[] files = evidence.listFiles();
        if (files != null) for (File file : files) total += file.length();
        assertTrue("Evidence remains below 80 MiB", total < 80L * 1024L * 1024L);
        write(name + "-webview.json", String.valueOf(js("JSON.stringify({url:location.href,title:document.title,cards:document.querySelectorAll('#tool-grid .tool-card').length,status:document.querySelector('#suite-status')?.textContent,preview:document.querySelector('#suite-preview-status')?.textContent,geometry:document.querySelector('#suite-geometry')?.textContent,outputs:document.querySelector('#suite-output-files')?.textContent})")));
    }

    private void write(String name, String text) throws Exception {
        try (FileOutputStream out = new FileOutputStream(new File(evidence, name))) { out.write(text.getBytes(StandardCharsets.UTF_8)); }
    }
}
